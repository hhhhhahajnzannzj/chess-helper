package com.chesshelper.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chesshelper.overlay.core.BoardGeometry;
import com.chesshelper.overlay.core.ChangeDetector;
import com.chesshelper.overlay.core.Engine;
import com.chesshelper.overlay.core.GameTracker;
import com.chesshelper.overlay.core.GeminiClient;
import com.chesshelper.overlay.core.Move;
import com.chesshelper.overlay.core.Position;
import com.chesshelper.overlay.core.Rules;
import com.chesshelper.overlay.core.Texts;

import java.io.ByteArrayOutputStream;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The floating "Chess Helper" window - fully automatic:
 *
 *   watch the board on screen -> when it changes, ask Gemini to read it -> the built-in engine
 *   finds the best move -> show a YELLOW box (piece to pick up), a GREEN box (where to put it)
 *   and a GREEN ARROW between them.
 *
 * You only drag a rectangle around the board once and switch Auto on.
 */
public class OverlayService extends Service {
    public static final String EXTRA_CODE = "code";
    public static final String EXTRA_DATA = "data";
    public static final String ACTION_STOP = "com.chesshelper.overlay.STOP";
    public static final String PREFS = "chess_helper";
    public static final String PREF_KEY = "gemini_key";
    private static final String CHANNEL_ID = "chess_helper";
    private static final int NOTIF_ID = 7;
    public static volatile boolean running;

    private static final int GREEN = Color.rgb(0, 224, 0);
    private static final int YELLOW = Color.rgb(255, 212, 0);
    private static final int ARROW = 0xDD00E000;
    private static final int BG = 0xFF1F2430, BAR = 0xFF11151C, FG = 0xFFE8E8E8, BTN = 0xFF323A4D;

    private static final String[] LEVEL_NAMES = {"Predictable", "Balanced", "Wild"};
    private static final int[] LEVEL_MARGIN = {1, 45, 90};
    private static final int[] LEVEL_TEMP = {1, 22, 45};
    private static final int[] THINK_SECONDS = {1, 2, 3, 5, 8};
    private static final int TICK_MS = 450;

    private WindowManager wm;
    private Handler ui;
    private ExecutorService netExec, engineExec;
    private HandlerThread frameThread;

    // screen capture
    private MediaProjection projection;
    private ImageReader imageReader;
    private VirtualDisplay virtualDisplay;
    private int screenW, screenH;
    private final Object frameLock = new Object();
    private Image heldImage;

    // views
    private LinearLayout panel, bodyView;
    private WindowManager.LayoutParams panelParams;
    private TextView statusView, targetView, detailsView, modelView, btnSide, btnAuto, btnLevel, btnThink, btnCoord;
    private FrameBox greenBox, yellowBox;
    private ArrowLayer arrow;
    private SelectView selectView;
    private int overlayDx, overlayDy;          // correction between requested and real window position
    private boolean offsetChecked;

    // game state (UI thread only)
    private final GameTracker tracker = new GameTracker(true);
    private volatile GeminiClient client;
    private String clientKey = "";
    private int[] region;                      // board rectangle on screen: left, top, w, h
    private boolean regionRefined;
    private boolean myWhite = true, auto, busy, forceMine;
    private boolean autoRegion;                // the board rectangle was found by Gemini (not dragged by hand)
    private boolean manualMode;
    private ManualBoardView manualView;
    private LinearLayout manualBox;
    private TextView btnManual;
    private final List<Position> manualHistory = new ArrayList<>();
    private int detectTry;
    private long blankUntil;
    private boolean coordMode = true;          // show best / wild / worst as coordinates
    private boolean orientAuto = true;         // work out "My pieces" from the picture
    private int detectFails, redetects;
    private long nextDetectAt;
    private LinearLayout settingsBox;
    private int levelIdx = 1, thinkIdx = 1;
    private int job;                           // bumps whenever work is cancelled / restarted
    private float[] ref, pending;              // board look at the last accepted state / a possible new state
    private int stable, errorStreak;
    private boolean needFirstRead, captureRefNext;
    private long settleAt;
    private char[] pendingBoard;               // a surprising reading waiting for a second opinion
    private String shownKey;
    private Engine.Result lastResult;
    private String lastResultKey;
    private AtomicBoolean cancelFlag;

    private static final class Frame {
        final int[] px;
        final int w, h;

        Frame(int[] px, int w, int h) {
            this.px = px;
            this.w = w;
            this.h = h;
        }
    }

    // ================================================================== lifecycle
    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        ui = new Handler(Looper.getMainLooper());
        netExec = Executors.newSingleThreadExecutor();
        engineExec = Executors.newSingleThreadExecutor();
        frameThread = new HandlerThread("chess-frames");
        frameThread.start();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressWarnings("deprecation")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running || intent == null) return START_NOT_STICKY;
        try {
            createChannel();
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIF_ID, n);
            }
            int code = intent.getIntExtra(EXTRA_CODE, 0);
            Intent data = intent.getParcelableExtra(EXTRA_DATA);
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    ui.post(() -> stopSelf());
                }
            }, ui);
            setupCapture();
            buildUi();
            loadConfig();
            running = true;
        } catch (Exception e) {
            Toast.makeText(this, "Chess Helper could not start: " + e.getMessage(), Toast.LENGTH_LONG).show();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        auto = false;
        ui.removeCallbacksAndMessages(null);
        cancelAll();
        try {
            if (greenBox != null) greenBox.hide();
            if (yellowBox != null) yellowBox.hide();
            if (arrow != null) arrow.hide();
            if (selectView != null) removeQuietly(selectView);
            if (panel != null) removeQuietly(panel);
        } catch (Exception ignored) {
        }
        synchronized (frameLock) {
            if (heldImage != null) heldImage.close();
            heldImage = null;
        }
        if (virtualDisplay != null) virtualDisplay.release();
        if (imageReader != null) imageReader.close();
        if (projection != null) projection.stop();
        netExec.shutdownNow();
        engineExec.shutdownNow();
        frameThread.quitSafely();
        super.onDestroy();
    }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Chess Helper",
                NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification.Action action = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", pi).build();
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Chess Helper is running")
                .setContentText("Open your chess game. Tap Stop to close the helper.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .addAction(action)
                .setOngoing(true)
                .build();
    }

    // ================================================================== screen capture
    @SuppressWarnings("deprecation")
    private void setupCapture() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 3);
        imageReader.setOnImageAvailableListener(r -> {
            Image img = null;
            try {
                img = r.acquireLatestImage();
            } catch (Exception ignored) {
            }
            if (img == null) return;
            synchronized (frameLock) {
                if (heldImage != null) heldImage.close();
                heldImage = img;                   // keep only the newest frame
            }
        }, new Handler(frameThread.getLooper()));
        virtualDisplay = projection.createVirtualDisplay("ChessHelper", screenW, screenH, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, null);
    }

    /** Copies a rectangle of the newest screen frame into ARGB pixels (null if there is no frame yet). */
    private Frame grabRegion(int l, int t, int w, int h) {
        synchronized (frameLock) {
            if (heldImage == null) return null;
            Image.Plane plane = heldImage.getPlanes()[0];
            ByteBuffer buf = plane.getBuffer();
            int rowStride = plane.getRowStride(), pixStride = plane.getPixelStride();
            int iw = heldImage.getWidth(), ih = heldImage.getHeight();
            l = Math.max(0, l);
            t = Math.max(0, t);
            w = Math.min(w, iw - l);
            h = Math.min(h, ih - t);
            if (w <= 0 || h <= 0) return null;
            int[] out = new int[w * h];
            for (int y = 0; y < h; y++) {
                int base = (t + y) * rowStride + l * pixStride;
                for (int x = 0; x < w; x++) {
                    int i = base + x * pixStride;
                    int r = buf.get(i) & 0xFF, g = buf.get(i + 1) & 0xFF, b = buf.get(i + 2) & 0xFF;
                    out[y * w + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
                }
            }
            return new Frame(out, w, h);
        }
    }

    /** JPEG of a board picture, at most 768 px on the long side (small and fast to send). */
    private static byte[] encodeJpeg(Frame f) {
        return encodeJpeg(f, 768, 88);
    }

    private static byte[] encodeJpeg(Frame f, int max, int quality) {
        Bitmap bmp = Bitmap.createBitmap(f.px, f.w, f.h, Bitmap.Config.ARGB_8888);
        if (Math.max(f.w, f.h) > max) {
            float s = max / (float) Math.max(f.w, f.h);
            bmp = Bitmap.createScaledBitmap(bmp, Math.round(f.w * s), Math.round(f.h * s), true);
        }
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, quality, bos);
        return bos.toByteArray();
    }

    // ================================================================== UI building
    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private TextView makeButton(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(FG);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(10), dp(6), dp(10));
        t.setBackground(rounded(BTN, dp(8)));
        t.setClickable(true);
        t.setOnClickListener(l);
        return t;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(4);
        r.setLayoutParams(lp);
        return r;
    }

    private void addWeighted(LinearLayout row, View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(2);
        lp.rightMargin = dp(2);
        row.addView(v, lp);
    }

    private TextView smallText(int color, float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setTextColor(color);
        t.setTextSize(sp);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private void buildUi() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(rounded(BG, dp(14)));

        // ---- title bar (drag handle) ----
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(rounded(BAR, dp(14)));
        TextView title = smallText(GREEN, 15, true);
        title.setText("♞  Chess Helper");
        title.setPadding(dp(12), dp(8), dp(8), dp(8));
        bar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView gear = smallText(0xFFAAB0C0, 17, false);
        gear.setText("⚙");
        gear.setPadding(dp(12), dp(4), dp(10), dp(4));
        gear.setOnClickListener(v -> settingsBox.setVisibility(
                settingsBox.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        bar.addView(gear);
        TextView collapse = smallText(0xFFAAB0C0, 20, false);
        collapse.setText("–");
        collapse.setPadding(dp(14), dp(4), dp(14), dp(4));
        collapse.setOnClickListener(v ->
                bodyView.setVisibility(bodyView.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        bar.addView(collapse);
        TextView close = smallText(0xFFAAB0C0, 18, false);
        close.setText("✕");
        close.setPadding(dp(14), dp(4), dp(14), dp(4));
        close.setOnClickListener(v -> stopSelf());
        bar.addView(close);
        bar.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = panelParams.x;
                        sy = panelParams.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelParams.x = sx + (int) (e.getRawX() - tx);
                        panelParams.y = sy + (int) (e.getRawY() - ty);
                        wm.updateViewLayout(panel, panelParams);
                        return true;
                    default:
                        return false;
                }
            }
        });
        panel.addView(bar);

        // ---- body ----
        bodyView = new LinearLayout(this);
        bodyView.setOrientation(LinearLayout.VERTICAL);
        bodyView.setPadding(dp(10), dp(6), dp(10), dp(10));
        panel.addView(bodyView);

        statusView = smallText(FG, 13, true);
        statusView.setText("Open your chess game, then tap Auto Hint to turn it ON. I find the board by myself.");
        bodyView.addView(statusView);

        LinearLayout r1 = row();
        btnAuto = makeButton("", v -> toggleAuto());
        addWeighted(r1, btnAuto);
        addWeighted(r1, makeButton("Suggest now", v -> suggestNow()));
        bodyView.addView(r1);
        LinearLayout r1b = row();
        btnCoord = makeButton("", v -> {
            coordMode = !coordMode;
            lastResult = null;                         // recompute so the extra moves exist
            lastResultKey = null;
            refreshButtons();
            saveConfig();
            setStatus(coordMode ? "Coordinate mode ON: best / wild / worst moves as coordinates."
                    : "Coordinate mode OFF.");
        });
        addWeighted(r1b, btnCoord);
        bodyView.addView(r1b);
        LinearLayout r1c = row();
        btnManual = makeButton("", v -> setManual(!manualMode));
        addWeighted(r1c, btnManual);
        bodyView.addView(r1c);

        manualBox = new LinearLayout(this);
        manualBox.setOrientation(LinearLayout.VERTICAL);
        manualBox.setVisibility(View.GONE);
        manualView = new ManualBoardView(this);
        LinearLayout.LayoutParams mlp = new LinearLayout.LayoutParams(dp(250), dp(250));
        mlp.topMargin = dp(6);
        mlp.gravity = Gravity.CENTER_HORIZONTAL;
        manualBox.addView(manualView, mlp);
        LinearLayout rm = row();
        addWeighted(rm, makeButton("Undo move", v -> manualUndo()));
        addWeighted(rm, makeButton("Reset", v -> manualReset()));
        manualBox.addView(rm);
        bodyView.addView(manualBox);

        targetView = smallText(0xFFC9FFC9, 15, true);
        targetView.setText("The GREEN box and arrow will show\nwhere to place the piece");
        targetView.setGravity(Gravity.CENTER);
        targetView.setPadding(dp(8), dp(8), dp(8), dp(8));
        GradientDrawable tbg = rounded(0xFF0B3D0B, dp(10));
        tbg.setStroke(dp(2), GREEN);
        targetView.setBackground(tbg);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = dp(6);
        bodyView.addView(targetView, tlp);

        detailsView = smallText(0xFFC8CDD8, 11, false);
        bodyView.addView(detailsView);

        // ---- settings (tap the gear in the title bar) ----
        settingsBox = new LinearLayout(this);
        settingsBox.setOrientation(LinearLayout.VERTICAL);
        settingsBox.setVisibility(View.GONE);
        LinearLayout r2 = row();
        btnSide = makeButton("", v -> toggleSide());
        btnLevel = makeButton("", v -> {
            levelIdx = (levelIdx + 1) % LEVEL_NAMES.length;
            refreshButtons();
            saveConfig();
        });
        addWeighted(r2, btnSide);
        addWeighted(r2, btnLevel);
        settingsBox.addView(r2);
        LinearLayout r3 = row();
        btnThink = makeButton("", v -> {
            thinkIdx = (thinkIdx + 1) % THINK_SECONDS.length;
            refreshButtons();
            saveConfig();
        });
        addWeighted(r3, btnThink);
        addWeighted(r3, makeButton("① Select board", v -> selectBoard()));
        settingsBox.addView(r3);
        LinearLayout r4 = row();
        addWeighted(r4, makeButton("Hide boxes", v -> hideBoxes()));
        addWeighted(r4, makeButton("New game", v -> newGame()));
        settingsBox.addView(r4);
        modelView = smallText(0xFF7F8AA3, 10, false);
        settingsBox.addView(modelView);
        bodyView.addView(settingsBox);

        refreshButtons();
        greenBox = new FrameBox(GREEN);
        yellowBox = new FrameBox(YELLOW);
        arrow = new ArrowLayer();

        panelParams = new WindowManager.LayoutParams(dp(270), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = dp(10);
        panelParams.y = (int) (screenH * 0.55f);
        wm.addView(panel, panelParams);
    }

    private void refreshButtons() {
        btnSide.setText("My pieces: " + (myWhite ? "White" : "Black"));
        btnAuto.setText(auto ? "Auto Hint: ON" : "Auto Hint: OFF");
        btnAuto.setTextColor(auto ? GREEN : FG);
        btnManual.setText(manualMode ? "Manual board: ON" : "Manual board: OFF");
        btnManual.setTextColor(manualMode ? GREEN : FG);
        btnCoord.setText(coordMode ? "Coordinate mode: ON" : "Coordinate mode: OFF");
        btnCoord.setTextColor(coordMode ? GREEN : FG);
        btnLevel.setText("Surprise: " + LEVEL_NAMES[levelIdx]);
        btnThink.setText("Think: " + THINK_SECONDS[thinkIdx] + "s");
    }

    private void setStatus(String s) {
        statusView.setText(s);
    }

    private void removeQuietly(View v) {
        try {
            wm.removeViewImmediate(v);
        } catch (Exception ignored) {
        }
    }

    // ================================================================== overlay boxes + arrow
    /** A hollow coloured rectangle drawn with four thin windows, so the square stays tappable. */
    private final class FrameBox {
        private final View[] views = new View[4];
        private final WindowManager.LayoutParams[] lps = new WindowManager.LayoutParams[4];
        private final boolean[] attached = new boolean[4];
        private int[] last;                                  // x, y, w, h, thickness of the last show()

        FrameBox(int color) {
            for (int i = 0; i < 4; i++) {
                views[i] = new View(OverlayService.this);
                views[i].setBackgroundColor(color);
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(10, 10,
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                        PixelFormat.OPAQUE);
                lp.gravity = Gravity.TOP | Gravity.START;
                if (Build.VERSION.SDK_INT >= 28) {
                    lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                }
                lps[i] = lp;
            }
        }

        void reshow() {
            if (last != null && attached[0]) show(last[0], last[1], last[2], last[3], last[4]);
        }

        void show(final int x, final int y, final int w, final int h, final int t) {
            last = new int[]{x, y, w, h, t};
            final int[][] g = {{x, y, w, t}, {x, y + h - t, w, t}, {x, y, t, h}, {x + w - t, y, t, h}};
            for (int i = 0; i < 4; i++) {
                lps[i].x = g[i][0] + overlayDx;
                lps[i].y = g[i][1] + overlayDy;
                lps[i].width = g[i][2];
                lps[i].height = g[i][3];
                try {
                    if (!attached[i]) {
                        wm.addView(views[i], lps[i]);
                        attached[i] = true;
                    } else {
                        wm.updateViewLayout(views[i], lps[i]);
                    }
                } catch (Exception ignored) {
                }
            }
            if (!offsetChecked) {
                // Some phones place overlay windows below the status bar / cutout. Measure where the
                // first edge really landed once, remember the difference, and redraw there.
                offsetChecked = true;
                final View first = views[0];
                first.postDelayed(() -> {
                    if (!attached[0]) return;
                    int[] loc = new int[2];
                    first.getLocationOnScreen(loc);
                    int fixX = (g[0][0] + overlayDx) - loc[0];
                    int fixY = (g[0][1] + overlayDy) - loc[1];
                    if (fixX != 0 || fixY != 0) {
                        overlayDx += fixX;
                        overlayDy += fixY;
                        greenBox.reshow();
                        yellowBox.reshow();
                        arrow.reshow();
                    }
                }, 150);
            }
        }

        void hide() {
            for (int i = 0; i < 4; i++) {
                if (attached[i]) {
                    removeQuietly(views[i]);
                    attached[i] = false;
                }
            }
        }
    }

    /** Draws the arrow from the piece's square to the target square. */
    private final class ArrowView extends View {
        private final Paint line = new Paint(), fill = new Paint();
        private final Path head = new Path();
        private float fx, fy, tx, ty, sq;

        ArrowView(Context c) {
            super(c);
            line.setAntiAlias(true);
            line.setColor(ARROW);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeCap(Paint.Cap.ROUND);
            fill.setAntiAlias(true);
            fill.setColor(ARROW);
            fill.setStyle(Paint.Style.FILL);
        }

        void setArrow(float fx, float fy, float tx, float ty, float sq) {
            this.fx = fx;
            this.fy = fy;
            this.tx = tx;
            this.ty = ty;
            this.sq = sq;
            invalidate();
        }

        @Override
        protected void onDraw(Canvas c) {
            float dx = tx - fx, dy = ty - fy;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len < 1f) return;
            float ux = dx / len, uy = dy / len;
            float headLen = sq * 0.45f, headHalf = sq * 0.27f;
            float bx = tx - ux * headLen, by = ty - uy * headLen;           // base of the arrow head
            float sx = fx + ux * sq * 0.28f, sy = fy + uy * sq * 0.28f;     // start just off the piece
            line.setStrokeWidth(sq * 0.13f);
            c.drawLine(sx, sy, bx, by, line);
            head.reset();
            head.moveTo(tx, ty);
            head.lineTo(bx - uy * headHalf, by + ux * headHalf);
            head.lineTo(bx + uy * headHalf, by - ux * headHalf);
            head.close();
            c.drawPath(head, fill);
        }
    }

    /** A see-through window the size of the board that carries the arrow. */
    private final class ArrowLayer {
        private final ArrowView view = new ArrowView(OverlayService.this);
        private final WindowManager.LayoutParams lp;
        private boolean attached;
        private int[] lastRegion;
        private float[] lastArrow;

        ArrowLayer() {
            lp = new WindowManager.LayoutParams(10, 10, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            if (Build.VERSION.SDK_INT >= 28) {
                lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            }
        }

        void reshow() {
            if (attached && lastRegion != null && lastArrow != null) {
                show(lastRegion, lastArrow[0], lastArrow[1], lastArrow[2], lastArrow[3], lastArrow[4]);
            }
        }

        /** Coordinates are screen pixels; the window itself covers the board region. */
        void show(int[] reg, float fx, float fy, float tx, float ty, float sq) {
            lastRegion = reg.clone();
            lastArrow = new float[]{fx, fy, tx, ty, sq};
            lp.x = reg[0] + overlayDx;
            lp.y = reg[1] + overlayDy;
            lp.width = reg[2];
            lp.height = reg[3];
            view.setArrow(fx - reg[0], fy - reg[1], tx - reg[0], ty - reg[1], sq);
            try {
                if (!attached) {
                    wm.addView(view, lp);
                    attached = true;
                } else {
                    wm.updateViewLayout(view, lp);
                }
            } catch (Exception ignored) {
            }
        }

        void hide() {
            if (attached) {
                removeQuietly(view);
                attached = false;
            }
        }
    }

    private void hideBoxes() {
        if (greenBox != null) greenBox.hide();
        if (yellowBox != null) yellowBox.hide();
        if (arrow != null) arrow.hide();
    }

    // ================================================================== select the board (once)
    /** Full-screen translucent layer: drag a rectangle around the board. */
    private final class SelectView extends View {
        private final Paint fill = new Paint(), line = new Paint(), text = new Paint();
        private float x0, y0, x1, y1;
        private float rawX0, rawY0;
        private boolean dragging;

        SelectView(Context c) {
            super(c);
            fill.setColor(0x2200E000);
            line.setColor(GREEN);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(dp(3));
            text.setColor(GREEN);
            text.setTextSize(dp(16));
            text.setFakeBoldText(true);
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawColor(0x77000000);
            c.drawText("Drag a rectangle around the 64 squares", dp(16), dp(90), text);
            c.drawText("(only the squares, as tight as you can)", dp(16), dp(115), text);
            c.drawText("(a quick tap cancels)", dp(16), dp(140), text);
            if (dragging) {
                c.drawRect(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1), Math.max(y0, y1), fill);
                c.drawRect(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1), Math.max(y0, y1), line);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    x0 = x1 = e.getX();
                    y0 = y1 = e.getY();
                    rawX0 = e.getRawX();
                    rawY0 = e.getRawY();
                    dragging = true;
                    invalidate();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    x1 = e.getX();
                    y1 = e.getY();
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                    dragging = false;
                    int l = (int) Math.min(rawX0, e.getRawX()), r = (int) Math.max(rawX0, e.getRawX());
                    int t = (int) Math.min(rawY0, e.getRawY()), b = (int) Math.max(rawY0, e.getRawY());
                    finishSelection(l, t, r - l, b - t);
                    return true;
                default:
                    return true;
            }
        }
    }

    private void selectBoard() {
        if (selectView != null) return;
        auto = false;
        cancelAll();
        hideBoxes();
        refreshButtons();
        ui.removeCallbacks(tick);
        panel.setVisibility(View.GONE);
        selectView = new SelectView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        wm.addView(selectView, lp);
    }

    private void finishSelection(int l, int t, int w, int h) {
        removeQuietly(selectView);
        selectView = null;
        panel.setVisibility(View.VISIBLE);
        if (w < dp(120) || h < dp(120)) {
            setStatus("Selection cancelled (too small). Tap ① to try again.");
            return;
        }
        region = new int[]{l, t, w, h};
        regionRefined = false;
        autoRegion = false;
        ref = null;
        lastResult = null;
        lastResultKey = null;
        tracker.reset();
        saveConfig();
        setStatus("Board selected ✔\nNow tap Auto Hint.");
        movePanelAwayFromBoard();
    }

    private boolean panelOverlapsBoard() {
        if (region == null || panel.getVisibility() != View.VISIBLE) return false;
        int[] loc = new int[2];
        panel.getLocationOnScreen(loc);
        int pl = loc[0], pt = loc[1], pr = pl + panel.getWidth(), pb = pt + panel.getHeight();
        return pl < region[0] + region[2] && pr > region[0] && pt < region[1] + region[3] && pb > region[1];
    }

    // ================================================================== buttons
    private boolean ensureClient() {
        String key = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_KEY, "");
        if (key == null || key.trim().isEmpty()) {
            setStatus("No Gemini API key yet. Open the Chess Helper app, paste your key and tap Save.");
            return false;
        }
        key = key.trim();
        if (client == null || !key.equals(clientKey)) {
            client = new GeminiClient(key, GeminiClient.DEFAULT_BASE, GeminiClient.DEFAULT_MODELS);
            clientKey = key;
        }
        return true;
    }

    private void toggleSide() {
        myWhite = !myWhite;
        orientAuto = false;                            // you chose it yourself: stop guessing
        tracker.myWhite = myWhite;
        resetTracking();
        refreshButtons();
        if (manualMode) manualReset();
        setStatus("Now I help " + (myWhite ? "White" : "Black") + " (the pieces at the bottom of your screen).");
        saveConfig();
    }

    private void resetTracking() {
        cancelAll();
        tracker.myWhite = myWhite;
        tracker.reset();
        lastResult = null;
        lastResultKey = null;
        shownKey = null;
        ref = null;
        if (auto) needFirstRead = true;
    }

    private void toggleAuto() {
        ui.removeCallbacks(tick);
        if (!auto) {
            if (manualMode) setManual(false);
            if (!ensureClient()) return;
            auto = true;
            detectTry = 0;
            blankUntil = 0;
            cancelAll();
            ref = null;
            detectFails = 0;
            redetects = 0;
            nextDetectAt = 0;
            if (region == null || autoRegion) {            // find the board again (the game may have moved)
                region = null;
                autoRegion = true;
                needFirstRead = false;
                setStatus("Auto Hint is ON. Looking for the chess board…");
            } else {
                needFirstRead = true;
                regionRefined = false;
                setStatus("Auto Hint is ON. Reading the board…");
            }
            ui.post(tick);
        } else {
            auto = false;
            cancelAll();
            hideBoxes();
            setPanelHidden(false);
            setStatus("Auto Hint is OFF.");
        }
        refreshButtons();
    }

    private void suggestNow() {
        if (manualMode) {
            manualAfterMove();
            return;
        }
        if (!ensureClient()) return;
        cancelAll();
        forceMine = true;
        if (region == null) {
            autoRegion = true;
            startDetect();
        } else {
            startRead(0);
        }
    }

    private void newGame() {
        resetTracking();
        hideBoxes();
        if (manualMode) manualReset();
        targetView.setText("The GREEN box and arrow will show\nwhere to place the piece");
        detailsView.setText("");
        orientAuto = true;
        setStatus(auto ? "New game. Looking at the board…" : "Tracking reset. Tap Auto Hint.");
    }

    private void cancelAll() {
        job++;
        busy = false;
        forceMine = false;
        pendingBoard = null;
        errorStreak = 0;
        if (cancelFlag != null) cancelFlag.set(true);
    }

    // ================================================================== watching the screen
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!auto) return;
            if (!busy && region != null) {
                final int[] reg = region.clone();
                final int myJob = job;
                netExec.execute(() -> {
                    float[] sig = null;
                    try {
                        Frame f = grabRegion(reg[0], reg[1], reg[2], reg[3]);
                        if (f != null && f.w == reg[2] && f.h == reg[3]) {
                            sig = ChangeDetector.signature(f.px, f.w, f.h);
                        }
                    } catch (Exception ignored) {
                    }
                    final float[] s = sig;
                    ui.post(() -> {
                        if (myJob == job) onFrame(s);
                    });
                });
            } else if (!busy && region == null && System.currentTimeMillis() >= nextDetectAt) {
                startDetect();
            }
            ui.postDelayed(this, TICK_MS);
        }
    };

    private void onFrame(float[] sig) {
        if (sig == null || busy || !auto) return;
        if (needFirstRead) {
            if (System.currentTimeMillis() < blankUntil) return;
            needFirstRead = false;
            ref = sig;
            startRead(0);
            return;
        }
        if (captureRefNext) {                          // our own boxes just appeared: take that as "unchanged"
            if (System.currentTimeMillis() < settleAt) return;
            captureRefNext = false;
            ref = sig;
            pending = null;
            stable = 0;
            return;
        }
        if (ref == null) {
            ref = sig;
            return;
        }
        if (ChangeDetector.changedSquares(sig, ref) == 0) {
            pending = null;
            stable = 0;
            return;
        }
        if (pending != null && ChangeDetector.changedSquares(sig, pending) == 0) stable++;
        else {
            pending = sig;
            stable = 1;
        }
        if (stable >= 2) startRead(0);                 // board changed and stopped moving
    }

    // ================================================================== reading with Gemini
    /** Rough board rectangle -> exact grid. null when it can't be improved safely. */
    private int[] tryRefine(int[] reg) {
        try {
            int mx = reg[2] / 16, my = reg[3] / 16;
            int l = Math.max(0, reg[0] - mx), t = Math.max(0, reg[1] - my);
            Frame big = grabRegion(l, t, reg[2] + (reg[0] - l) + mx, reg[3] + (reg[1] - t) + my);
            if (big == null) return null;
            int ax = reg[0] - l, ay = reg[1] - t;
            if (ax + reg[2] > big.w || ay + reg[3] > big.h) return null;
            int[] r = BoardGeometry.refineBoard(big.px, big.w, big.h, ax, ay, reg[2], reg[3]);
            if (r[0] < 0 || r[1] < 0 || r[0] + r[2] > big.w || r[1] + r[3] > big.h) return null;
            if (Math.abs(r[2] - reg[2]) > 0.12 * reg[2] || Math.abs(r[3] - reg[3]) > 0.12 * reg[3]) return null;
            if (Math.abs(r[2] - r[3]) > 0.04 * Math.max(r[2], r[3])) return null;
            return new int[]{l + r[0], t + r[1], r[2], r[3]};
        } catch (Exception e) {
            return null;
        }
    }

    private void startRead(final int attempt) {
        if (!ensureClient()) {
            busy = false;
            auto = false;
            refreshButtons();
            return;
        }
        busy = true;
        final int myJob = ++job;
        hideBoxes();                                   // so Gemini and the change detector see a clean board
        setStatus(attempt == 0 ? "Reading the board with Gemini…" : "Double-checking the board…");
        setPanelHidden(true);
        ui.postDelayed(() -> {
            if (myJob != job || region == null) {
                setPanelHidden(false);
                return;
            }
            final int[] reg = region.clone();
            final boolean doRefine = !regionRefined;
            final GeminiClient cl = client;
            netExec.execute(() -> {
                int[] refined = doRefine ? tryRefine(reg) : null;
                final int[] use = refined != null ? refined : reg;
                Frame f = grabRegion(use[0], use[1], use[2], use[3]);
                ui.post(() -> setPanelHidden(false));
                if (f == null || f.w != use[2] || f.h != use[3]) {
                    ui.post(() -> {
                        if (myJob != job) return;
                        setStatus("No screen picture yet. Retrying…");
                        ui.postDelayed(() -> {
                            if (myJob == job) startRead(attempt);
                        }, 1500);
                    });
                    return;
                }
                if (BoardGeometry.isBlankScreen(f.px, f.w, f.h, 0)) {
                    ui.post(() -> {
                        if (myJob != job) return;
                        busy = false;
                        ref = null;
                        needFirstRead = true;
                        blankUntil = System.currentTimeMillis() + 3000;
                        setStatus("The screen looks BLACK to me: this chess app blocks screen capture (it is protected), so I can't see the board. Tap Manual board below to use the helper without reading the screen.");
                    });
                    return;
                }
                final float[] sig = ChangeDetector.signature(f.px, f.w, f.h);
                GeminiClient.Reading rd = null;
                GeminiClient.GeminiException err = null;
                try {
                    rd = cl.readBoard(encodeJpeg(f));
                } catch (GeminiClient.GeminiException e) {
                    err = e;
                } catch (Exception e) {
                    err = new GeminiClient.GeminiException("Unexpected problem: " + e, false, 5);
                }
                final GeminiClient.Reading reading = rd;
                final GeminiClient.GeminiException error = err;
                final int[] newRegion = refined;
                ui.post(() -> {
                    if (myJob != job) return;
                    if (doRefine) {
                        regionRefined = true;
                        if (newRegion != null) {
                            region = newRegion;
                            saveConfig();
                        }
                    }
                    onReading(reading, error, sig, attempt, myJob);
                });
            });
        }, 350);
    }

    private void onGeminiError(GeminiClient.GeminiException e, int myJob) {
        String msg = e.getMessage() == null ? "" : e.getMessage();
        if (msg.length() > 140) msg = msg.substring(0, 140) + "…";
        if (e.fatal) {
            busy = false;
            auto = false;
            ui.removeCallbacks(tick);
            refreshButtons();
            setStatus("⚠ " + msg);
            return;
        }
        errorStreak++;
        if (errorStreak >= 4) {
            busy = false;
            ref = null;
            errorStreak = 0;
            nextDetectAt = System.currentTimeMillis() + 15000;
            setStatus("Reading failed several times: " + msg + "\nTap Suggest now to try again.");
            return;
        }
        final int wait = Math.max(3, e.waitSeconds);
        setStatus("Gemini: " + msg + "\nTrying again in " + wait + " s…");
        ui.postDelayed(() -> {
            if (myJob != job) return;
            if (region == null) startDetect();
            else startRead(0);
        }, wait * 1000L);
    }

    private void onReading(GeminiClient.Reading r, GeminiClient.GeminiException err, float[] sig, int attempt,
                           int myJob) {
        if (err != null) {
            onGeminiError(err, myJob);
            return;
        }
        errorStreak = 0;
        StringBuilder dbg = new StringBuilder("Read by " + r.model + " in " + (r.millis / 100) / 10.0 + " s\n");
        for (int i = 0; i < r.rows.length; i++) dbg.append(i > 0 ? "/" : "").append(r.rows[i].replace(' ', '.'));
        modelView.setText(dbg.toString());
        int side = BoardGeometry.whiteAtBottom(r.rows);              // +1 white, -1 black, 0 unknown
        if (side != 0 && (orientAuto || BoardGeometry.isStartPosition(r.rows)) && (side > 0) != myWhite) {
            myWhite = side > 0;
            tracker.myWhite = myWhite;
            tracker.reset();
            lastResult = null;
            lastResultKey = null;
            refreshButtons();
            saveConfig();
        }
        orientAuto = false;                                          // guess once per game
        char[] board = BoardGeometry.rowsToBoard(r.rows, !myWhite);
        boolean legal = board != null
                && (GameTracker.validBoard(board, myWhite) || GameTracker.validBoard(board, !myWhite));
        if (!legal) {
            if (attempt < 2) {
                startRead(attempt + 1);
                return;
            }
            if (autoRegion && auto && redetects < 2) {   // maybe the board moved: look for it again
                redetects++;
                busy = false;
                region = null;
                ref = null;
                nextDetectAt = 0;
                setStatus("The board looks unclear. Looking for it again…");
                return;
            }
            busy = false;
            ref = sig;
            setStatus(panelOverlapsBoard() ? "I'm covering the board. Drag me off it."
                    : "I can't read a legal position. Open the game so the whole board is visible, "
                    + "or tap the gear ⚙ and ① Select board.");
            return;
        }
        if (!tracker.reachable(board)) {
            if (pendingBoard != null && Arrays.equals(pendingBoard, board)) {
                pendingBoard = null;                   // two identical readings: believe it
            } else if (attempt < 3) {
                pendingBoard = board;                  // surprising: ask once more before accepting
                startRead(attempt + 1);
                return;
            }
        } else {
            pendingBoard = null;
        }
        String res = tracker.update(board);
        pendingBoard = null;
        if (res.equals("invalid")) {
            busy = false;
            ref = sig;
            setStatus("That doesn't look like a legal chess position.");
            return;
        }
        if (res.equals("resync")) tracker.applyTurnHint(r.turn);
        redetects = 0;
        ref = sig;
        pending = null;
        stable = 0;
        afterPosition(myJob);
    }

    // ================================================================== manual board (for apps that block capture)
    private void setManual(boolean on) {
        if (on == manualMode) return;
        manualMode = on;
        if (on) {
            auto = false;
            ui.removeCallbacks(tick);
            cancelAll();
            hideBoxes();
            setPanelHidden(false);
            manualBox.setVisibility(View.VISIBLE);
            manualReset();
        } else {
            cancelAll();
            manualBox.setVisibility(View.GONE);
            setStatus("Manual board is OFF.");
        }
        refreshButtons();
    }

    private void manualReset() {
        cancelAll();
        tracker.myWhite = myWhite;
        tracker.reset();
        manualHistory.clear();
        lastResult = null;
        lastResultKey = null;
        manualView.clearSelection();
        manualAfterMove();
    }

    private void manualUndo() {
        if (manualHistory.isEmpty() || tracker.keys.size() < 2) return;
        cancelAll();
        tracker.pos = manualHistory.remove(manualHistory.size() - 1);
        tracker.keys.remove(tracker.keys.size() - 1);
        lastResult = null;
        lastResultKey = null;
        manualView.clearSelection();
        manualAfterMove();
    }

    private void manualPlay(int from, int to) {
        Position pos = tracker.pos;
        int chosen = -1;
        for (int m : Rules.legalMoves(pos)) {
            if (Move.from(m) == from && Move.to(m) == to && (Move.promo(m) == 0 || Move.promo(m) == 'Q')) chosen = m;
        }
        if (chosen < 0) return;
        cancelAll();
        manualHistory.add(pos);
        tracker.pos = Rules.apply(pos, chosen);
        tracker.keys.add(tracker.pos.key());
        lastResult = null;
        lastResultKey = null;
        manualAfterMove();
    }

    private void manualAfterMove() {
        manualView.invalidate();
        Position pos = tracker.pos;
        String end = Rules.outcome(pos, tracker.keys, null);
        if (end != null) {
            setStatus(end);
            return;
        }
        if (pos.white != myWhite) {
            setStatus("Opponent's turn: tap the piece they moved, then its new square.");
            targetView.setText("Waiting for the opponent's move");
            detailsView.setText("");
            return;
        }
        busy = true;
        setStatus("Your turn - thinking…");
        requestSuggestion(job);
    }

    private final class ManualBoardView extends View {
        private final Paint p = new Paint(), t = new Paint();
        private int sel = -1;
        private int[] targets = new int[0];

        ManualBoardView(Context c) {
            super(c);
            p.setAntiAlias(true);
            t.setAntiAlias(true);
            t.setTextAlign(Paint.Align.CENTER);
        }

        void clearSelection() {
            sel = -1;
            targets = new int[0];
            invalidate();
        }

        private int squareAt(int r, int c) {
            return BoardGeometry.imgIndex(r * 8 + c, !myWhite);
        }

        @Override
        protected void onDraw(Canvas cv) {
            float cell = getWidth() / 8f;
            Position pos = tracker.pos;
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
                    int sq = squareAt(r, c);
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(((r + c) & 1) == 0 ? 0xFFEEEED2 : 0xFF769656);
                    cv.drawRect(c * cell, r * cell, (c + 1) * cell, (r + 1) * cell, p);
                    if (sq == sel) {
                        p.setColor(0xAAFFD400);
                        cv.drawRect(c * cell, r * cell, (c + 1) * cell, (r + 1) * cell, p);
                    }
                    char ch = pos.b[sq];
                    if (ch != '.') {
                        String g = Texts.glyph(Character.toUpperCase(ch));
                        t.setTextSize(cell * 0.82f);
                        float cx = c * cell + cell / 2f, cy = r * cell + cell * 0.76f;
                        boolean white = Rules.isWhite(ch);
                        t.setStyle(Paint.Style.STROKE);
                        t.setStrokeWidth(cell * 0.06f);
                        t.setColor(white ? 0xFF222222 : 0xFFFFFFFF);
                        cv.drawText(g, cx, cy, t);
                        t.setStyle(Paint.Style.FILL);
                        t.setColor(white ? 0xFFFFFFFF : 0xFF111111);
                        cv.drawText(g, cx, cy, t);
                    }
                    for (int tg : targets) {
                        if (tg == sq) {
                            p.setColor(0xCC00E000);
                            cv.drawCircle(c * cell + cell / 2f, r * cell + cell / 2f, cell * 0.17f, p);
                        }
                    }
                }
            }
            t.setStyle(Paint.Style.FILL);
            t.setTextSize(cell * 0.24f);
            t.setColor(0xFF33442A);
            for (int i = 0; i < 8; i++) {                                // coordinate letters / numbers
                String file = String.valueOf((char) ('a' + (myWhite ? i : 7 - i)));
                String rank = String.valueOf(myWhite ? 8 - i : i + 1);
                cv.drawText(file, i * cell + cell * 0.82f, 8 * cell - cell * 0.06f, t);
                cv.drawText(rank, cell * 0.14f, i * cell + cell * 0.27f, t);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() == MotionEvent.ACTION_DOWN) return true;
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            float cell = getWidth() / 8f;
            int c = (int) (e.getX() / cell), r = (int) (e.getY() / cell);
            if (c < 0 || c > 7 || r < 0 || r > 7) return true;
            int sq = squareAt(r, c);
            Position pos = tracker.pos;
            for (int tg : targets) {
                if (tg == sq && sel >= 0) {
                    int from = sel;
                    clearSelection();
                    manualPlay(from, sq);
                    return true;
                }
            }
            char ch = pos.b[sq];
            if (ch != '.' && Rules.isWhite(ch) == pos.white) {
                sel = sq;
                List<Integer> list = new ArrayList<>();
                for (int m : Rules.legalMoves(pos)) {
                    if (Move.from(m) == sq && !list.contains(Move.to(m))) list.add(Move.to(m));
                }
                targets = new int[list.size()];
                for (int i = 0; i < targets.length; i++) targets[i] = list.get(i);
            } else {
                sel = -1;
                targets = new int[0];
            }
            invalidate();
            return true;
        }
    }

    // ================================================================== finding the board by itself
    private void setPanelHidden(boolean hidden) {
        if (panel == null || selectView != null) return;
        panel.setVisibility(hidden ? View.INVISIBLE : View.VISIBLE);
    }

    private void startDetect() {
        if (!ensureClient()) {
            busy = false;
            auto = false;
            refreshButtons();
            return;
        }
        busy = true;
        final int myJob = ++job;
        hideBoxes();
        detectTry++;
        setStatus("Looking for the chess board… (try " + detectTry + ")");
        setPanelHidden(true);                          // keep my own window out of the picture
        ui.postDelayed(() -> {
            if (myJob != job) {
                setPanelHidden(false);
                return;
            }
            final GeminiClient cl = client;
            netExec.execute(() -> {
                Frame f = grabRegion(0, 0, screenW, screenH);
                ui.post(() -> setPanelHidden(false));
                double[] box = null;
                int[] rect = null;
                GeminiClient.GeminiException err = null;
                if (f == null) {
                    err = new GeminiClient.GeminiException("No screen picture yet", false, 2);
                } else if (BoardGeometry.isBlankScreen(f.px, f.w, f.h, 0.06)) {
                    ui.post(() -> {
                        if (myJob != job) return;
                        busy = false;
                        nextDetectAt = System.currentTimeMillis() + 3000;   // cheap check, no Gemini call
                        setStatus("The screen looks BLACK to me: this chess app blocks screen capture (it is protected), so I can't see the board. Tap Manual board below to use the helper without reading the screen.");
                    });
                    return;
                } else {
                    try {
                        box = cl.findBoard(encodeJpeg(f, 1024, 80));
                        if (box != null) rect = boardRectFromBox(f, box);
                    } catch (GeminiClient.GeminiException e) {
                        err = e;
                    } catch (Exception e) {
                        err = new GeminiClient.GeminiException("Unexpected problem: " + e, false, 5);
                    }
                }
                final int[] r = rect;
                final boolean found = box != null;
                final GeminiClient.GeminiException error = err;
                ui.post(() -> {
                    if (myJob == job) onDetected(r, found, error, myJob);
                });
            });
        }, 400);
    }

    /** Gemini's rough box (fractions of the screen) -> exact square rectangle in screen pixels, or null. */
    private static int[] boardRectFromBox(Frame f, double[] b) {
        int l = (int) Math.round(b[1] * f.w), t = (int) Math.round(b[0] * f.h);
        int w = (int) Math.round((b[3] - b[1]) * f.w), h = (int) Math.round((b[2] - b[0]) * f.h);
        int minSide = (int) (0.25 * Math.min(f.w, f.h));
        if (w < minSide || h < minSide) return null;
        if (Math.abs(w - h) > 0.25 * Math.max(w, h)) return null;       // a board is square
        l = Math.max(0, l);
        t = Math.max(0, t);
        w = Math.min(w, f.w - l);
        h = Math.min(h, f.h - t);
        int[] rough = {l, t, w, h};
        try {
            int[] r = BoardGeometry.refineBoard(f.px, f.w, f.h, l, t, w, h);
            boolean moved = !Arrays.equals(r, rough);
            if (moved && r[0] >= 0 && r[1] >= 0 && r[0] + r[2] <= f.w && r[1] + r[3] <= f.h
                    && Math.abs(r[2] - w) <= 0.25 * w && Math.abs(r[3] - h) <= 0.25 * h
                    && Math.abs(r[2] - r[3]) <= 0.04 * Math.max(r[2], r[3])) {
                return r;
            }
        } catch (Exception ignored) {
        }
        int side = Math.min(w, h);                                       // couldn't snap: use a centred square
        return new int[]{l + (w - side) / 2, t + (h - side) / 2, side, side};
    }

    private void onDetected(int[] rect, boolean found, GeminiClient.GeminiException err, int myJob) {
        if (err != null) {
            onGeminiError(err, myJob);
            return;
        }
        errorStreak = 0;
        if (rect == null) {
            detectFails++;
            busy = false;
            if (!auto) {
                setStatus("I can't see a chess board on the screen. Open your game and try again.");
                return;
            }
            nextDetectAt = System.currentTimeMillis() + (3000L << Math.min(detectFails - 1, 3));
            setStatus(found ? "The board is not clear yet. Looking again…"
                    : "No chess board visible. Open your game: I keep looking…");
            return;
        }
        detectFails = 0;
        region = rect;
        regionRefined = true;
        autoRegion = true;
        needFirstRead = false;
        ref = null;
        lastResult = null;
        lastResultKey = null;
        saveConfig();
        busy = false;
        movePanelAwayFromBoard();
        startRead(0);
    }

    /** Put the window below (or above) the board so it never sits on the squares. */
    private void movePanelAwayFromBoard() {
        if (region == null || panel == null) return;
        panel.post(() -> {
            try {
                int ph = panel.getHeight(), pw = panel.getWidth();
                if (ph <= 0) return;
                int[] loc = new int[2];
                panel.getLocationOnScreen(loc);
                if (!panelOverlapsBoard()) return;
                int below = region[1] + region[3] + dp(6);
                int above = region[1] - ph - dp(6);
                int y;
                if (below + ph <= screenH) y = below;
                else if (above >= 0) y = above;
                else y = Math.max(0, screenH - ph);
                panelParams.x = Math.max(0, Math.min(screenW - pw, panelParams.x));
                panelParams.y = y - (loc[1] - panelParams.y);
                wm.updateViewLayout(panel, panelParams);
            } catch (Exception ignored) {
            }
        });
    }

    private void afterPosition(int myJob) {
        Position pos = tracker.pos;
        if (forceMine && pos.white != myWhite) tracker.forceMyTurn();
        forceMine = false;
        pos = tracker.pos;
        shownKey = pos.key();
        String end = Rules.outcome(pos, tracker.keys, null);
        if (end != null) {
            busy = false;
            setStatus(end);
            return;
        }
        String note = tracker.synced ? "" : "\n(joined mid-game: castling rights guessed)";
        if (pos.white != myWhite) {
            busy = false;
            setStatus("Opponent's turn…" + note);
            return;
        }
        if (lastResult != null && shownKey.equals(lastResultKey) && (!coordMode || lastResult.hasExtremes)) {      // same position again: same advice
            showSuggestion(lastResult);
            return;
        }
        setStatus("Your turn - thinking…" + note);
        requestSuggestion(myJob);
    }

    // ================================================================== the best move
    private void requestSuggestion(final int myJob) {
        if (cancelFlag != null) cancelFlag.set(true);
        final AtomicBoolean cancel = new AtomicBoolean(false);
        cancelFlag = cancel;
        final Position pos = tracker.pos;
        final int margin = LEVEL_MARGIN[levelIdx], temp = LEVEL_TEMP[levelIdx], secs = THINK_SECONDS[thinkIdx];
        final boolean coordOn = coordMode;
        engineExec.execute(() -> {
            Engine.Result r = null;
            try {
                Engine eng = new Engine(cancel);
                Random rnd = new Random();
                r = eng.search(pos, 6, secs, margin, temp, rnd);
                if (r != null && coordOn) eng.addExtremes(pos, r, rnd, 1.5);
            } catch (Throwable ignored) {
            }
            final Engine.Result res = r;
            ui.post(() -> {
                if (myJob != job) return;
                if (res == null) {
                    busy = false;
                    setStatus("No legal move found.");
                    return;
                }
                if (manualMode) showSuggestion(res);
                else verifyThenShow(res, myJob);
            });
        });
    }

    /** The board may have changed while the engine was thinking: check before showing anything. */
    private void verifyThenShow(final Engine.Result res, final int myJob) {
        if (region == null) {
            busy = false;
            return;
        }
        final int[] reg = region.clone();
        netExec.execute(() -> {
            float[] s = null;
            try {
                Frame f = grabRegion(reg[0], reg[1], reg[2], reg[3]);
                if (f != null && f.w == reg[2] && f.h == reg[3]) s = ChangeDetector.signature(f.px, f.w, f.h);
            } catch (Exception ignored) {
            }
            final float[] now = s;
            ui.post(() -> {
                if (myJob != job) return;
                if (now != null && ref != null && ChangeDetector.changedSquares(now, ref) > 0) {
                    startRead(0);                      // the board moved on: read it again
                    return;
                }
                showSuggestion(res);
            });
        });
    }

    /** Screen rectangle {x, y, w, h} of a square (0 = a8 ... 63 = h1). */
    private int[] squareRect(int sq) {
        int r = sq / 8, c = sq % 8;
        if (!myWhite) {
            r = 7 - r;
            c = 7 - c;
        }
        float cw = region[2] / 8f, ch = region[3] / 8f;
        int x0 = region[0] + Math.round(c * cw), y0 = region[1] + Math.round(r * ch);
        int x1 = region[0] + Math.round((c + 1) * cw), y1 = region[1] + Math.round((r + 1) * ch);
        return new int[]{x0, y0, x1 - x0, y1 - y0};
    }

    /** "e2 → e4  (Pawn)" */
    private static String coordText(Position pos, int m) {
        char piece = Character.toUpperCase(pos.b[Move.from(m)]);
        return Rules.sqName(Move.from(m)) + " → " + Rules.sqName(Move.to(m)) + "  (" + Texts.pieceName(piece) + ")";
    }

    private void showSuggestion(Engine.Result res) {
        Position pos = tracker.pos;
        lastResult = res;
        lastResultKey = pos.key();
        int m = res.move;
        int from = Move.from(m), to = Move.to(m);
        Texts.Described d = Texts.describe(pos, m);
        char piece = Character.toUpperCase(pos.b[from]);
        if (coordMode && res.hasExtremes) {
            targetView.setText("BEST    " + coordText(pos, m) + "\n"
                    + "WILD    " + coordText(pos, res.wild) + "\n"
                    + "WORST  " + coordText(pos, res.worst));
            targetView.setGravity(Gravity.START);
            targetView.setTextSize(17);
        } else {
            targetView.setText(Texts.glyph(piece) + " " + Texts.pieceName(piece) + "\n"
                    + Rules.sqName(from) + "  →  " + Rules.sqName(to));
            targetView.setGravity(Gravity.CENTER);
            targetView.setTextSize(15);
        }
        StringBuilder sb = new StringBuilder();
        sb.append(coordMode ? "BEST = the move to play. WILD = a surprising but playable move. WORST = the move that loses the most.\n"
                : "")
                .append("Best move: YELLOW box = piece, GREEN box = target (")
                .append(Rules.sqName(to)).append(").");
        if (!d.tags.isEmpty()) sb.append("\nThis move ").append(android.text.TextUtils.join(", ", d.tags)).append(".");
        sb.append("\n").append(Texts.evalText(res.score)).append("  |  winning chance ")
                .append(Math.round(Texts.winChance(res.score) * 100)).append("%");
        detailsView.setText(sb.toString());
        setStatus("Your turn: move the " + Texts.pieceName(piece));
        if (manualMode || region == null) {
            busy = false;
            return;
        }
        int[] f = squareRect(from), t = squareRect(to);
        int th = Math.max(dp(3), (int) (Math.min(t[2], t[3]) * 0.06f));
        yellowBox.show(f[0] + 2, f[1] + 2, f[2] - 4, f[3] - 4, Math.max(2, th - 1));
        greenBox.show(t[0] + 2, t[1] + 2, t[2] - 4, t[3] - 4, th);
        arrow.show(region, f[0] + f[2] / 2f, f[1] + f[3] / 2f, t[0] + t[2] / 2f, t[1] + t[3] / 2f,
                Math.min(t[2], t[3]));
        busy = false;
        captureRefNext = true;                         // after the boxes settle, treat the screen as "unchanged"
        settleAt = System.currentTimeMillis() + 900;
    }

    // ================================================================== settings
    private void saveConfig() {
        try {
            SharedPreferences.Editor e = getSharedPreferences(PREFS, MODE_PRIVATE).edit();
            if (region != null) e.putString("region", region[0] + "," + region[1] + "," + region[2] + "," + region[3]);
            else e.remove("region");
            e.putBoolean("autoRegion", autoRegion);
            e.putString("screen", screenW + "x" + screenH);
            e.putBoolean("white", myWhite);
            e.putInt("level", levelIdx);
            e.putBoolean("coord", coordMode);
            e.putInt("think2", thinkIdx);
            e.apply();
        } catch (Exception ignored) {
        }
    }

    private void loadConfig() {
        try {
            SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            myWhite = p.getBoolean("white", true);
            levelIdx = Math.max(0, Math.min(LEVEL_NAMES.length - 1, p.getInt("level", 1)));
            thinkIdx = Math.max(0, Math.min(THINK_SECONDS.length - 1, p.getInt("think2", 1)));
            autoRegion = p.getBoolean("autoRegion", false);
            coordMode = p.getBoolean("coord", true);
            tracker.myWhite = myWhite;
            String reg = p.getString("region", null);
            if (reg != null && (screenW + "x" + screenH).equals(p.getString("screen", ""))) {
                String[] s = reg.split(",");
                region = new int[]{Integer.parseInt(s[0]), Integer.parseInt(s[1]),
                        Integer.parseInt(s[2]), Integer.parseInt(s[3])};
                setStatus("Open your game and tap Auto Hint.");
            }
            refreshButtons();
        } catch (Exception ignored) {
        }
    }
}
