package com.chesshelper.overlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.chesshelper.overlay.core.GeminiClient;

/**
 * Start screen:
 *   - paste your Gemini API key once (saved only on this phone),
 *   - allow "Display over other apps" and screen capture,
 *   - start the floating "Chess Helper" window.
 */
public class MainActivity extends Activity {
    private static final int REQ_PROJECTION = 42;
    private static final int REQ_NOTIF = 43;

    private TextView stepOverlay, info, keyInfo;
    private EditText keyInput;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = dp(20);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF1F2430);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, dp(40), pad, pad);
        sv.addView(col);

        col.addView(text("♞  Chess Helper", 26, 0xFF00E000, true));
        col.addView(text("Reads the chess game on your screen with Gemini, finds the best move and shows a "
                + "GREEN box and arrow where to place your piece.", 15, 0xFFE8E8E8, false), lp(dp(10)));

        // ---- step 1: Gemini key ----
        col.addView(text("1. Gemini API key (free, from aistudio.google.com)", 15, 0xFFFFFFFF, true), lp(dp(22)));
        keyInput = new EditText(this);
        keyInput.setSingleLine(true);
        keyInput.setHint("Paste your Gemini API key here");
        keyInput.setTextColor(Color.WHITE);
        keyInput.setHintTextColor(0xFF8890A0);
        keyInput.setText(prefs().getString(OverlayService.PREF_KEY, ""));
        col.addView(keyInput, lp(dp(6)));
        LinearLayout keyRow = new LinearLayout(this);
        keyRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView save = button("Save", v -> saveKey());
        TextView test = button("Test key", v -> testKey());
        LinearLayout.LayoutParams half = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        half.rightMargin = dp(6);
        keyRow.addView(save, half);
        keyRow.addView(test, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        col.addView(keyRow, lp(dp(8)));
        keyInfo = text("", 13, 0xFFC8CDD8, false);
        col.addView(keyInfo, lp(dp(6)));

        // ---- step 2: permission ----
        stepOverlay = button("", v -> askOverlayPermission());
        col.addView(stepOverlay, lp(dp(22)));

        // ---- step 3: start ----
        TextView start = button("▶  Start Chess Helper", v -> startHelper());
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF1B8A1B);
        g.setCornerRadius(dp(10));
        start.setBackground(g);
        col.addView(start, lp(dp(12)));

        col.addView(button("■  Stop", v -> {
            stopService(new Intent(MainActivity.this, OverlayService.class));
            refresh();
        }), lp(dp(12)));

        info = text("", 14, 0xFFC8CDD8, false);
        col.addView(info, lp(dp(16)));

        col.addView(text("How to use\n"
                + "1. Paste the key, tap Save, then Test key (it should say it works).\n"
                + "2. Tap Start. Allow notifications. For screen capture choose “Entire screen” and “Start now”.\n"
                + "3. Open your chess game. In the floating window tap Auto Hint so it says ON.\n"
                + "4. Gemini finds the board and reads it by itself (a few seconds). When it is your turn: "
                + "YELLOW box = piece to pick up, GREEN box + arrow = where to put it. The moves are the best "
                + "ones but slightly unpredictable.\n\n"
                + "If the helper says the screen looks BLACK, that chess app blocks screen capture (it is protected) "
                + "and nothing can read it. Tap “Manual board: OFF” to turn it ON: a small board appears in the "
                + "window. Tap each move on it (yours and the opponent's) and it prints BEST / WILD / WORST "
                + "coordinates.\n\n"
                + "If the pieces at the bottom are not yours, tap the gear ⚙ in the window and change “My pieces”. "
                + "Gear also has Surprise level, Think time and a manual ① Select board.\n\n"
                + "Xiaomi / MIUI / HyperOS: if the window or boxes do not appear, open Settings > Apps > Chess Helper > "
                + "Other permissions and allow “Display pop-up windows while running in the background”; "
                + "set Battery saver to “No restrictions” and turn Autostart on.\n\n"
                + "Use it for practice and games against the computer; most chess sites forbid engine help "
                + "in rated games against people.", 13, 0xFFAAB0C0, false), lp(dp(10)));
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private SharedPreferences prefs() {
        return getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE);
    }

    private String key() {
        return keyInput.getText().toString().trim();
    }

    private void saveKey() {
        prefs().edit().putString(OverlayService.PREF_KEY, key()).apply();
        keyInfo.setText(key().isEmpty() ? "Key cleared." : "✔ Key saved on this phone.");
    }

    private void testKey() {
        saveKey();
        final String k = key();
        if (k.isEmpty()) {
            keyInfo.setText("Paste your key first.");
            return;
        }
        keyInfo.setText("Testing…");
        new Thread(() -> {
            String msg;
            try {
                String model = new GeminiClient(k, GeminiClient.DEFAULT_BASE, GeminiClient.DEFAULT_MODELS).ping();
                msg = "✔ The key works (answered by " + model + ").";
            } catch (GeminiClient.GeminiException e) {
                msg = "✘ " + e.getMessage();
            } catch (Exception e) {
                msg = "✘ " + e;
            }
            final String m = msg;
            runOnUiThread(() -> keyInfo.setText(m));
        }).start();
    }

    private void refresh() {
        boolean ok = Settings.canDrawOverlays(this);
        stepOverlay.setText(ok ? "✔  Permission “Display over other apps” is ON"
                : "2.  Allow “Display over other apps”  (tap here)");
        stepOverlay.setTextColor(ok ? 0xFF00E000 : 0xFFFFFFFF);
        info.setText(OverlayService.running ? "The Chess Helper window is running. Switch to your chess game."
                : "Not running.");
    }

    private void askOverlayPermission() {
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
    }

    private void startHelper() {
        saveKey();
        if (key().isEmpty()) {
            info.setText("First paste your Gemini API key above and tap Save.");
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            info.setText("First allow “Display over other apps” (the button above).");
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        if (OverlayService.running) {
            info.setText("Already running. Switch to your chess game.");
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_NOTIF) startHelper();      // continue even if denied: the window still works
    }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != REQ_PROJECTION) return;
        if (result != RESULT_OK || data == null) {
            info.setText("Screen capture was not allowed, so I can't see the board. Tap Start and choose “Start now”.");
            return;
        }
        Intent svc = new Intent(this, OverlayService.class);
        svc.putExtra(OverlayService.EXTRA_CODE, result);
        svc.putExtra(OverlayService.EXTRA_DATA, data);
        startForegroundService(svc);
        info.setText("Chess Helper started. Now open your chess game.");
        moveTaskToBack(true);                      // go back to whatever you were playing
    }

    // ---- small view helpers ----
    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams lp(int topMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = topMargin;
        return p;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private TextView button(String s, View.OnClickListener l) {
        TextView t = text(s, 16, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(16), dp(12), dp(16));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF323A4D);
        g.setCornerRadius(dp(10));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }
}
