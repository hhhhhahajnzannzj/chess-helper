package com.chesshelper.overlay.core;

/**
 * Cheap "did the board change?" test. A picture of the board is reduced to a 32x32 brightness
 * map; two maps are compared square by square. Used so that Gemini is only asked when needed.
 */
public final class ChangeDetector {
    public static final int N = 32;                 // 32x32 map = 4x4 cells per chess square
    private static final float SQUARE_THRESHOLD = 6f;

    private ChangeDetector() {
    }

    /** @param px ARGB pixels of the board picture */
    public static float[] signature(int[] px, int w, int h) {
        float[] sum = new float[N * N];
        int[] cnt = new int[N * N];
        for (int y = 0; y < h; y++) {
            int gy = Math.min(N - 1, y * N / h);
            for (int x = 0; x < w; x++) {
                int c = px[y * w + x];
                int lum = (((c >> 16) & 255) * 299 + ((c >> 8) & 255) * 587 + (c & 255) * 114) / 1000;
                int g = gy * N + Math.min(N - 1, x * N / w);
                sum[g] += lum;
                cnt[g]++;
            }
        }
        for (int i = 0; i < N * N; i++) if (cnt[i] > 0) sum[i] /= cnt[i];
        return sum;
    }

    /** Number of chess squares whose look changed noticeably between two signatures. */
    public static int changedSquares(float[] a, float[] b) {
        int changed = 0;
        int per = N / 8;
        for (int sr = 0; sr < 8; sr++) {
            for (int sc = 0; sc < 8; sc++) {
                float d = 0;
                for (int y = 0; y < per; y++) {
                    for (int x = 0; x < per; x++) {
                        int i = (sr * per + y) * N + sc * per + x;
                        d += Math.abs(a[i] - b[i]);
                    }
                }
                if (d / (per * per) > SQUARE_THRESHOLD) changed++;
            }
        }
        return changed;
    }
}
