package com.chesshelper.overlay.core;

import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Chess engine: iterative-deepening negamax with alpha-beta and quiescence search.
 * It scores every candidate move within `margin` centipawns of the best one and then
 * picks randomly among them (softmax), so the advice is strong but not predictable.
 * Forced mates are always chosen.
 */
public final class Engine {
    public static final int MATE = 100000;
    private static final int INF = 1000000000;

    public static final class Result {
        public int move;
        public int score;          // from the point of view of the side to move
        public int depth;
        public int[] alternatives;
        public long nodes;
        public boolean hasExtremes;   // worst / wild were worked out
        public int worst, wild;
        public int worstScore, wildScore;
        public int bestMove, bestScore;
        public int[] candidates, candidateScores;   // moves within the margin of the best, best first   // the engine's own top choice (before any random pick)
    }

    private static final class Stopped extends RuntimeException {
        Stopped() {
            super("stopped", null, false, false);
        }
    }

    private static final class Scored {
        int[] moves;
        int[] scores;
        int n;
    }

    private final AtomicBoolean cancel;
    private long nodes;
    private long deadline = Long.MAX_VALUE;

    public Engine(AtomicBoolean cancel) {
        this.cancel = cancel != null ? cancel : new AtomicBoolean(false);
    }

    // ------------------------------------------------------------------ evaluation
    private static final int[] PAWN = {
            0, 0, 0, 0, 0, 0, 0, 0,
            50, 50, 50, 50, 50, 50, 50, 50,
            10, 10, 20, 30, 30, 20, 10, 10,
            5, 5, 10, 25, 25, 10, 5, 5,
            0, 0, 0, 20, 20, 0, 0, 0,
            5, -5, -10, 0, 0, -10, -5, 5,
            5, 10, 10, -20, -20, 10, 10, 5,
            0, 0, 0, 0, 0, 0, 0, 0};
    private static final int[] KNIGHT = {
            -50, -40, -30, -30, -30, -30, -40, -50,
            -40, -20, 0, 0, 0, 0, -20, -40,
            -30, 0, 10, 15, 15, 10, 0, -30,
            -30, 5, 15, 20, 20, 15, 5, -30,
            -30, 0, 15, 20, 20, 15, 0, -30,
            -30, 5, 10, 15, 15, 10, 5, -30,
            -40, -20, 0, 5, 5, 0, -20, -40,
            -50, -40, -30, -30, -30, -30, -40, -50};
    private static final int[] BISHOP = {
            -20, -10, -10, -10, -10, -10, -10, -20,
            -10, 0, 0, 0, 0, 0, 0, -10,
            -10, 0, 5, 10, 10, 5, 0, -10,
            -10, 5, 5, 10, 10, 5, 5, -10,
            -10, 0, 10, 10, 10, 10, 0, -10,
            -10, 10, 10, 10, 10, 10, 10, -10,
            -10, 5, 0, 0, 0, 0, 5, -10,
            -20, -10, -10, -10, -10, -10, -10, -20};
    private static final int[] ROOK = {
            0, 0, 0, 0, 0, 0, 0, 0,
            5, 10, 10, 10, 10, 10, 10, 5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            0, 0, 0, 5, 5, 0, 0, 0};
    private static final int[] QUEEN = {
            -20, -10, -10, -5, -5, -10, -10, -20,
            -10, 0, 0, 0, 0, 0, 0, -10,
            -10, 0, 5, 5, 5, 5, 0, -10,
            -5, 0, 5, 5, 5, 5, 0, -5,
            0, 0, 5, 5, 5, 5, 0, -5,
            -10, 5, 5, 5, 5, 5, 0, -10,
            -10, 0, 5, 0, 0, 0, 0, -10,
            -20, -10, -10, -5, -5, -10, -10, -20};
    private static final int[] KING_MID = {
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -20, -30, -30, -40, -40, -30, -30, -20,
            -10, -20, -20, -20, -20, -20, -20, -10,
            20, 20, 0, 0, 0, 0, 20, 20,
            20, 30, 10, 0, 0, 10, 30, 20};
    private static final int[] KING_END = {
            -50, -40, -30, -20, -20, -30, -40, -50,
            -30, -20, -10, 0, 0, -10, -20, -30,
            -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -10, 30, 40, 40, 30, -10, -30,
            -30, -10, 30, 40, 40, 30, -10, -30,
            -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -30, 0, 0, 0, 0, -30, -30,
            -50, -30, -30, -30, -30, -30, -30, -50};

    private static int val(char u) {
        switch (u) {
            case 'P':
                return 100;
            case 'N':
                return 320;
            case 'B':
                return 330;
            case 'R':
                return 500;
            case 'Q':
                return 900;
            default:
                return 0;
        }
    }

    private static int[] pst(char u) {
        switch (u) {
            case 'P':
                return PAWN;
            case 'N':
                return KNIGHT;
            case 'B':
                return BISHOP;
            case 'R':
                return ROOK;
            default:
                return QUEEN;
        }
    }

    /** Score in centipawns from the point of view of the side to move. */
    public static int evaluate(Position pos) {
        char[] b = pos.b;
        int score = 0, npm = 0, wk = 0, bk = 0;
        for (int i = 0; i < 64; i++) {
            char p = b[i];
            if (p == '.') continue;
            char u = Character.toUpperCase(p);
            if (u == 'K') {
                if (p == 'K') wk = i;
                else bk = i;
                continue;
            }
            npm += val(u);
            if (Rules.isWhite(p)) score += val(u) + pst(u)[i];
            else score -= val(u) + pst(u)[i ^ 56];
        }
        int[] kt = npm <= 2600 ? KING_END : KING_MID;
        score += kt[wk] - kt[bk ^ 56];
        return pos.white ? score : -score;
    }

    private static int moveScore(Position pos, int m) {
        int f = Move.from(m), t = Move.to(m);
        char[] b = pos.b;
        int s = 0;
        char cap = b[t];
        if (cap != '.') s += 10 * val(Character.toUpperCase(cap)) - val(Character.toUpperCase(b[f]));
        else if ((b[f] == 'P' || b[f] == 'p') && t == pos.ep) s += 900;
        char pr = Move.promo(m);
        if (pr != 0) s += val(pr);
        return s;
    }

    /** Moves sorted best-first (stable). */
    private static int[] ordered(Position pos, IntList l) {
        int n = l.n;
        int[] mv = new int[n];
        int[] sc = new int[n];
        for (int i = 0; i < n; i++) {
            mv[i] = l.a[i];
            sc[i] = moveScore(pos, mv[i]);
        }
        for (int i = 1; i < n; i++) {
            int m = mv[i], s = sc[i], j = i - 1;
            while (j >= 0 && sc[j] < s) {
                mv[j + 1] = mv[j];
                sc[j + 1] = sc[j];
                j--;
            }
            mv[j + 1] = m;
            sc[j + 1] = s;
        }
        return mv;
    }

    // ------------------------------------------------------------------ search
    private void tick() {
        nodes++;
        if ((nodes & 511) == 0 && (cancel.get() || System.nanoTime() > deadline)) throw new Stopped();
    }

    private int quiesce(Position pos, int alpha, int beta, int qd) {
        tick();
        int stand = evaluate(pos);
        if (stand >= beta) return stand;
        if (stand > alpha) alpha = stand;
        if (qd >= 6) return alpha;
        IntList all = new IntList();
        Rules.pseudoMoves(pos, all);
        IntList caps = new IntList();
        for (int i = 0; i < all.n; i++) {
            int m = all.a[i];
            int f = Move.from(m), t = Move.to(m);
            if (pos.b[t] != '.' || Move.promo(m) != 0 || ((pos.b[f] == 'P' || pos.b[f] == 'p') && t == pos.ep))
                caps.add(m);
        }
        for (int m : ordered(pos, caps)) {
            Position child = Rules.apply(pos, m);
            if (Rules.kingInCheck(child.b, pos.white)) continue;
            int s = -quiesce(child, -beta, -alpha, qd + 1);
            if (s >= beta) return s;
            if (s > alpha) alpha = s;
        }
        return alpha;
    }

    private int negamax(Position pos, int depth, int alpha, int beta, int ply) {
        tick();
        if (pos.half >= 100) return 0;
        boolean checked = Rules.inCheck(pos);
        if (checked && ply < 10) depth++;
        if (depth <= 0) return quiesce(pos, alpha, beta, 0);
        IntList all = new IntList();
        Rules.pseudoMoves(pos, all);
        int best = -INF;
        int legal = 0;
        for (int m : ordered(pos, all)) {
            Position child = Rules.apply(pos, m);
            if (Rules.kingInCheck(child.b, pos.white)) continue;
            legal++;
            int s = -negamax(child, depth - 1, -beta, -alpha, ply + 1);
            if (s > best) best = s;
            if (s > alpha) alpha = s;
            if (alpha >= beta) break;
        }
        if (legal == 0) return checked ? -MATE + ply : 0;
        return best;
    }

    /** Scores every root move within `margin` of the best one. */
    private Scored root(Position pos, int[] ordered, int depth, int margin) {
        int best = -INF;
        int[] mv = new int[ordered.length];
        int[] sc = new int[ordered.length];
        int n = 0;
        for (int m : ordered) {
            Position child = Rules.apply(pos, m);
            int alpha = best == -INF ? -INF : best - margin;
            int s = -negamax(child, depth - 1, -INF, -alpha, 1);
            if (s > alpha) {
                mv[n] = m;
                sc[n] = s;
                n++;
                if (s > best) best = s;
            }
        }
        Scored out = new Scored();
        out.moves = new int[n];
        out.scores = new int[n];
        int k = 0;
        for (int i = 0; i < n; i++) {
            if (sc[i] >= best - margin) {
                out.moves[k] = mv[i];
                out.scores[k] = sc[i];
                k++;
            }
        }
        out.n = k;
        for (int i = 1; i < k; i++) {                       // stable sort, best first
            int m = out.moves[i], s = out.scores[i], j = i - 1;
            while (j >= 0 && out.scores[j] < s) {
                out.moves[j + 1] = out.moves[j];
                out.scores[j + 1] = out.scores[j];
                j--;
            }
            out.moves[j + 1] = m;
            out.scores[j + 1] = s;
        }
        return out;
    }

    /**
     * Adds the WORST move (lowest score) and a WILD move (playable but surprising: clearly worse than the
     * best, not a blunder) to a result. Quick: every legal move is scored at a shallow depth.
     */
    public void addExtremes(Position pos, Result r, Random rng, double maxSeconds) {
        int[] moves = Rules.legalMoves(pos);
        if (moves.length < 2) return;
        deadline = System.nanoTime() + (long) (maxSeconds * 1e9);
        int[] sc = new int[moves.length];
        try {
            for (int i = 0; i < moves.length; i++) {
                sc[i] = -negamax(Rules.apply(pos, moves[i]), 2, -INF, INF, 1);
            }
        } catch (Stopped e) {
            return;
        }
        int top = -INF, wi = 0;
        for (int i = 0; i < sc.length; i++) {
            if (sc[i] > top) top = sc[i];
            if (sc[i] < sc[wi]) wi = i;
        }
        r.worst = moves[wi];
        r.worstScore = sc[wi];
        int[] pool = new int[moves.length];
        int n = 0;
        for (int i = 0; i < moves.length; i++) {                 // playable but not the best: 120..450 cp below
            if (moves[i] != r.move && moves[i] != r.worst && sc[i] <= top - 120 && sc[i] >= top - 450) pool[n++] = i;
        }
        if (n == 0) {                                            // quiet position: anything but best/worst
            for (int i = 0; i < moves.length; i++) {
                if (moves[i] != r.move && moves[i] != r.worst) pool[n++] = i;
            }
        }
        if (n == 0) {
            r.wild = r.worst;
            r.wildScore = r.worstScore;
        } else {
            int k = pool[rng.nextInt(n)];
            r.wild = moves[k];
            r.wildScore = sc[k];
        }
        r.hasExtremes = true;
    }

    // ------------------------------------------------------------------ sacrifices ("brilliant" moves)
    /** Material of the side to move minus the other side (kings ignored). */
    private static int material(Position pos) {
        int sum = 0;
        for (char c : pos.b) {
            if (c == '.') continue;
            int v = val(Character.toUpperCase(c));
            sum += Rules.isWhite(c) == pos.white ? v : -v;
        }
        return sum;
    }

    /** Material balance (side to move's view) once all captures are played out. */
    private int materialQ(Position pos, int alpha, int beta, int qd) {
        int stand = material(pos);
        if (stand >= beta) return stand;
        if (stand > alpha) alpha = stand;
        if (qd >= 8) return alpha;
        IntList all = new IntList();
        Rules.pseudoMoves(pos, all);
        IntList caps = new IntList();
        for (int i = 0; i < all.n; i++) {
            int m = all.a[i];
            int f = Move.from(m), t = Move.to(m);
            if (pos.b[t] != '.' || ((pos.b[f] == 'P' || pos.b[f] == 'p') && t == pos.ep)) caps.add(m);
        }
        for (int m : ordered(pos, caps)) {
            Position child = Rules.apply(pos, m);
            if (Rules.kingInCheck(child.b, pos.white)) continue;
            int s = -materialQ(child, -beta, -alpha, qd + 1);
            if (s >= beta) return s;
            if (s > alpha) alpha = s;
        }
        return alpha;
    }

    /**
     * How much material (centipawns) the mover gives up with move m, compared with what would happen
     * anyway if the mover simply passed. Trades are 0, winning material is negative, a real sacrifice
     * is a large positive number.
     */
    public int sacrifice(Position pos, int m) {
        int before;
        if (Rules.inCheck(pos)) {
            before = material(pos);
        } else {
            Position pass = new Position(pos.b.clone(), !pos.white, pos.castle, -1, pos.half, pos.full);
            before = -materialQ(pass, -INF, INF, 0);
        }
        Position c = Rules.apply(pos, m);
        int after = -materialQ(c, -INF, INF, 0);
        return before - after;
    }

    /** Score (mover's view) of playing m, searched to `depth`; Integer.MIN_VALUE if time ran out. */
    public int scoreMove(Position pos, int m, int depth, double seconds) {
        deadline = System.nanoTime() + (long) (seconds * 1e9);
        try {
            return -negamax(Rules.apply(pos, m), Math.max(1, depth - 1), -INF, INF, 1);
        } catch (Stopped e) {
            return Integer.MIN_VALUE;
        }
    }

    // ------------------------------------------------------------------ fast checkmate
    private long mateEnd = Long.MAX_VALUE;

    /** First move after which the side to move forces mate in n (attacker plays checks only, except at the root). */
    private int mateMove(Position pos, int n, boolean root) {
        if ((++nodes & 127) == 0 && (cancel.get() || System.nanoTime() > mateEnd)) throw new Stopped();
        int[] legal = Rules.legalMoves(pos);
        for (int pass = 0; pass < 2; pass++) {                    // checking moves first, then (root only) quiet ones
            for (int m : legal) {
                Position c = Rules.apply(pos, m);
                boolean check = Rules.inCheck(c);
                if (check != (pass == 0)) continue;
                if (!check && !(root && n > 1)) continue;
                int[] replies = Rules.legalMoves(c);
                if (replies.length == 0) {
                    if (check) return m;                             // checkmate
                    continue;                                        // stalemate: not a win
                }
                if (n == 1) continue;
                boolean all = true;
                for (int r : replies) {
                    if (mateMove(Rules.apply(c, r), n - 1, false) < 0) {
                        all = false;
                        break;
                    }
                }
                if (all) return m;
            }
        }
        return -1;
    }

    /**
     * Fastest forced mate for the side to move, found by a small forcing search (millisecond fast).
     *
     * @return {move, number of moves to mate}, or null when no mate within maxMoves was found in time
     */
    public int[] findMate(Position pos, int maxMoves, double seconds) {
        mateEnd = System.nanoTime() + (long) (seconds * 1e9);
        try {
            for (int n = 1; n <= maxMoves; n++) {
                int m = mateMove(pos, n, true);
                if (m >= 0) return new int[]{m, n};
            }
        } catch (Stopped e) {
            return null;
        }
        return null;
    }

    // ------------------------------------------------------------------ brilliant moves
    private int matSearch(Position pos, int depth, int alpha, int beta) {
        if (depth == 0) return materialQ(pos, alpha, beta, 0);
        int[] mv = Rules.legalMoves(pos);
        if (mv.length == 0) return Rules.inCheck(pos) ? -MATE : 0;
        int best = -INF;
        for (int m : ordered(pos, listOf(mv))) {
            int sc = -matSearch(Rules.apply(pos, m), depth - 1, -beta, -alpha);
            if (sc > best) best = sc;
            if (sc > alpha) alpha = sc;
            if (alpha >= beta) break;
        }
        return best;
    }

    private static IntList listOf(int[] mv) {
        IntList l = new IntList();
        for (int m : mv) l.add(m);
        return l;
    }

    /** Material balance (mover's view) if the mover passed and everything were traded off. */
    private int materialBefore(Position pos) {
        if (Rules.inCheck(pos)) return material(pos);
        Position pass = new Position(pos.b.clone(), !pos.white, pos.castle, -1, pos.half, pos.full);
        return -materialQ(pass, -INF, INF, 0);
    }

    /** The material is still given up three moves later (not just a trade or a quick combination), or it mates. */
    private boolean sacrificeHolds(Position pos, int m) {
        int before = materialBefore(pos);
        int after = -matSearch(Rules.apply(pos, m), 3, -INF, INF);
        return after >= MATE - 200 || before - after >= 250;
    }

    /**
     * A real brilliant move, as strict as possible:
     *  - a genuine piece sacrifice (at least about a minor piece) that is still a sacrifice three moves later,
     *  - the mover is not already far ahead in material (nothing to prove),
     *  - a deeper search rates it as good as the best move (within 15 cp) and the position is not worse than equal,
     *    or it forces mate.
     *
     * @return the move, or -1 when there is none
     */
    public int findBrilliant(Position pos, Result r, Random rng, boolean randomPick, double seconds) {
        long end = System.nanoTime() + (long) (seconds * 1e9);
        boolean aheadAlready = materialBefore(pos) >= 500;
        int[] moves = Rules.legalMoves(pos);
        int n = 0;
        int[] cand = new int[moves.length];
        int[] sac = new int[moves.length];
        for (int m : moves) {
            int sc = sacrifice(pos, m);
            if (sc >= 200) {
                cand[n] = m;
                sac[n] = sc;
                n++;
            }
        }
        if (n == 0) return -1;
        for (int i = 1; i < n; i++) {                           // biggest sacrifice first
            int m = cand[i], sc = sac[i], j = i - 1;
            while (j >= 0 && sac[j] < sc) {
                cand[j + 1] = cand[j];
                sac[j + 1] = sac[j];
                j--;
            }
            cand[j + 1] = m;
            sac[j + 1] = sc;
        }
        int[] real = new int[Math.min(n, 8)];
        int k = 0;
        for (int i = 0; i < n && k < real.length; i++) {
            if (System.nanoTime() > end) break;
            if (sacrificeHolds(pos, cand[i])) real[k++] = cand[i];
        }
        if (k == 0) return -1;
        int depth = Math.max(8, r.depth + 2);
        double total = Math.max(0.2, (end - System.nanoTime()) / 1e9);
        int ref = scoreMove(pos, r.bestMove, depth, total * 0.3);
        if (ref == Integer.MIN_VALUE) {                          // too slow: compare at the normal depth instead
            depth = Math.max(4, r.depth);
            ref = r.bestScore;
        }
        int[] sc = new int[k];
        for (int i = 0; i < k; i++) {
            double left = (end - System.nanoTime()) / 1e9;
            if (real[i] == r.bestMove) sc[i] = ref;
            else sc[i] = left <= 0.05 ? Integer.MIN_VALUE : scoreMove(pos, real[i], depth, left / (k - i));
            if (sc[i] != Integer.MIN_VALUE && sc[i] > ref) ref = sc[i];
        }
        int[] good = new int[k];
        int[] goodScore = new int[k];
        int g = 0;
        for (int i = 0; i < k; i++) {
            if (sc[i] == Integer.MIN_VALUE) continue;
            boolean mate = sc[i] >= MATE - 200;
            boolean sound = sc[i] >= ref - 15 && sc[i] >= 0 && ref < 700 && !aheadAlready;
            if (mate || sound) {
                good[g] = real[i];
                goodScore[g] = sc[i];
                g++;
            }
        }
        if (g == 0) return -1;
        if (randomPick) return good[rng.nextInt(g)];
        int bi = 0;
        for (int i = 1; i < g; i++) if (goodScore[i] > goodScore[bi]) bi = i;
        return good[bi];
    }

    /**
     * @param margin centipawns a move may be worse than the best and still be a candidate
     * @param temp   how evenly the candidates are mixed (bigger = more random)
     * @return null when there is no legal move
     */
    public Result search(Position pos, int maxDepth, double thinkSeconds, int margin, int temp, Random rng) {
        int[] moves = Rules.legalMoves(pos);
        if (moves.length == 0) return null;
        long start = System.nanoTime();
        IntList l = new IntList();
        for (int m : moves) l.add(m);
        int[] ord = ordered(pos, l);
        Scored result = null;
        int resultDepth = 0;
        for (int depth = 1; depth <= maxDepth; depth++) {
            deadline = depth == 1 ? Long.MAX_VALUE : start + (long) (thinkSeconds * 1e9);
            Scored sc;
            try {
                sc = root(pos, ord, depth, margin);
            } catch (Stopped e) {
                break;
            }
            result = sc;
            resultDepth = depth;
            int[] next = new int[ord.length];
            int k = 0;
            for (int i = 0; i < sc.n; i++) next[k++] = sc.moves[i];
            for (int m : ord) {
                boolean seen = false;
                for (int i = 0; i < sc.n; i++) if (sc.moves[i] == m) seen = true;
                if (!seen) next[k++] = m;
            }
            ord = next;
            if (sc.scores[0] >= MATE - 200) break;                          // forced mate found
            if ((System.nanoTime() - start) / 1e9 > thinkSeconds * 0.4) break;  // next depth too slow
        }
        if (result == null) {
            result = new Scored();
            result.moves = new int[]{ord[0]};
            result.scores = new int[]{0};
            result.n = 1;
        }
        int best = result.scores[0];
        int ci = 0;
        if (!(best >= MATE - 200 || best <= -MATE + 200) && result.n > 1) {
            double[] w = new double[result.n];
            double total = 0;
            for (int i = 0; i < result.n; i++) {
                w[i] = Math.exp((result.scores[i] - best) / Math.max(temp, 0.5));
                total += w[i];
            }
            double x = rng.nextDouble() * total;
            for (int i = 0; i < result.n; i++) {
                x -= w[i];
                if (x <= 0) {
                    ci = i;
                    break;
                }
                ci = i;
            }
        }
        Result r = new Result();
        r.move = result.moves[ci];
        r.score = result.scores[ci];
        r.bestMove = result.moves[0];
        r.bestScore = result.scores[0];
        r.depth = resultDepth;
        r.nodes = nodes;
        int[] alts = new int[Math.min(2, result.n - 1)];
        int a = 0;
        for (int i = 0; i < result.n && a < alts.length; i++) if (i != ci) alts[a++] = result.moves[i];
        r.alternatives = alts;
        r.candidates = java.util.Arrays.copyOf(result.moves, result.n);
        r.candidateScores = java.util.Arrays.copyOf(result.scores, result.n);
        return r;
    }
}
