package com.chesshelper.overlay.core;

import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/** Chooses the move to show, according to the switches. */
public final class Brain {
    /** Picks one of several engine-approved moves (used for "Use AI"). */
    public interface Chooser {
        Choice choose(Position pos, int[] moves, int[] scores) throws Exception;
    }

    public static final class Choice {
        public int move;
        public String why;
        public String model;
    }

    public static final class Options {
        public boolean unpredictable = true;
        public boolean humanize;            // play like a person: varied, natural, never a blunder
        public boolean onlyBrilliant;
        public boolean bestGambit;          // "Use best Gambit/Trap"
        public boolean fastMate;            // "Fast Checkmate 100%"
        public Chooser chooser;             // not null = "Use AI"
        public boolean instant;             // "Instant" thinking
        public double thinkSeconds = 2;
        public int margin = 45;             // centipawns a move may be worse than the best when unpredictable
    }

    public static final class Decision {
        public int move;
        public int from, to;
        public int score;               // centipawns, mover's view
        public String kind;             // "best", "random", "brilliant", "gambit", "accurate", "mate", "ai"
        public String note;             // one line for the person
        public Engine.Result result;
    }

    private static final int MAX_BOOK_TRIES = 12;

    private final Gambits.Line[] book;

    public Brain() {
        this(Gambits.BOOK);
    }

    public Brain(Gambits.Line[] book) {
        this.book = book;
    }

    /**
     * @param failed keys of gambits/traps that already failed in this game; this method adds to it
     * @return null when there is no legal move
     */
    public Decision decide(Position pos, boolean myWhite, Options o, Set<String> failed, Random rng,
                           AtomicBoolean cancel) {
        Engine eng = new Engine(cancel);
        double secs = o.instant ? 0.08 : Math.max(0.15, o.thinkSeconds);
        int depth = o.instant ? 3 : 7;
        boolean accurateOnly = !o.unpredictable && !o.humanize;
        boolean varied = !accurateOnly;
        int margin = accurateOnly ? 0 : (o.humanize ? Math.max(o.margin, 70) : o.margin);
        int temp = accurateOnly ? 1 : (o.humanize ? 36 : 22);

        // ---- 1. Fast Checkmate 100%: a forcing mate search (milliseconds); a mate always wins over everything else
        Engine.Result r = null;
        if (o.fastMate) {
            int[] fm = eng.findMate(pos, o.instant ? 3 : 5, o.instant ? 0.05 : 0.12);
            if (fm != null) {
                return make(pos, fm[0], Engine.MATE - (2 * fm[1] - 1), "mate", "Fast checkmate: forced mate in "
                        + fm[1] + (fm[1] == 1 ? " move!" : " moves!"), null);
            }
        }

        // ---- 2. normal search
        if (r == null) {
            int m = o.chooser != null ? Math.max(margin, 60) : margin;
            r = eng.search(pos, depth, secs, m, temp, rng);
            if (r == null) return null;
        }

        // ---- 3. gambit / trap book
        String bookNote = null;
        if (o.bestGambit) {
            List<Gambits.Pick> picks = Gambits.matches(pos, myWhite, failed, book);
            if (varied) Collections.shuffle(picks, rng);
            int tries = 0;
            double check = Math.min(1.5, Math.max(0.25, secs));
            for (Gambits.Pick pk : picks) {
                if (tries++ >= MAX_BOOK_TRIES) break;
                int s = pk.move == r.bestMove ? r.bestScore : eng.scoreMove(pos, pk.move, Math.max(4, r.depth), check);
                boolean sound = s != Integer.MIN_VALUE && s >= r.bestScore - 200 && s >= -250;
                if (sound) {
                    return make(pos, pk.move, s, "gambit",
                            pk.line.name + (pk.line.isTrap() ? " (trap, book move)" : " (gambit, book move)"), r);
                }
                if (failed != null) failed.add(pk.line.key());          // refuted: try the next one
                bookNote = pk.line.name + " failed";
            }
            if (bookNote != null) bookNote += "; playing the 100% accurate move";
            else bookNote = "No gambit or trap fits here; playing the 100% accurate move";
            if (!accurateOnly) {                                         // be fully accurate, no random pick
                Engine.Result acc = new Engine(cancel).search(pos, depth, secs, o.chooser != null ? 60 : 0, 1, rng);
                if (acc != null) r = acc;
            }
        }

        // ---- 4. Only Brilliant
        if (o.onlyBrilliant) {
            double bt = o.instant ? 0.6 : Math.min(6.0, Math.max(1.5, secs * 2));
            int b = eng.findBrilliant(pos, r, rng, varied, bt);
            if (b >= 0) {
                int s = b == r.bestMove ? r.bestScore : eng.scoreMove(pos, b, Math.max(4, r.depth), 0.5);
                if (s == Integer.MIN_VALUE) s = r.bestScore;
                return make(pos, b, s, "brilliant", "Brilliant move: a real piece sacrifice that is checked deeply", r);
            }
            bookNote = (bookNote == null ? "" : bookNote + ". ") + "No real brilliant move here, so the best move";
        }

        // ---- 5. Use AI: Gemini picks among the engine-approved moves
        String aiNote = null;
        if (o.chooser != null) {
            if (o.instant) {
                aiNote = "AI skipped (Instant mode)";
            } else if (r.candidates == null || r.candidates.length < 2) {
                aiNote = "Only one good move, so no AI needed";
            } else {
                try {
                    int n = Math.min(5, r.candidates.length);              // the five best are enough
                    int[] cm = java.util.Arrays.copyOf(r.candidates, n);
                    int[] cs = java.util.Arrays.copyOf(r.candidateScores, n);
                    Choice c = o.chooser.choose(pos, cm, cs);
                    if (c != null) {
                        int s = r.bestScore;
                        for (int i = 0; i < n; i++) if (cm[i] == c.move) s = cs[i];
                        String why = c.why == null || c.why.isEmpty() ? "" : ": " + c.why;
                        return make(pos, c.move, s, "ai", "AI (" + c.model + ")" + why, r);
                    }
                    aiNote = "AI gave no usable answer";
                } catch (Exception e) {
                    String msg = String.valueOf(e.getMessage());
                    aiNote = "AI unavailable (" + (msg.length() > 70 ? msg.substring(0, 70) + "…" : msg) + ")";
                }
            }
        }

        Decision d = plain(pos, r, o);
        String extra = bookNote == null ? aiNote : (aiNote == null ? bookNote : bookNote + ". " + aiNote);
        if (extra != null) {
            d.note = extra + (extra.endsWith(".") ? "" : ".");
            if (bookNote != null && bookNote.contains("100% accurate")) d.kind = "accurate";
        }
        return d;
    }

    private static Decision plain(Position pos, Engine.Result r, Options o) {
        boolean mate = r.score >= Engine.MATE - 200;
        String kind = mate ? "mate" : (o.humanize ? "human" : o.unpredictable ? "random" : "best");
        String note = mate ? "Forced mate!" : o.humanize ? "A natural, human-like move"
                : o.unpredictable ? "A strong move, picked with some surprise" : "The best move";
        return make(pos, r.move, r.score, kind, note, r);
    }

    private static Decision make(Position pos, int move, int score, String kind, String note, Engine.Result r) {
        Decision d = new Decision();
        d.move = move;
        d.from = Move.from(move);
        d.to = Move.to(move);
        d.score = score;
        d.kind = kind;
        d.note = note;
        d.result = r;
        return d;
    }
}
