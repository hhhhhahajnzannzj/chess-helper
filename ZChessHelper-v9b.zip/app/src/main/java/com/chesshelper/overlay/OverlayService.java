package com.chesshelper.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chesshelper.overlay.core.AiChooser;
import com.chesshelper.overlay.core.AiPool;
import com.chesshelper.overlay.core.BoardGeometry;
import com.chesshelper.overlay.core.Brain;
import com.chesshelper.overlay.core.DefaultKeys;
import com.chesshelper.overlay.core.GameTracker;
import com.chesshelper.overlay.core.GeminiClient;
import com.chesshelper.overlay.core.Move;
import com.chesshelper.overlay.core.Position;
import com.chesshelper.overlay.core.Rules;
import com.chesshelper.overlay.core.Texts;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The floating "Chess Helper" window. It holds its own chess board: you tap every move (yours and the
 * opponent's) on it, and when it is your turn the best move is shown on that board with an ARROW and a
 * BLUE box. Nothing is read from the screen and nothing is sent anywhere.
 */
public class OverlayService extends Service {
    public static final String ACTION_STOP = "com.chesshelper.overlay.STOP";
    public static final String PREFS = "chess_helper";
    private static final String CHANNEL_ID = "chess_helper";
    private static final int NOTIF_ID = 7;
    public static volatile boolean running;

    private static final int GREEN = Color.rgb(0, 224, 0);
    private static final int BLUE = Color.rgb(47, 139, 255);
    private static final int BG = 0xFF1F2430, BAR = 0xFF11151C, FG = 0xFFE8E8E8, BTN = 0xFF323A4D;

    public static final String PREF_KEY = "gemini_key";
    // Think: 0 = automatic (from the mode), 1 = Instant, then fixed seconds
    private static final double[] THINK_SECONDS = {0, 0.05, 1, 2, 3, 5, 8};
    private static final String[] THINK_NAMES = {"Auto", "Instant", "1s", "2s", "3s", "5s", "8s"};
    private static final int[] BOARD_DP = {210, 260, 310};
    private static final String[] SIZE_NAMES = {"Small", "Medium", "Large"};

    // Choose your mode (like the Chess.com time controls). Faster mode = faster thinking, kept balanced.
    private static final String[] MODE_GROUPS = {"Bullet", "Blitz (Lightning)", "Rapid", "Daily"};
    private static final String[] MODE_LABELS = {"1 min", "1 + 1", "2 + 1", "3 min", "3 + 2", "5 min",
            "10 min", "10 + 5", "15 + 10", "1 day", "3 days", "7 days"};
    private static final double[] MODE_SECONDS = {0.3, 0.4, 0.5, 0.8, 1.0, 1.3, 2, 2.5, 3, 6, 8, 10};
    private static final int[] MODE_MARGIN = {25, 25, 25, 35, 35, 35, 45, 45, 45, 45, 45, 45};

    // features that can be shown or hidden in the window
    private static final String[] FEATURE_KEYS = {"done", "undo", "newgame", "mode", "think", "unpred", "brill",
            "gambit", "mate", "ai", "human", "side", "size"};
    private static final String[] FEATURE_NAMES = {"Done button", "Undo move", "New game", "Choose your mode",
            "Think time", "Unpredictable", "Only Brilliant", "Use best Gambit/Trap", "Fast Checkmate 100%",
            "Use AI", "Humanize", "My pieces", "Board size"};

    private WindowManager wm;
    private Handler ui;
    private ExecutorService engineExec;
    private int screenW, screenH;

    // views
    private LinearLayout panel, bodyView;
    private WindowManager.LayoutParams panelParams;
    private TextView statusView, btnSide, btnThink, btnSize, btnMode, btnDone;
    private TextView btnUnpredictable, btnBrilliant, btnGambit, btnMate, btnAi, btnHuman;
    private TextView[] modeButtons = new TextView[MODE_LABELS.length];
    private LinearLayout modeBox, settingsView, doneRow;
    private boolean featuresCollapsed;
    private TextView[] featureToggles = new TextView[FEATURE_KEYS.length];
    private View[] featureViews = new View[FEATURE_KEYS.length];
    private final boolean[] featureShown = new boolean[FEATURE_KEYS.length];
    private final List<LinearLayout> bodyRows = new ArrayList<>();
    private View closeDialog;
    private BoardView boardView;
    private AiPool aiPool;
    private String aiPoolKey = "";

    // game state (UI thread only)
    private final GameTracker tracker = new GameTracker(true);
    private final List<Position> history = new ArrayList<>();
    private final Set<String> failedGambits = new HashSet<>();
    private boolean myWhite = true;
    private boolean unpredictable = true, onlyBrilliant, bestGambit, fastMate, useAi, humanize;
    private int thinkIdx = 0, sizeIdx = 1, modeIdx = 7;
    private int job;                                   // bumps whenever work is cancelled / restarted
    private AtomicBoolean cancelFlag = new AtomicBoolean(false);

    // ================================================================== lifecycle
    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        ui = new Handler(Looper.getMainLooper());
        engineExec = Executors.newSingleThreadExecutor();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running || intent == null) return START_NOT_STICKY;
        try {
            createChannel();
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NOTIF_ID, n);
            }
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
            loadConfig();
            buildUi();
            running = true;
            newGame();
        } catch (Exception e) {
            Toast.makeText(this, "Chess Helper could not start: " + e.getMessage(), Toast.LENGTH_LONG).show();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        cancelAll();
        ui.removeCallbacksAndMessages(null);
        try {
            if (closeDialog != null) wm.removeViewImmediate(closeDialog);
            if (panel != null) wm.removeViewImmediate(panel);
        } catch (Exception ignored) {
        }
        engineExec.shutdownNow();
        super.onDestroy();
    }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Chess Helper",
                NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification.Action action = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", pi).build();
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Chess Helper is running")
                .setContentText("Tap Stop to close the helper.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .addAction(action)
                .setOngoing(true)
                .build();
    }

    // ================================================================== UI helpers
    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private TextView makeButton(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(FG);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(10), dp(6), dp(10));
        t.setBackground(rounded(BTN, dp(8)));
        t.setClickable(true);
        t.setOnClickListener(l);
        return t;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(4);
        r.setLayoutParams(lp);
        return r;
    }

    private void addWeighted(LinearLayout row, View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(2);
        lp.rightMargin = dp(2);
        row.addView(v, lp);
    }

    private TextView smallText(int color, float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setTextColor(color);
        t.setTextSize(sp);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private int boardPx() {
        int want = dp(BOARD_DP[sizeIdx]);
        return Math.min(want, screenW - dp(28));
    }

    private void buildUi() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(rounded(BG, dp(14)));

        // ---- title bar (drag handle) ----
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(rounded(BAR, dp(14)));
        TextView title = smallText(GREEN, 15, true);
        title.setText("♞  Chess Helper");
        title.setPadding(dp(12), dp(8), dp(8), dp(8));
        bar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView gear = smallText(0xFFAAB0C0, 17, false);
        gear.setText("⚙");
        gear.setPadding(dp(12), dp(4), dp(10), dp(4));
        gear.setOnClickListener(v -> {                       // tap: hide / show all the feature buttons
            featuresCollapsed = !featuresCollapsed;
            applyFeatureVisibility();
            saveConfig();
        });
        gear.setOnLongClickListener(v -> {                   // long-press: choose which features to show
            toggleSettings();
            return true;
        });
        bar.addView(gear);
        TextView collapse = smallText(0xFFAAB0C0, 20, false);
        collapse.setText("–");
        collapse.setPadding(dp(14), dp(4), dp(14), dp(4));
        collapse.setOnClickListener(v -> {
            boolean open = bodyView.getVisibility() == View.VISIBLE || settingsView.getVisibility() == View.VISIBLE;
            if (open) {
                bodyView.setVisibility(View.GONE);
                settingsView.setVisibility(View.GONE);
            } else {
                bodyView.setVisibility(View.VISIBLE);
            }
        });
        bar.addView(collapse);
        TextView close = smallText(0xFFAAB0C0, 18, false);
        close.setText("✕");
        close.setPadding(dp(14), dp(4), dp(14), dp(4));
        close.setOnClickListener(v -> askClose());
        bar.addView(close);
        bar.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = panelParams.x;
                        sy = panelParams.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelParams.x = sx + (int) (e.getRawX() - tx);
                        panelParams.y = sy + (int) (e.getRawY() - ty);
                        wm.updateViewLayout(panel, panelParams);
                        return true;
                    default:
                        return false;
                }
            }
        });
        panel.addView(bar);

        // ---- body ----
        bodyView = new LinearLayout(this);
        bodyView.setOrientation(LinearLayout.VERTICAL);
        bodyView.setPadding(dp(10), dp(6), dp(10), dp(10));
        panel.addView(bodyView);

        statusView = smallText(FG, 13, true);
        bodyView.addView(statusView);

        boardView = new BoardView(this);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(boardPx(), boardPx());
        blp.topMargin = dp(6);
        blp.gravity = Gravity.CENTER_HORIZONTAL;
        bodyView.addView(boardView, blp);

        // ---- Done ----
        btnDone = makeButton("Done ✔  (place the move)", v -> done());
        btnDone.setTextSize(15);
        btnDone.setTypeface(null, android.graphics.Typeface.BOLD);
        btnDone.setTextColor(Color.WHITE);
        btnDone.setBackground(rounded(0xFF1B8A1B, dp(10)));
        LinearLayout rDone = row();
        doneRow = rDone;
        addWeighted(rDone, btnDone);
        bodyView.addView(rDone);
        bodyRows.add(rDone);
        featureViews[idx("done")] = btnDone;

        LinearLayout r1 = row();
        TextView btnUndo = makeButton("Undo move", v -> undo());
        TextView btnNew = makeButton("New game", v -> newGame());
        addWeighted(r1, btnUndo);
        addWeighted(r1, btnNew);
        bodyView.addView(r1);
        bodyRows.add(r1);
        featureViews[idx("undo")] = btnUndo;
        featureViews[idx("newgame")] = btnNew;

        // ---- Choose your mode (+ the picker) ----
        btnMode = makeButton("", v -> modeBox.setVisibility(
                modeBox.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        LinearLayout rMode = row();
        addWeighted(rMode, btnMode);
        bodyView.addView(rMode);
        bodyRows.add(rMode);
        featureViews[idx("mode")] = btnMode;
        buildModeBox();
        bodyView.addView(modeBox);

        LinearLayout r2 = row();
        btnUnpredictable = makeButton("", v -> {
            unpredictable = !unpredictable;
            optionsChanged();
        });
        btnBrilliant = makeButton("", v -> {
            onlyBrilliant = !onlyBrilliant;
            optionsChanged();
        });
        addWeighted(r2, btnUnpredictable);
        addWeighted(r2, btnBrilliant);
        bodyView.addView(r2);
        bodyRows.add(r2);
        featureViews[idx("unpred")] = btnUnpredictable;
        featureViews[idx("brill")] = btnBrilliant;

        LinearLayout r3 = row();
        btnGambit = makeButton("", v -> {
            bestGambit = !bestGambit;
            failedGambits.clear();
            optionsChanged();
        });
        btnMate = makeButton("", v -> {
            fastMate = !fastMate;
            optionsChanged();
        });
        addWeighted(r3, btnGambit);
        addWeighted(r3, btnMate);
        bodyView.addView(r3);
        bodyRows.add(r3);
        featureViews[idx("gambit")] = btnGambit;
        featureViews[idx("mate")] = btnMate;

        LinearLayout r4 = row();
        btnAi = makeButton("", v -> {
            useAi = !useAi;
            optionsChanged();
        });
        btnThink = makeButton("", v -> {
            thinkIdx = (thinkIdx + 1) % THINK_SECONDS.length;
            optionsChanged();
        });
        addWeighted(r4, btnAi);
        addWeighted(r4, btnThink);
        bodyView.addView(r4);
        bodyRows.add(r4);
        featureViews[idx("ai")] = btnAi;
        featureViews[idx("think")] = btnThink;

        LinearLayout rH = row();
        btnHuman = makeButton("", v -> {
            humanize = !humanize;
            optionsChanged();
        });
        addWeighted(rH, btnHuman);
        bodyView.addView(rH);
        bodyRows.add(rH);
        featureViews[idx("human")] = btnHuman;

        LinearLayout r5 = row();
        btnSide = makeButton("", v -> toggleSide());
        btnSize = makeButton("", v -> {
            sizeIdx = (sizeIdx + 1) % BOARD_DP.length;
            applySize();
            saveConfig();
            refreshButtons();
        });
        addWeighted(r5, btnSide);
        addWeighted(r5, btnSize);
        bodyView.addView(r5);
        bodyRows.add(r5);
        featureViews[idx("side")] = btnSide;
        featureViews[idx("size")] = btnSize;

        buildSettingsView();
        panel.addView(settingsView);

        refreshButtons();
        applyFeatureVisibility();

        panelParams = new WindowManager.LayoutParams(panelWidth(), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = dp(8);
        panelParams.y = dp(48);
        wm.addView(panel, panelParams);
    }

    private int panelWidth() {
        return boardPx() + dp(20);
    }

    private void applySize() {
        LinearLayout.LayoutParams blp = (LinearLayout.LayoutParams) boardView.getLayoutParams();
        blp.width = boardPx();
        blp.height = boardPx();
        boardView.setLayoutParams(blp);
        panelParams.width = panelWidth();
        wm.updateViewLayout(panel, panelParams);
    }

    private void toggleButton(TextView b, String name, boolean on) {
        toggleButton(b, name, on, "ON", "OFF");
    }

    private void toggleButton(TextView b, String name, boolean on, String onText, String offText) {
        b.setText(name + ": " + (on ? onText : offText));
        b.setTextColor(on ? GREEN : FG);
        b.setBackground(rounded(on ? 0xFF1B4A24 : BTN, dp(8)));
    }

    private void refreshButtons() {
        toggleButton(btnUnpredictable, "Unpredictable", unpredictable);
        toggleButton(btnBrilliant, "Only Brilliant", onlyBrilliant);
        toggleButton(btnGambit, "Use best Gambit/Trap", bestGambit);
        toggleButton(btnMate, "Fast Checkmate 100%", fastMate);
        toggleButton(btnAi, "Use AI", useAi);
        toggleButton(btnHuman, "Humanize", humanize);
        btnSide.setText("My pieces: " + (myWhite ? "White" : "Black"));
        btnThink.setText("Think: " + THINK_NAMES[thinkIdx]);
        btnSize.setText("Board size: " + SIZE_NAMES[sizeIdx]);
        btnMode.setText("Choose your mode  ·  " + modeGroupOf(modeIdx) + " " + MODE_LABELS[modeIdx]);
        for (int i = 0; i < modeButtons.length; i++) {
            boolean on = i == modeIdx;
            modeButtons[i].setTextColor(on ? GREEN : FG);
            GradientDrawable g = rounded(BTN, dp(8));
            if (on) g.setStroke(dp(2), GREEN);
            modeButtons[i].setBackground(g);
        }
    }

    private static String modeGroupOf(int i) {
        return MODE_GROUPS[i / 3];
    }

    private int idx(String key) {
        for (int i = 0; i < FEATURE_KEYS.length; i++) if (FEATURE_KEYS[i].equals(key)) return i;
        return -1;
    }

    private void buildModeBox() {
        modeBox = new LinearLayout(this);
        modeBox.setOrientation(LinearLayout.VERTICAL);
        modeBox.setVisibility(View.GONE);
        modeBox.setBackground(rounded(0xFF181C25, dp(10)));
        modeBox.setPadding(dp(6), dp(4), dp(6), dp(6));
        for (int g = 0; g < MODE_GROUPS.length; g++) {
            TextView head = smallText(0xFFFFFFFF, 13, true);
            head.setText(MODE_GROUPS[g]);
            head.setPadding(dp(4), dp(6), 0, 0);
            modeBox.addView(head);
            LinearLayout r = row();
            for (int k = 0; k < 3; k++) {
                final int index = g * 3 + k;
                TextView b = makeButton(MODE_LABELS[index], v -> {
                    modeIdx = index;
                    thinkIdx = 0;                              // the mode sets the thinking time
                    modeBox.setVisibility(View.GONE);
                    optionsChanged();
                });
                modeButtons[index] = b;
                addWeighted(r, b);
            }
            modeBox.addView(r);
        }
    }

    private void buildSettingsView() {
        settingsView = new LinearLayout(this);
        settingsView.setOrientation(LinearLayout.VERTICAL);
        settingsView.setPadding(dp(10), dp(6), dp(10), dp(10));
        settingsView.setVisibility(View.GONE);
        TextView head = smallText(FG, 13, true);
        head.setText("Settings: show or hide features.\nA hidden feature keeps its current setting.");
        settingsView.addView(head);
        LinearLayout r = null;
        for (int i = 0; i < FEATURE_KEYS.length; i++) {
            if (i % 2 == 0) {
                r = row();
                settingsView.addView(r);
            }
            final int index = i;
            featureToggles[i] = makeButton("", v -> {
                featureShown[index] = !featureShown[index];
                applyFeatureVisibility();
                saveConfig();
            });
            addWeighted(r, featureToggles[i]);
        }
        LinearLayout ra = row();
        addWeighted(ra, makeButton("Show all", v -> setAllFeatures(true)));
        addWeighted(ra, makeButton("Hide all", v -> setAllFeatures(false)));
        settingsView.addView(ra);
        LinearLayout rb = row();
        addWeighted(rb, makeButton("Back to the board", v -> toggleSettings()));
        settingsView.addView(rb);
    }

    private void setAllFeatures(boolean show) {
        java.util.Arrays.fill(featureShown, show);
        applyFeatureVisibility();
        saveConfig();
    }

    private void toggleSettings() {
        boolean open = settingsView.getVisibility() == View.VISIBLE;
        settingsView.setVisibility(open ? View.GONE : View.VISIBLE);
        bodyView.setVisibility(open ? View.VISIBLE : View.GONE);
    }

    private void applyFeatureVisibility() {
        for (int i = 0; i < FEATURE_KEYS.length; i++) {
            if (featureViews[i] != null) featureViews[i].setVisibility(featureShown[i] ? View.VISIBLE : View.GONE);
            toggleButton(featureToggles[i], FEATURE_NAMES[i], featureShown[i], "SHOWN", "HIDDEN");
        }
        for (LinearLayout row : bodyRows) {
            boolean any = false;
            for (int c = 0; c < row.getChildCount(); c++) if (row.getChildAt(c).getVisibility() == View.VISIBLE) any = true;
            boolean keep = !featuresCollapsed || row == doneRow;      // collapsed: only the Done button stays
            row.setVisibility(any && keep ? View.VISIBLE : View.GONE);
        }
        if (!featureShown[idx("mode")] || featuresCollapsed) modeBox.setVisibility(View.GONE);
    }

    private void setStatus(String s) {
        statusView.setText(s);
    }

    // ================================================================== close pop-up
    private void askClose() {
        if (closeDialog != null) return;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rounded(0xFF2A3042, dp(16)));
        card.setPadding(dp(22), dp(20), dp(22), dp(18));
        TextView q = smallText(Color.WHITE, 17, true);
        q.setText("Are you sure to close?");
        q.setGravity(Gravity.CENTER);
        card.addView(q);
        LinearLayout r = row();
        TextView yes = makeButton("Yes", v -> stopSelf());
        yes.setTextSize(16);
        yes.setBackground(rounded(0xFFB3261E, dp(10)));
        yes.setTextColor(Color.WHITE);
        TextView no = makeButton("No", v -> dismissClose());
        no.setTextSize(16);
        no.setBackground(rounded(0xFF1B8A1B, dp(10)));
        no.setTextColor(Color.WHITE);
        addWeighted(r, yes);
        addWeighted(r, no);
        LinearLayout.LayoutParams rp = (LinearLayout.LayoutParams) r.getLayoutParams();
        rp.topMargin = dp(16);
        card.addView(r);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(Math.min(dp(300), screenW - dp(40)),
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_DIM_BEHIND,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.CENTER;
        lp.dimAmount = 0.55f;
        try {
            wm.addView(card, lp);
            closeDialog = card;
        } catch (Exception e) {
            stopSelf();
        }
    }

    private void dismissClose() {
        if (closeDialog == null) return;
        try {
            wm.removeViewImmediate(closeDialog);
        } catch (Exception ignored) {
        }
        closeDialog = null;
    }

    private void done() {
        if (boardView.hintFrom < 0 || boardView.hintTo < 0) {
            setStatus("No move is shown yet. Wait for your turn.");
            return;
        }
        play(boardView.hintFrom, boardView.hintTo);                // puts the piece there, then waits for the opponent
    }

    // ================================================================== AI keys
    private Brain.Chooser aiChooser() {
        String custom = "";
        try {
            custom = getSharedPreferences(PREFS, MODE_PRIVATE).getString(PREF_KEY, "").trim();
        } catch (Exception ignored) {
        }
        if (aiPool == null || !custom.equals(aiPoolKey)) {
            List<String> keys = new ArrayList<>();
            if (!custom.isEmpty()) keys.add(custom);                  // your own key first, then the built-in ones
            for (String k : DefaultKeys.KEYS) if (!keys.contains(k)) keys.add(k);
            aiPool = new AiPool(keys.toArray(new String[0]), GeminiClient.DEFAULT_BASE, GeminiClient.DEFAULT_MODELS,
                    9000, 14000);
            aiPoolKey = custom;
        }
        return new AiChooser(aiPool);
    }

    // ================================================================== game
    private void cancelAll() {
        job++;
        cancelFlag.set(true);
        cancelFlag = new AtomicBoolean(false);
    }

    private void optionsChanged() {
        saveConfig();
        refreshButtons();
        advance();                                      // new settings: work out the hint again
    }

    private void newGame() {
        cancelAll();
        tracker.myWhite = myWhite;
        tracker.reset();
        history.clear();
        failedGambits.clear();
        boardView.clearSelection();
        boardView.setHint(-1, -1);
        advance();
    }

    private void undo() {
        if (history.isEmpty() || tracker.keys.size() < 2) return;
        cancelAll();
        tracker.pos = history.remove(history.size() - 1);
        tracker.keys.remove(tracker.keys.size() - 1);
        failedGambits.clear();
        boardView.clearSelection();
        boardView.setHint(-1, -1);
        advance();
    }

    private void toggleSide() {
        myWhite = !myWhite;
        saveConfig();
        refreshButtons();
        newGame();
    }

    private void play(int from, int to) {
        Position pos = tracker.pos;
        int chosen = -1;
        for (int m : Rules.legalMoves(pos)) {
            if (Move.from(m) == from && Move.to(m) == to && (Move.promo(m) == 0 || Move.promo(m) == 'Q')) chosen = m;
        }
        if (chosen < 0) return;
        cancelAll();
        history.add(pos);
        tracker.pos = Rules.apply(pos, chosen);
        tracker.keys.add(tracker.pos.key());
        boardView.setHint(-1, -1);
        advance();
    }

    /** After any change: game over? opponent's turn? or think about my move. */
    private void advance() {
        boardView.invalidate();
        Position pos = tracker.pos;
        String end = Rules.outcome(pos, tracker.keys, null);
        if (end != null) {
            setStatus(end);
            return;
        }
        if (pos.white != myWhite) {
            setStatus("Opponent's turn. Tap the piece they moved, then its new square.");
            return;
        }
        setStatus(useAi && thinkIdx != 1 ? "Your turn - thinking (asking the AI)…" : "Your turn - thinking…");
        think();
    }

    private void think() {
        cancelAll();
        final int myJob = job;
        final AtomicBoolean cancel = cancelFlag;
        final Position pos = tracker.pos;
        final boolean mine = myWhite;
        final Brain.Options o = new Brain.Options();
        o.unpredictable = unpredictable;
        o.onlyBrilliant = onlyBrilliant;
        o.bestGambit = bestGambit;
        o.fastMate = fastMate;
        o.humanize = humanize;
        o.chooser = useAi ? aiChooser() : null;
        o.instant = thinkIdx == 1;
        if (thinkIdx == 0) {
            o.thinkSeconds = MODE_SECONDS[modeIdx];
            o.margin = MODE_MARGIN[modeIdx];
        } else {
            o.thinkSeconds = THINK_SECONDS[thinkIdx];
        }
        final Set<String> failed = new HashSet<>(failedGambits);
        final Random rng = new Random();
        engineExec.execute(() -> {
            Brain.Decision d = null;
            String problem = null;
            try {
                d = new Brain().decide(pos, mine, o, failed, rng, cancel);
            } catch (Throwable t) {
                problem = String.valueOf(t);
            }
            final Brain.Decision dec = d;
            final String err = problem;
            long wait = 0;
            if (humanize && !o.instant && dec != null) {      // a person needs a moment: vary it
                double base = thinkIdx == 0 ? Math.min(2.5, 0.4 + MODE_SECONDS[modeIdx]) : 1.2;
                wait = (long) (1000 * (0.3 + rng.nextDouble() * base));
            }
            ui.postDelayed(() -> {
                if (myJob != job) return;                     // the position changed meanwhile
                failedGambits.addAll(failed);
                if (dec == null) {
                    setStatus(err != null ? "Could not think: " + err : "No move available.");
                    return;
                }
                boardView.setHint(dec.from, dec.to);
                String piece = Texts.pieceName(Character.toUpperCase(pos.b[dec.from]));
                setStatus("Move the " + piece + " as shown by the arrow.\n" + dec.note);
            }, wait);
        });
    }

    // ================================================================== the board
    private final class BoardView extends View {
        private final Paint p = new Paint(), t = new Paint();
        private final Path head = new Path();
        private int sel = -1;
        private int[] targets = new int[0];
        int hintFrom = -1, hintTo = -1;

        BoardView(Context c) {
            super(c);
            p.setAntiAlias(true);
            t.setAntiAlias(true);
            t.setTextAlign(Paint.Align.CENTER);
        }

        void clearSelection() {
            sel = -1;
            targets = new int[0];
            invalidate();
        }

        void setHint(int from, int to) {
            hintFrom = from;
            hintTo = to;
            invalidate();
        }

        private int squareAt(int r, int c) {
            return BoardGeometry.imgIndex(r * 8 + c, !myWhite);
        }

        private float cx(int sq, float cell) {
            int i = BoardGeometry.imgIndex(sq, !myWhite);          // the mapping is its own inverse
            return (i % 8) * cell + cell / 2f;
        }

        private float cy(int sq, float cell) {
            int i = BoardGeometry.imgIndex(sq, !myWhite);
            return (i / 8) * cell + cell / 2f;
        }

        @Override
        protected void onDraw(Canvas cv) {
            float cell = getWidth() / 8f;
            Position pos = tracker.pos;
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
                    int sq = squareAt(r, c);
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(((r + c) & 1) == 0 ? 0xFFEEEED2 : 0xFF769656);
                    cv.drawRect(c * cell, r * cell, (c + 1) * cell, (r + 1) * cell, p);
                    if (sq == sel) {
                        p.setColor(0xAAFFD400);
                        cv.drawRect(c * cell, r * cell, (c + 1) * cell, (r + 1) * cell, p);
                    }
                    char ch = pos.b[sq];
                    if (ch != '.') {
                        String g = Texts.glyph(Character.toUpperCase(ch));
                        t.setTextSize(cell * 0.82f);
                        float x = c * cell + cell / 2f, y = r * cell + cell * 0.76f;
                        boolean white = Rules.isWhite(ch);
                        t.setStyle(Paint.Style.STROKE);
                        t.setStrokeWidth(cell * 0.06f);
                        t.setColor(white ? 0xFF222222 : 0xFFFFFFFF);
                        cv.drawText(g, x, y, t);
                        t.setStyle(Paint.Style.FILL);
                        t.setColor(white ? 0xFFFFFFFF : 0xFF111111);
                        cv.drawText(g, x, y, t);
                    }
                    for (int tg : targets) {
                        if (tg == sq) {
                            p.setColor(0xCC00E000);
                            cv.drawCircle(c * cell + cell / 2f, r * cell + cell / 2f, cell * 0.17f, p);
                        }
                    }
                }
            }
            t.setStyle(Paint.Style.FILL);
            t.setTextSize(cell * 0.24f);
            t.setColor(0xFF33442A);
            for (int i = 0; i < 8; i++) {                                // a-h / 1-8 labels
                String file = String.valueOf((char) ('a' + (myWhite ? i : 7 - i)));
                String rank = String.valueOf(myWhite ? 8 - i : i + 1);
                cv.drawText(file, i * cell + cell * 0.82f, 8 * cell - cell * 0.06f, t);
                cv.drawText(rank, cell * 0.14f, i * cell + cell * 0.27f, t);
            }
            if (hintFrom >= 0 && hintTo >= 0) drawHint(cv, cell);
        }

        /** BLUE box on the piece and on the target square, and a BLUE arrow between them. */
        private void drawHint(Canvas cv, float cell) {
            float fx = cx(hintFrom, cell), fy = cy(hintFrom, cell);
            float tx = cx(hintTo, cell), ty = cy(hintTo, cell);
            float h = cell / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x552F8BFF);
            cv.drawRect(fx - h, fy - h, fx + h, fy + h, p);
            cv.drawRect(tx - h, ty - h, tx + h, ty + h, p);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(BLUE);
            p.setStrokeWidth(cell * 0.07f);
            cv.drawRect(fx - h + cell * 0.04f, fy - h + cell * 0.04f, fx + h - cell * 0.04f, fy + h - cell * 0.04f, p);
            p.setStrokeWidth(cell * 0.13f);
            cv.drawRect(tx - h + cell * 0.07f, ty - h + cell * 0.07f, tx + h - cell * 0.07f, ty + h - cell * 0.07f, p);

            float dx = tx - fx, dy = ty - fy;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len < 1f) return;
            float ux = dx / len, uy = dy / len;
            float headLen = cell * 0.42f, headW = cell * 0.30f;
            float sx = fx + ux * cell * 0.30f, sy = fy + uy * cell * 0.30f;     // start just outside the piece
            float bx = tx - ux * (cell * 0.28f + headLen), by = ty - uy * (cell * 0.28f + headLen);
            float ex = tx - ux * cell * 0.28f, ey = ty - uy * cell * 0.28f;
            p.setColor(0xEE2F8BFF);
            p.setStrokeWidth(cell * 0.16f);
            p.setStrokeCap(Paint.Cap.ROUND);
            cv.drawLine(sx, sy, bx, by, p);
            p.setStyle(Paint.Style.FILL);
            head.reset();
            head.moveTo(ex, ey);
            head.lineTo(bx - uy * headW, by + ux * headW);
            head.lineTo(bx + uy * headW, by - ux * headW);
            head.close();
            cv.drawPath(head, p);
            p.setStrokeCap(Paint.Cap.BUTT);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            float cell = getWidth() / 8f;
            int c = (int) (e.getX() / cell), r = (int) (e.getY() / cell);
            if (c < 0 || c > 7 || r < 0 || r > 7) return true;
            int sq = squareAt(r, c);
            Position pos = tracker.pos;
            for (int tg : targets) {
                if (tg == sq && sel >= 0) {
                    int from = sel;
                    clearSelection();
                    play(from, sq);
                    return true;
                }
            }
            char ch = pos.b[sq];
            if (ch != '.' && Rules.isWhite(ch) == pos.white) {
                sel = sq;
                List<Integer> list = new ArrayList<>();
                for (int m : Rules.legalMoves(pos)) {
                    if (Move.from(m) == sq && !list.contains(Move.to(m))) list.add(Move.to(m));
                }
                targets = new int[list.size()];
                for (int i = 0; i < targets.length; i++) targets[i] = list.get(i);
            } else {
                sel = -1;
                targets = new int[0];
            }
            invalidate();
            return true;
        }
    }

    // ================================================================== settings
    private void saveConfig() {
        try {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean("white", myWhite)
                    .putBoolean("t_unpred", unpredictable)
                    .putBoolean("t_brill", onlyBrilliant)
                    .putBoolean("t_gambit", bestGambit)
                    .putBoolean("t_mate", fastMate)
                    .putBoolean("t_ai", useAi)
                    .putBoolean("t_human", humanize)
                    .putInt("think4", thinkIdx)
                    .putInt("mode4", modeIdx)
                    .putInt("size3", sizeIdx)
                    .putBoolean("collapsed", featuresCollapsed)
                    .putString("shown", shownString())
                    .apply();
        } catch (Exception ignored) {
        }
    }

    private String shownString() {
        StringBuilder sb = new StringBuilder();
        for (boolean b : featureShown) sb.append(b ? '1' : '0');
        return sb.toString();
    }

    private void loadConfig() {
        java.util.Arrays.fill(featureShown, true);
        try {
            SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            myWhite = p.getBoolean("white", true);
            unpredictable = p.getBoolean("t_unpred", true);
            onlyBrilliant = p.getBoolean("t_brill", false);
            bestGambit = p.getBoolean("t_gambit", false);
            fastMate = p.getBoolean("t_mate", false);
            useAi = p.getBoolean("t_ai", false);
            humanize = p.getBoolean("t_human", false);
            thinkIdx = Math.max(0, Math.min(THINK_SECONDS.length - 1, p.getInt("think4", 0)));
            modeIdx = Math.max(0, Math.min(MODE_LABELS.length - 1, p.getInt("mode4", 7)));
            featuresCollapsed = p.getBoolean("collapsed", false);
            String shown = p.getString("shown", "");
            for (int i = 0; i < FEATURE_KEYS.length; i++) featureShown[i] = i >= shown.length() || shown.charAt(i) != '0';
            sizeIdx = Math.max(0, Math.min(BOARD_DP.length - 1, p.getInt("size3", 1)));
        } catch (Exception ignored) {
        }
    }
}
