package com.chesshelper.overlay.core;

import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/** Chooses the move to show, according to the switches. */
public final class Brain {
    public static final class Options {
        public boolean alien;               // "Alien Gambit": play it as White, answer it as Black
        public boolean counter;             // "Counter Gambit/Trap": spot the opponent's gambit or trap and answer it
        public int[] history;               // the moves played so far in this game (needed by "counter")
        public boolean bestGambit;          // "Use best Gambit/Trap"
        public boolean fastMate;            // "Fast Checkmate 100%"
        public boolean instant;             // "Instant" thinking
        public double thinkSeconds = 2;
        public boolean noBlunder;           // "No blunder (Risk)": every pick is checked against the best move

        public Options copy() {
            Options c = new Options();
            c.alien = alien;
            c.counter = counter;
            c.history = history;
            c.bestGambit = bestGambit;
            c.fastMate = fastMate;
            c.instant = instant;
            c.thinkSeconds = thinkSeconds;
            c.noBlunder = noBlunder;
            return c;
        }
    }

    public static final class Decision {
        public int move;
        public int from, to;
        public int score;               // centipawns, mover's view
        public String kind;             // "best", "gambit", "accurate", "mate", "counter"
        public String note;             // one line for the person
        public Engine.Result result;
    }

    private static final int MAX_BOOK_TRIES = 12;

    private final Gambits.Line[] book;

    public Brain() {
        this(Gambits.BOOK);
    }

    public Brain(Gambits.Line[] book) {
        this.book = book;
    }

    /**
     * @param failed keys of gambits/traps that already failed in this game; this method adds to it
     * @return null when there is no legal move
     */
    public Decision decide(Position pos, boolean myWhite, Options opt, Set<String> failed, Random rng,
                           AtomicBoolean cancel) {
        final Options o = opt;
        Engine eng = new Engine(cancel);
        if (o.instant) eng.setTableBits(16);
        double secs = o.instant ? 0.15 : Math.max(0.3, o.thinkSeconds);  // Instant: a sixth of a second (pondering often makes it zero)
        int depth = o.instant ? 8 : 40;                                   // the clock decides how deep it gets
        setHistory(eng, pos, o);

        // ---- 0. Alien Gambit (its own switch). It comes FIRST: nothing else may take its place.
        //      As White it plays the Alien Gambit line; when the opponent has left that line it plays another real
        //      gambit from the book instead. As Black it meets the Alien Gambit with 4...Bf5, otherwise a Black gambit.
        String alienNote = null;
        if (o.alien) {
            Decision ad = alienDecision(eng, pos, myWhite, o, rng);
            if (ad != null) return ad;
            alienNote = "Alien Gambit: no gambit is possible from here (the opponent has left every gambit line), so the best move is shown";
        }

        // ---- 1. Fast Checkmate 100%: a complete mate solver; a forced mate always wins over everything else
        if (o.fastMate) {
            int[] fm = eng.findMate(pos, o.instant ? 3 : 4, 6, o.instant ? 0.35 : 1.2, null);
            if (fm != null) {
                return make(pos, fm[0], Engine.MATE - (2 * fm[1] - 1), "mate", "Fast checkmate: forced mate in "
                        + fm[1] + (fm[1] == 1 ? " move!" : " moves!"), null);
            }
        }

        // ---- 2. Counter Gambit/Trap: recognise what the opponent is doing, then play the 100% accurate answer
        String counterNote = null;
        if (o.counter && o.history != null) {
            Gambits.Detected det = Gambits.detectOpponent(o.history, myWhite, book);
            if (det != null) {
                counterNote = "Counter: the opponent's moves match " + det.names + (det.trap ? " (a possible trap)" : " (a possible gambit)")
                        + ". Playing the 100% accurate answer";
                secs = Math.max(secs, o.instant ? 0.3 : 1.0);
                depth = Math.max(depth, 6);
            }
        }

        // ---- normal search. The search lists the candidates; the choice among them is made below.
        int searchMargin = o.noBlunder ? 80 : 0;
        Engine.Result r = eng.search(pos, depth, secs, searchMargin, 1, rng);
        if (r == null) return null;
        final double verifySecs = o.instant ? 0.08 : Math.min(1.0, Math.max(0.2, secs * 0.3));   // short, so Instant stays fast
        final int vdepth = Math.max(4, r.depth);                         // used by the built-in engine; Stockfish goes by time

        // ---- 3. gambit / trap book
        String bookNote = null;
        if (o.bestGambit && counterNote == null) {
            List<Gambits.Pick> picks = Gambits.matches(pos, myWhite, failed, book);
            int tries = 0;
            double check = Math.min(1.5, Math.max(0.25, secs));
            final int allowed = 70;                                      // a gambit is only played when it is rated about as well as the best move
            final int floor = -80;
            for (Gambits.Pick pk : picks) {
                if (tries++ >= MAX_BOOK_TRIES) break;
                int s = pk.move == r.bestMove ? r.bestScore : eng.scoreMove(pos, pk.move, Math.max(4, r.depth), check);
                boolean sound = s != Integer.MIN_VALUE && s >= r.bestScore - allowed && s >= floor;
                if (sound) {
                    return make(pos, pk.move, s, "gambit",
                            pk.line.name + (pk.line.isTrap() ? " (trap, book move)" : " (gambit, book move)"), r);
                }
                if (failed != null) failed.add(pk.line.key());          // refuted: try the next one
                bookNote = pk.line.name + " failed";
            }
            if (bookNote != null) bookNote += "; playing the 100% accurate move";
            else bookNote = "No gambit or trap fits here; playing the 100% accurate move";
        }

        // ---- 5. the choice itself: the best move (a repetition is avoided when we are better)
        int move = r.bestMove;
        int score = r.bestScore;
        String kind = "best";
        String note = "The best move";
        boolean mate = r.bestScore >= Engine.MATE - 200;
        if (r.avoidedRepeat) {
            move = r.move;
            score = r.score;
            note = "Repetition avoided: you are better, so it plays on for the win";
        } else if (mate) {
            kind = "mate";
            note = "Forced mate!";
        } else {
            if (o.noBlunder) {                                         // a quick second look at the best move itself
                Engine.Result fixed = recheckBest(eng, pos, r, vdepth, verifySecs);
                if (fixed != null) {
                    move = fixed.bestMove;
                    score = fixed.bestScore;
                    r = fixed;
                    note = "No blunder: the first choice looked risky, so a safer move was taken";
                }
            }
        }
        Decision d = make(pos, move, score, kind, note, r);
        if (alienNote != null && bookNote == null) bookNote = alienNote;
        if (counterNote != null) {
            d.kind = "counter";
            bookNote = bookNote == null ? counterNote : counterNote + ". " + bookNote;
        }
        if (bookNote != null) {
            d.note = bookNote + (bookNote.endsWith(".") ? "" : ".") + (d.note.equals("The best move") ? "" : " " + d.note);
            if (bookNote.contains("100% accurate") && !d.kind.equals("counter")) d.kind = "accurate";
        }
        return d;
    }

    /**
     * No blunder: the chosen special move (a gambit, ...) must be rated about as well as the engine's
     * best move in a fair comparison, otherwise the best move is shown instead.
     */
    private Decision guard(Engine eng, Position pos, Decision d, Engine.Result r, int allowed, int depth,
                           double secs) {
        if (d.move == r.bestMove || d.kind.equals("mate")) return d;
        int s = eng.scoreMove(pos, d.move, depth, secs);
        int sb = eng.scoreMove(pos, r.bestMove, depth, secs);
        boolean ok = s != Integer.MIN_VALUE && sb != Integer.MIN_VALUE && (s >= Engine.MATE - 200 || s >= sb - allowed);
        if (ok) return d;
        Decision safe = make(pos, r.bestMove, r.bestScore, "accurate",
                "No blunder: the special move did not hold up, so here is the best move", r);
        return safe;
    }

    /**
     * Looks at the best move once more (a fresh, focused search of only that move). If it now drops a lot, the
     * runner-up is checked the same way and used when it is clearly better.
     *
     * @return a result whose bestMove/bestScore are the safer move, or null when the best move stands
     */
    private Engine.Result recheckBest(Engine eng, Position pos, Engine.Result r, int depth, double secs) {
        if (r.candidates == null || r.candidates.length < 2) return null;
        int s1 = eng.scoreMove(pos, r.bestMove, depth, secs);
        if (s1 == Integer.MIN_VALUE || s1 >= r.bestScore - 120) return null;
        int alt = r.candidates[1];
        int s2 = eng.scoreMove(pos, alt, depth, secs);
        if (s2 == Integer.MIN_VALUE || s2 <= s1 + 30) return null;
        Engine.Result n = new Engine.Result();
        n.move = alt;
        n.bestMove = alt;
        n.score = s2;
        n.bestScore = s2;
        n.depth = r.depth;
        n.alternatives = new int[]{r.bestMove};
        n.candidates = new int[]{alt};
        n.candidateScores = new int[]{s2};
        return n;
    }

    /** Lets the engine know the positions already played, so it avoids (or takes) repetitions. */
    private static void setHistory(Engine eng, Position pos, Options o) {
        if (o.history == null || o.history.length == 0) return;
        try {
            Position p = Position.fromFen(Rules.START_FEN);
            long[] hs = new long[o.history.length];
            for (int i = 0; i < o.history.length; i++) {
                hs[i] = Engine.hash(p);
                p = Rules.apply(p, o.history[i]);
            }
            if (Engine.hash(p) == Engine.hash(pos)) eng.setGameHistory(hs);     // only when it is really this game
        } catch (RuntimeException ignored) {
        }
    }

    /** The Alien Gambit step. @return null only when no gambit of any kind fits the position */
    private Decision alienDecision(Engine eng, Position pos, boolean myWhite, Options o, Random rng) {
        double check = o.instant ? 0.1 : 0.3;
        if (myWhite) {
            int am = Gambits.alienMove(pos, o.history);
            if (am >= 0) {
                return make(pos, am, quickScore(eng, pos, am, check), "gambit",
                        "Alien Gambit (book move): 1.e4 c6 2.d4 d5 3.Nc3 dxe4 4.Nxe4 Nf6 5.Ng5 and then 6.Nxf7, a knight sacrifice. "
                                + "It is a risky surprise weapon, and it is played every time", null);
            }
        } else {
            int cm = Gambits.alienCounter(pos);
            if (cm >= 0) {
                return make(pos, cm, quickScore(eng, pos, cm, check), "counter",
                        "Alien Gambit counter: 4...Bf5 keeps the bishop out and avoids the Nxf7 sacrifice", null);
            }
        }
        // the opponent is not in the Alien Gambit line: play another real gambit (the best-rated one that fits)
        List<Gambits.Pick> picks = Gambits.matches(pos, myWhite, null, book);
        Gambits.Pick bestPick = null;
        int bestScore = Integer.MIN_VALUE;
        int n = 0;
        for (Gambits.Pick pk : picks) {
            if (n++ >= 6) break;
            int s = quickScore(eng, pos, pk.move, check);
            if (bestPick == null || s > bestScore) {
                bestPick = pk;
                bestScore = s;
            }
        }
        if (bestPick == null) return null;
        return make(pos, bestPick.move, bestScore, "gambit",
                "Alien Gambit mode: the opponent left the Alien line, so it plays another real gambit: " + bestPick.line.name
                        + (bestPick.line.isTrap() ? " (trap, book move)" : " (gambit, book move)"), null);
    }

    /** A short look at a move, for the evaluation shown only (0 when it cannot be rated). */
    private static int quickScore(Engine eng, Position pos, int move, double secs) {
        try {
            int s = eng.scoreMove(pos, move, 8, secs);
            return s == Integer.MIN_VALUE ? 0 : s;
        } catch (RuntimeException e) {
            return 0;
        }
    }

    private static Decision make(Position pos, int move, int score, String kind, String note, Engine.Result r) {
        Decision d = new Decision();
        d.move = move;
        d.from = Move.from(move);
        d.to = Move.to(move);
        d.score = score;
        d.kind = kind;
        d.note = note;
        d.result = r;
        return d;
    }
}
