package com.chesshelper.desktop;

import com.chesshelper.overlay.core.Brain;
import com.chesshelper.overlay.core.Engine;
import com.chesshelper.overlay.core.GameTracker;
import com.chesshelper.overlay.core.Move;
import com.chesshelper.overlay.core.Position;
import com.chesshelper.overlay.core.Rules;
import com.chesshelper.overlay.core.Texts;
import com.chesshelper.overlay.core.Uci;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Path2D;
import java.io.File;
import java.util.*;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.prefs.Preferences;

/**
 * Chess Helper for Windows / Linux / Mac: the same helper as the phone version, in a normal window.
 * You tap the opponent's moves on the board; on your turn the best move is shown with a box on the piece, a box on the
 * target square and an arrow. It does not read your screen, a website or any other program.
 */
public final class DesktopApp {
    private static final double[] THINK_SECONDS = {0.05, 1, 2, 3, 5, 8, 15, 30};
    private static final String[] THINK_NAMES = {"Instant", "1 s", "2 s", "3 s", "5 s", "8 s", "15 s", "30 s"};
    private static final Color BLUE = new Color(0x2F8BFF), RED = new Color(0xE53935), YELLOW = new Color(0xF2C200);

    private final Preferences prefs = Preferences.userNodeForPackage(DesktopApp.class);
    private final GameTracker tracker = new GameTracker(true);
    private final List<Position> history = new ArrayList<>();
    private final List<Integer> moveInts = new ArrayList<>();
    private final Set<String> failedGambits = new HashSet<>();
    private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "helper-engine");
        t.setDaemon(true);
        return t;
    });
    private volatile AtomicBoolean cancel = new AtomicBoolean(false);
    private int job;

    private boolean myWhite = true;
    private int hintMove = -1, pendMid = -1, pendWorst = -1;
    private String hintStatus = "";
    private String engineName = "built-in engine";
    private volatile String agentNames = "";
    private boolean agentsLoading;

    private JFrame frame;
    private BoardPanel board;
    private JTextArea status;
    private JButton btnDone;
    private JCheckBox cNoBlunder, cAlien, cGambit, cMate, cCounter, cWorst, cMid, cTop;
    private JComboBox<String> thinkBox, sideBox;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new DesktopApp().start());
    }

    // ------------------------------------------------------------------ window
    private void start() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }
        frame = new JFrame("Chess Helper");
        frame.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
        frame.addWindowListener(new java.awt.event.WindowAdapter() {
            @Override
            public void windowClosing(java.awt.event.WindowEvent e) {
                if (confirm("Are you sure to close?", "Close Chess Helper?")) shutdown();
            }
        });
        board = new BoardPanel();
        board.setPreferredSize(new Dimension(520, 520));
        board.setMinimumSize(new Dimension(240, 240));

        JPanel side = new JPanel();
        side.setLayout(new BoxLayout(side, BoxLayout.Y_AXIS));
        side.setBorder(BorderFactory.createEmptyBorder(8, 8, 8, 8));
        status = new JTextArea(7, 26);
        status.setEditable(false);
        status.setLineWrap(true);
        status.setWrapStyleWord(true);
        status.setFont(status.getFont().deriveFont(Font.BOLD, 13f));
        side.add(new JScrollPane(status));
        side.add(Box.createVerticalStrut(6));

        btnDone = new JButton("Done ✔  (place the move)");
        btnDone.setFont(btnDone.getFont().deriveFont(Font.BOLD, 14f));
        btnDone.addActionListener(e -> done());
        JButton undo = new JButton("Undo move");
        undo.addActionListener(e -> undo());
        JButton newGame = new JButton("New game");
        newGame.addActionListener(e -> {
            if (confirm("Are you sure to start a new game?\nThe game on the helper board is cleared.", "New game")) newGame();
        });
        side.add(row(btnDone));
        side.add(row(undo, newGame));

        thinkBox = new JComboBox<>(THINK_NAMES);
        thinkBox.setSelectedIndex(clamp(prefs.getInt("think2", 3), 0, THINK_NAMES.length - 1));
        thinkBox.addActionListener(e -> changed());
        sideBox = new JComboBox<>(new String[]{"My pieces: White", "My pieces: Black"});
        sideBox.setSelectedIndex(prefs.getBoolean("white", true) ? 0 : 1);
        sideBox.addActionListener(e -> {
            boolean white = sideBox.getSelectedIndex() == 0;
            if (white != myWhite) {
                if (confirm("Changing sides starts a new game. Continue?", "My pieces")) {
                    myWhite = white;
                    newGame();
                } else {
                    sideBox.setSelectedIndex(myWhite ? 0 : 1);
                }
            }
        });
        myWhite = sideBox.getSelectedIndex() == 0;
        tracker.myWhite = myWhite;
        side.add(row(new JLabel("Think time:"), thinkBox));
        side.add(row(sideBox));

        cNoBlunder = check(side, "No blunder (Risk check): every move is checked", "noblunder", true);
        cGambit = check(side, "Use best Gambit/Trap", "gambit", false);
        cAlien = check(side, "Alien Gambit (always a gambit: Alien as White, else another gambit)", "alien", false);
        cMate = check(side, "Fast Checkmate", "mate", true);
        cCounter = check(side, "Counter Gambit/Trap", "counter", false);
        cWorst = check(side, "Worst move (red)", "worst", false);
        cMid = check(side, "Mid move (yellow)", "mid", false);
        cTop = new JCheckBox("Always on top", prefs.getBoolean("top", true));
        cTop.addActionListener(e -> {
            frame.setAlwaysOnTop(cTop.isSelected());
            prefs.putBoolean("top", cTop.isSelected());
        });
        side.add(left(cTop));

        JScrollPane sideScroll = new JScrollPane(side, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        sideScroll.setBorder(null);
        sideScroll.getVerticalScrollBar().setUnitIncrement(16);
        sideScroll.setPreferredSize(new Dimension(380, 520));
        frame.getContentPane().add(board, BorderLayout.CENTER);
        frame.getContentPane().add(sideScroll, BorderLayout.EAST);
        frame.pack();
        frame.setMinimumSize(new Dimension(520, 320));
        frame.setAlwaysOnTop(cTop.isSelected());
        frame.setLocationByPlatform(true);
        frame.setVisible(true);
        setStatus("Starting the engine…");
        exec.execute(() -> {
            startEngines();
            SwingUtilities.invokeLater(this::advance);
        });
    }

    private JCheckBox check(JPanel side, String text, String key, boolean def) {
        JCheckBox c = new JCheckBox(text, prefs.getBoolean(key, def));
        c.addActionListener(e -> {
            prefs.putBoolean(key, c.isSelected());
                changed();
        });
        side.add(left(c));
        return c;
    }

    private static JComponent left(JComponent c) {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
        p.add(c);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, p.getPreferredSize().height + 2));
        return p;
    }

    private static JComponent row(JComponent... cs) {
        JPanel p = new JPanel(new GridLayout(1, cs.length, 6, 0));
        for (JComponent c : cs) p.add(c);
        p.setMaximumSize(new Dimension(Integer.MAX_VALUE, p.getPreferredSize().height + 6));
        p.setBorder(BorderFactory.createEmptyBorder(2, 0, 2, 0));
        return p;
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private boolean confirm(String message, String title) {
        Object[] options = {"Yes", "No"};
        return JOptionPane.showOptionDialog(frame, message, title, JOptionPane.YES_NO_OPTION,
                JOptionPane.QUESTION_MESSAGE, null, options, options[1]) == 0;
    }

    private void changed() {
        prefs.putInt("think2", thinkBox.getSelectedIndex());
        prefs.putBoolean("white", myWhite);
        advance();
    }

    private void shutdown() {
        Engine.agentsOn = false;
        try {
            if (Engine.uci != null) Engine.uci.close();
            for (Uci a : new ArrayList<>(Engine.agents)) a.close();
        } catch (RuntimeException ignored) {
        }
        frame.dispose();
        System.exit(0);
    }

    // ------------------------------------------------------------------ engines
    private static File engineDir() {
        List<File> cands = new ArrayList<>();
        try {
            File jar = new File(DesktopApp.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            cands.add(new File(jar.getParentFile(), "engines"));
        } catch (Exception ignored) {
        }
        cands.add(new File("engines"));
        for (File f : cands) if (f.isDirectory()) return f;
        return null;
    }

    private static boolean isWindows() {
        return System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    }

    /** Stockfish first (fast AVX2 build, then the plain one); every agent_*.exe in the folder is a second engine. */
    private void startEngines() {
        File dir = engineDir();
        int cores = Runtime.getRuntime().availableProcessors();
        long mem = Runtime.getRuntime().maxMemory();
        int threads = Math.max(1, Math.min(8, cores - 1));
        int hash = 256;
        if (dir != null) {
            String ext = isWindows() ? ".exe" : "";
            for (String n : new String[]{"stockfish-avx2", "stockfish-sse41"}) {
                File f = new File(dir, n + ext);
                if (!f.isFile()) continue;
                Uci u = Uci.start(f.getAbsolutePath(), threads, hash);
                if (u != null) {
                    Engine.uci = u;
                    engineName = u.name;
                    break;
                }
            }
            final File[] all = dir.listFiles();
            if (all != null && Engine.uci != null) {
                Arrays.sort(all);
                final int limit = cores >= 12 ? 3 : cores >= 8 ? 2 : 1;
                Engine.agentLimit = limit;
                // second engines load in the background, so the first move never waits for their networks
                Thread loader = new Thread(() -> {
                    StringBuilder names = new StringBuilder();
                    for (File f : all) {
                        if (!f.getName().toLowerCase(Locale.ROOT).startsWith("agent_")) continue;
                        if (Engine.agents.size() >= limit) break;
                        Uci a = Uci.startLowPriority(f.getAbsolutePath(), Math.max(1, cores / 4), 128);
                        if (a == null) continue;
                        String n = f.getName().toLowerCase(Locale.ROOT);
                        a.weight = n.contains("plenty") || n.contains("shash") ? 1 : 2;
                        Engine.agents.add(a);
                        names.append(names.length() == 0 ? "" : " + ").append(a.name.split(" ")[0]);
                        agentNames = names.toString();
                    }
                }, "agent-loader");
                loader.setDaemon(true);
                agentsLoading = true;
                loader.start();
            }
        }
        if (Engine.uci == null) engineName = "built-in engine (Stockfish did not start)";
    }

    // ------------------------------------------------------------------ game
    private void newGame() {
        cancelAll();
        tracker.myWhite = myWhite;
        tracker.reset();
        final Uci u = Engine.uci;
        if (u != null) exec.execute(u::newGame);
        for (final Uci a : new ArrayList<>(Engine.agents)) exec.execute(a::newGame);
        history.clear();
        moveInts.clear();
        failedGambits.clear();
        board.clearSelection();
        clearHint();
        advance();
    }

    private void undo() {
        if (history.isEmpty() || tracker.keys.size() < 2) return;
        cancelAll();
        tracker.pos = history.remove(history.size() - 1);
        if (!moveInts.isEmpty()) moveInts.remove(moveInts.size() - 1);
        tracker.keys.remove(tracker.keys.size() - 1);
        failedGambits.clear();
        board.clearSelection();
        clearHint();
        advance();
    }

    private void cancelAll() {
        job++;
        cancel.set(true);
        cancel = new AtomicBoolean(false);
    }

    /** A move tapped on the board; a promotion asks which piece (no king: that is not allowed in chess). */
    void play(int from, int to) {
        List<Integer> options = new ArrayList<>();
        for (int m : Rules.legalMoves(tracker.pos)) if (Move.from(m) == from && Move.to(m) == to) options.add(m);
        if (options.isEmpty()) return;
        if (options.size() == 1) {
            playMove(options.get(0));
            return;
        }
        boolean enemy = tracker.pos.white != myWhite;
        String[] names = new String[options.size()];
        for (int i = 0; i < names.length; i++) {
            char pr = Move.promo(options.get(i)) == 0 ? 'Q' : Move.promo(options.get(i));
            names[i] = Texts.pieceName(Character.toUpperCase(pr));
        }
        int pick = JOptionPane.showOptionDialog(frame,
                enemy ? "The enemy pawn reached your side.\nWhat did it become? (a king is not allowed in chess)"
                        : "Promote your pawn to:",
                "Promotion", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, names, names[0]);
        if (pick >= 0) playMove(options.get(pick));
    }

    private void playMove(int chosen) {
        Position pos = tracker.pos;
        cancelAll();
        history.add(pos);
        moveInts.add(chosen);
        tracker.pos = Rules.apply(pos, chosen);
        tracker.keys.add(tracker.pos.key());
        clearHint();
        advance();
    }

    private void clearHint() {
        hintMove = pendMid = pendWorst = -1;
        board.hint = -1;
        board.mid = board.worst = -1;
        board.repaint();
    }

    private void done() {
        if (hintMove < 0) {
            setStatus("No move is shown yet. Wait for your turn.");
            return;
        }
        playMove(hintMove);
    }

    private void setStatus(String s) {
        status.setText(s);
        status.setCaretPosition(0);
    }

    private void advance() {
        board.repaint();
        Position pos = tracker.pos;
        String end = Rules.outcome(pos, tracker.keys, null);
        if (end != null) {
            setStatus(end);
            return;
        }
        if (pos.white != myWhite) {
            setStatus("Opponent's turn. Click the piece they moved, then its new square.");
            return;
        }
        if (Engine.uci == null && agentNames.isEmpty() && engineName.equals("built-in engine")) {
            setStatus("Starting the engine…");
        } else {
            setStatus("Your turn - thinking…");
        }
        think();
    }

    private void think() {
        cancelAll();
        final int myJob = job;
        final AtomicBoolean flag = cancel;
        final Position pos = tracker.pos;
        final boolean mine = myWhite;
        final Brain.Options o = new Brain.Options();
        o.alien = cAlien.isSelected();
        o.counter = cCounter.isSelected();
        int[] hist = new int[moveInts.size()];
        for (int i = 0; i < hist.length; i++) hist[i] = moveInts.get(i);
        o.history = hist;
        o.bestGambit = cGambit.isSelected();
        o.fastMate = cMate.isSelected();
        o.instant = thinkBox.getSelectedIndex() == 0;
        o.thinkSeconds = THINK_SECONDS[thinkBox.getSelectedIndex()];
        o.noBlunder = cNoBlunder.isSelected();
        Engine.agentsOn = !Engine.agents.isEmpty();          // SuperChess: the companion engines always join in
        Engine.agentTolerance = 6;                              // a second opinion may only pick a practically equal move
        final boolean wantMid = cMid.isSelected(), wantWorst = cWorst.isSelected();
        final Set<String> failed = new HashSet<>(failedGambits);
        final Random rng = new Random();
        exec.execute(() -> {
            Brain.Decision d = null;
            String problem = null;
            try {
                d = new Brain().decide(pos, mine, o, failed, rng, flag);
            } catch (Throwable t) {
                problem = String.valueOf(t);
            }
            final Brain.Decision dec = d;
            final String err = problem;
            int[] mw = null;
            if (dec != null && (wantMid || wantWorst)) {
                try {
                    mw = new Engine(flag).midAndWorst(pos, dec.move, o.instant ? 0.25 : 0.6);
                } catch (Throwable ignored) {
                }
            }
            final int mid = mw != null && wantMid ? mw[0] : -1, worst = mw != null && wantWorst ? mw[1] : -1;
            SwingUtilities.invokeLater(() -> {
                if (myJob != job) return;
                failedGambits.addAll(failed);
                if (dec == null) {
                    setStatus(err != null ? "Could not think: " + err : "No move available.");
                    return;
                }
                hintMove = dec.move;
                pendMid = mid;
                pendWorst = worst;
                board.hint = dec.move;
                board.mid = mid;
                board.worst = worst;
                String piece = Texts.pieceName(Character.toUpperCase(pos.b[dec.from]));
                Texts.Described ds = Texts.describe(pos, dec.move);
                String tags = ds.tags.isEmpty() ? "" : " (" + String.join(", ", ds.tags) + ")";
                String depth = dec.result != null && dec.result.depth > 0 ? ", depth " + dec.result.depth : "";
                hintStatus = "Move the " + piece + " as shown by the blue arrow.\n"
                        + ds.text + tags + "\n" + dec.note + "\n" + Texts.evalText(dec.score)
                        + (mid >= 0 ? "  Yellow = mid move." : "") + (worst >= 0 ? "  Red = worst move." : "")
                        + "\nEngine: SuperChess" + (Engine.uci == null ? " (basic mode)" : "") + depth;
                setStatus(hintStatus);
                board.repaint();
            });
        });
    }

    // ------------------------------------------------------------------ board
    private final class BoardPanel extends JPanel {
        int sel = -1;
        int[] targets = new int[0];
        int hint = -1, mid = -1, worst = -1;

        BoardPanel() {
            setBackground(new Color(0x22262F));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseReleased(MouseEvent e) {
                    click(e.getX(), e.getY());
                }
            });
        }

        void clearSelection() {
            sel = -1;
            targets = new int[0];
            repaint();
        }

        void setHint(boolean show) {
            if (!show) hint = -1;
            else hint = hintMove;
            if (show) {
                mid = pendMid;
                worst = pendWorst;
            } else {
                mid = worst = -1;
            }
            repaint();
        }

        private int boardPx() {
            return Math.min(getWidth(), getHeight());
        }

        private int sq(int row, int col) {
            return myWhite ? row * 8 + col : (7 - row) * 8 + (7 - col);
        }

        private int colOf(int sq) {
            return myWhite ? sq % 8 : 7 - sq % 8;
        }

        private int rowOf(int sq) {
            return myWhite ? sq / 8 : 7 - sq / 8;
        }

        private void click(int x, int y) {
            int s = boardPx();
            int ox = (getWidth() - s) / 2, oy = (getHeight() - s) / 2;
            double cell = s / 8.0;
            int c = (int) ((x - ox) / cell), r = (int) ((y - oy) / cell);
            if (c < 0 || c > 7 || r < 0 || r > 7) return;
            int square = sq(r, c);
            Position pos = tracker.pos;
            for (int tg : targets) {
                if (tg == square && sel >= 0) {
                    int from = sel;
                    clearSelection();
                    play(from, square);
                    return;
                }
            }
            char ch = pos.b[square];
            if (ch != '.' && Rules.isWhite(ch) == pos.white) {
                sel = square;
                List<Integer> list = new ArrayList<>();
                for (int m : Rules.legalMoves(pos)) if (Move.from(m) == square && !list.contains(Move.to(m))) list.add(Move.to(m));
                targets = new int[list.size()];
                for (int i = 0; i < targets.length; i++) targets[i] = list.get(i);
            } else {
                sel = -1;
                targets = new int[0];
            }
            repaint();
        }

        @Override
        protected void paintComponent(Graphics g0) {
            super.paintComponent(g0);
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int s = boardPx();
            int ox = (getWidth() - s) / 2, oy = (getHeight() - s) / 2;
            float cell = s / 8f;
            g.translate(ox, oy);
            Position pos = tracker.pos;
            Font pf = pieceFont((int) (cell * 0.8f));
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
                    int square = sq(r, c);
                    g.setColor(((r + c) & 1) == 0 ? new Color(0xEEEED2) : new Color(0x769656));
                    g.fill(new Rectangle2D(c * cell, r * cell, cell, cell));
                    if (square == sel) {
                        g.setColor(new Color(255, 212, 0, 170));
                        g.fill(new Rectangle2D(c * cell, r * cell, cell, cell));
                    }
                    char ch = pos.b[square];
                    if (ch != '.') {
                        String gl = Texts.glyph(Character.toUpperCase(ch));
                        g.setFont(pf);
                        FontMetrics fm = g.getFontMetrics();
                        float x = c * cell + (cell - fm.stringWidth(gl)) / 2f, y = r * cell + cell * 0.78f;
                        boolean white = Rules.isWhite(ch);
                        Shape outline = pf.createGlyphVector(g.getFontRenderContext(), gl).getOutline(x, y);
                        g.setColor(white ? Color.WHITE : new Color(0x111111));
                        g.fill(outline);
                        g.setStroke(new BasicStroke(cell * 0.03f));
                        g.setColor(white ? new Color(0x222222) : Color.WHITE);
                        g.draw(outline);
                    }
                    for (int tg : targets) {
                        if (tg == square) {
                            g.setColor(new Color(0, 224, 0, 200));
                            g.fillOval((int) (c * cell + cell * 0.36f), (int) (r * cell + cell * 0.36f), (int) (cell * 0.28f), (int) (cell * 0.28f));
                        }
                    }
                }
            }
            g.setFont(g.getFont().deriveFont(cell * 0.2f));
            g.setColor(new Color(0x33442A));
            for (int i = 0; i < 8; i++) {
                g.drawString(String.valueOf((char) ('a' + (myWhite ? i : 7 - i))), i * cell + cell * 0.8f, 8 * cell - cell * 0.06f);
                g.drawString(String.valueOf(myWhite ? 8 - i : i + 1), cell * 0.05f, i * cell + cell * 0.22f);
            }
            if (worst >= 0) drawMove(g, cell, worst, RED);
            if (mid >= 0) drawMove(g, cell, mid, YELLOW);
            if (hint >= 0) drawMove(g, cell, hint, BLUE);
            g.dispose();
        }

        private Font pieceFont(int size) {
            for (String n : new String[]{"Segoe UI Symbol", "DejaVu Sans", "Arial Unicode MS", "Apple Symbols", "Dialog"}) {
                Font f = new Font(n, Font.PLAIN, size);
                if (f.canDisplay('♞')) return f;
            }
            return new Font("Dialog", Font.PLAIN, size);
        }

        private float cx(int square, float cell) {
            return colOf(square) * cell + cell / 2f;
        }

        private float cy(int square, float cell) {
            return rowOf(square) * cell + cell / 2f;
        }

        /** A box on the piece and on the target square, and an arrow between them. */
        private void drawMove(Graphics2D g, float cell, int move, Color color) {
            int from = Move.from(move), to = Move.to(move);
            float fx = cx(from, cell), fy = cy(from, cell), tx = cx(to, cell), ty = cy(to, cell);
            float h = cell / 2f;
            Color fill = new Color(color.getRed(), color.getGreen(), color.getBlue(), 85);
            g.setColor(fill);
            g.fill(new Rectangle2D(fx - h, fy - h, cell, cell));
            g.fill(new Rectangle2D(tx - h, ty - h, cell, cell));
            g.setColor(color);
            g.setStroke(new BasicStroke(cell * 0.07f));
            g.draw(new Rectangle2D(fx - h + cell * 0.04f, fy - h + cell * 0.04f, cell * 0.92f, cell * 0.92f));
            g.setStroke(new BasicStroke(cell * 0.13f));
            g.draw(new Rectangle2D(tx - h + cell * 0.07f, ty - h + cell * 0.07f, cell * 0.86f, cell * 0.86f));
            float dx = tx - fx, dy = ty - fy;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len < 1f) return;
            float ux = dx / len, uy = dy / len;
            float headLen = cell * 0.42f, headW = cell * 0.30f;
            float sx = fx + ux * cell * 0.30f, sy = fy + uy * cell * 0.30f;
            float bx = tx - ux * (cell * 0.28f + headLen), by = ty - uy * (cell * 0.28f + headLen);
            float ex = tx - ux * cell * 0.28f, ey = ty - uy * cell * 0.28f;
            g.setColor(new Color(color.getRed(), color.getGreen(), color.getBlue(), 235));
            g.setStroke(new BasicStroke(cell * 0.16f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.drawLine(Math.round(sx), Math.round(sy), Math.round(bx), Math.round(by));
            Path2D.Float head = new Path2D.Float();
            head.moveTo(ex, ey);
            head.lineTo(bx - uy * headW, by + ux * headW);
            head.lineTo(bx + uy * headW, by - ux * headW);
            head.closePath();
            g.fill(head);
        }
    }

    /** java.awt.geom.Rectangle2D.Float without the long name. */
    private static final class Rectangle2D extends java.awt.geom.Rectangle2D.Float {
        Rectangle2D(float x, float y, float w, float h) {
            super(x, y, w, h);
        }
    }
}
