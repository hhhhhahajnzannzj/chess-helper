import Foundation

/// A move: squares are numbered 0...63, a1 = 0, b1 = 1, ... h8 = 63.
struct Move: Equatable, Hashable {
    let from: Int
    let to: Int
    let promo: Character?          // "q", "r", "b" or "n" (lower case)

    var uci: String {
        var s = Chess.name(from) + Chess.name(to)
        if let p = promo { s.append(p) }
        return s
    }
}

enum Chess {
    static let files: [Character] = Array("abcdefgh")

    static func name(_ sq: Int) -> String {
        return String(files[sq % 8]) + String(sq / 8 + 1)
    }

    static func square(_ s: String) -> Int? {
        let c = Array(s)
        guard c.count >= 2 else { return nil }
        guard let f = files.firstIndex(of: c[0]) else { return nil }
        guard let r = Int(String(c[1])), r >= 1, r <= 8 else { return nil }
        return (r - 1) * 8 + f
    }

    static func pieceName(_ p: Character) -> String {
        switch p.lowercased() {
        case "k": return "King"
        case "q": return "Queen"
        case "r": return "Rook"
        case "b": return "Bishop"
        case "n": return "Knight"
        default: return "Pawn"
        }
    }

    static let knightSteps: [(Int, Int)] = [(1, 2), (2, 1), (-1, 2), (-2, 1), (1, -2), (2, -1), (-1, -2), (-2, -1)]
    static let kingSteps: [(Int, Int)] = [(1, 0), (-1, 0), (0, 1), (0, -1), (1, 1), (1, -1), (-1, 1), (-1, -1)]
    static let rookSteps: [(Int, Int)] = [(1, 0), (-1, 0), (0, 1), (0, -1)]
    static let bishopSteps: [(Int, Int)] = [(1, 1), (1, -1), (-1, 1), (-1, -1)]
}

struct Position {
    var b: [Character] = Array(repeating: ".", count: 64)
    var whiteToMove = true
    var castle = "KQkq"
    var ep = -1
    var half = 0
    var full = 1

    static let startFEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1"

    init() {}

    init?(fen: String) {
        let parts = fen.split(separator: " ").map { String($0) }
        guard parts.count >= 4 else { return nil }
        var rank = 7
        var file = 0
        for ch in parts[0] {
            if ch == "/" {
                rank -= 1
                file = 0
            } else if let d = ch.wholeNumberValue {
                file += d
            } else {
                guard rank >= 0, file < 8 else { return nil }
                b[rank * 8 + file] = ch
                file += 1
            }
        }
        whiteToMove = parts[1] == "w"
        castle = parts[2] == "-" ? "" : parts[2]
        ep = parts[3] == "-" ? -1 : (Chess.square(parts[3]) ?? -1)
        half = parts.count > 4 ? (Int(parts[4]) ?? 0) : 0
        full = parts.count > 5 ? (Int(parts[5]) ?? 1) : 1
    }

    static func start() -> Position {
        return Position(fen: startFEN) ?? Position()
    }

    var fen: String {
        var s = ""
        for r in stride(from: 7, through: 0, by: -1) {
            var empty = 0
            for f in 0..<8 {
                let p = b[r * 8 + f]
                if p == "." {
                    empty += 1
                } else {
                    if empty > 0 {
                        s += String(empty)
                        empty = 0
                    }
                    s.append(p)
                }
            }
            if empty > 0 { s += String(empty) }
            if r > 0 { s += "/" }
        }
        let side = whiteToMove ? "w" : "b"
        let rights = castle.isEmpty ? "-" : castle
        let epText = ep >= 0 ? Chess.name(ep) : "-"
        return s + " " + side + " " + rights + " " + epText + " " + String(half) + " " + String(full)
    }

    /// Board, side and rights only (for repetition counting).
    var key: String {
        let parts = fen.split(separator: " ").prefix(4)
        return parts.joined(separator: " ")
    }

    // MARK: attacks

    private func inside(_ r: Int, _ f: Int) -> Bool {
        return r >= 0 && r < 8 && f >= 0 && f < 8
    }

    func isAttacked(_ sq: Int, byWhite: Bool) -> Bool {
        let r = sq / 8
        let f = sq % 8
        let pawn: Character = byWhite ? "P" : "p"
        let knight: Character = byWhite ? "N" : "n"
        let king: Character = byWhite ? "K" : "k"
        let rook: Character = byWhite ? "R" : "r"
        let bishop: Character = byWhite ? "B" : "b"
        let queen: Character = byWhite ? "Q" : "q"
        let pr = byWhite ? r - 1 : r + 1
        for df in [-1, 1] {
            let pf = f + df
            if inside(pr, pf) && b[pr * 8 + pf] == pawn { return true }
        }
        for (dr, df) in Chess.knightSteps {
            let nr = r + dr
            let nf = f + df
            if inside(nr, nf) && b[nr * 8 + nf] == knight { return true }
        }
        for (dr, df) in Chess.kingSteps {
            let nr = r + dr
            let nf = f + df
            if inside(nr, nf) && b[nr * 8 + nf] == king { return true }
        }
        for (dr, df) in Chess.rookSteps {
            var nr = r + dr
            var nf = f + df
            while inside(nr, nf) {
                let p = b[nr * 8 + nf]
                if p != "." {
                    if p == rook || p == queen { return true }
                    break
                }
                nr += dr
                nf += df
            }
        }
        for (dr, df) in Chess.bishopSteps {
            var nr = r + dr
            var nf = f + df
            while inside(nr, nf) {
                let p = b[nr * 8 + nf]
                if p != "." {
                    if p == bishop || p == queen { return true }
                    break
                }
                nr += dr
                nf += df
            }
        }
        return false
    }

    var inCheck: Bool {
        let king: Character = whiteToMove ? "K" : "k"
        guard let k = b.firstIndex(of: king) else { return false }
        return isAttacked(k, byWhite: !whiteToMove)
    }

    // MARK: moves

    private func pseudoMoves() -> [Move] {
        var moves: [Move] = []
        let white = whiteToMove
        for sq in 0..<64 {
            let p = b[sq]
            if p == "." { continue }
            if p.isUppercase != white { continue }
            let r = sq / 8
            let f = sq % 8
            let t = p.lowercased()
            if t == "p" {
                let dir = white ? 1 : -1
                let startRank = white ? 1 : 6
                let lastRank = white ? 7 : 0
                let nr = r + dir
                if inside(nr, f) && b[nr * 8 + f] == "." {
                    addPawnMove(&moves, sq, nr * 8 + f, nr == lastRank)
                    if r == startRank && b[(r + 2 * dir) * 8 + f] == "." {
                        moves.append(Move(from: sq, to: (r + 2 * dir) * 8 + f, promo: nil))
                    }
                }
                for df in [-1, 1] {
                    let nf = f + df
                    if !inside(nr, nf) { continue }
                    let to = nr * 8 + nf
                    let target = b[to]
                    if target != "." && target.isUppercase != white {
                        addPawnMove(&moves, sq, to, nr == lastRank)
                    } else if target == "." && to == ep {
                        moves.append(Move(from: sq, to: to, promo: nil))
                    }
                }
            } else if t == "n" || t == "k" {
                let steps = t == "n" ? Chess.knightSteps : Chess.kingSteps
                for (dr, df) in steps {
                    let nr = r + dr
                    let nf = f + df
                    if !inside(nr, nf) { continue }
                    let target = b[nr * 8 + nf]
                    if target == "." || target.isUppercase != white {
                        moves.append(Move(from: sq, to: nr * 8 + nf, promo: nil))
                    }
                }
                if t == "k" { addCastling(&moves, sq, white) }
            } else {
                var steps: [(Int, Int)] = []
                if t == "r" || t == "q" { steps += Chess.rookSteps }
                if t == "b" || t == "q" { steps += Chess.bishopSteps }
                for (dr, df) in steps {
                    var nr = r + dr
                    var nf = f + df
                    while inside(nr, nf) {
                        let target = b[nr * 8 + nf]
                        if target == "." {
                            moves.append(Move(from: sq, to: nr * 8 + nf, promo: nil))
                        } else {
                            if target.isUppercase != white {
                                moves.append(Move(from: sq, to: nr * 8 + nf, promo: nil))
                            }
                            break
                        }
                        nr += dr
                        nf += df
                    }
                }
            }
        }
        return moves
    }

    private func addPawnMove(_ moves: inout [Move], _ from: Int, _ to: Int, _ promotes: Bool) {
        if promotes {
            for p in ["q", "r", "b", "n"] {
                moves.append(Move(from: from, to: to, promo: Character(p)))
            }
        } else {
            moves.append(Move(from: from, to: to, promo: nil))
        }
    }

    private func addCastling(_ moves: inout [Move], _ sq: Int, _ white: Bool) {
        let home = white ? 4 : 60
        if sq != home { return }
        let enemyIsWhite = !white
        if isAttacked(home, byWhite: enemyIsWhite) { return }
        let rook: Character = white ? "R" : "r"
        let kingSide: Character = white ? "K" : "k"
        let queenSide: Character = white ? "Q" : "q"
        if castle.contains(kingSide) && b[home + 1] == "." && b[home + 2] == "." && b[home + 3] == rook
            && !isAttacked(home + 1, byWhite: enemyIsWhite) && !isAttacked(home + 2, byWhite: enemyIsWhite) {
            moves.append(Move(from: home, to: home + 2, promo: nil))
        }
        if castle.contains(queenSide) && b[home - 1] == "." && b[home - 2] == "." && b[home - 3] == "." && b[home - 4] == rook
            && !isAttacked(home - 1, byWhite: enemyIsWhite) && !isAttacked(home - 2, byWhite: enemyIsWhite) {
            moves.append(Move(from: home, to: home - 2, promo: nil))
        }
    }

    func legalMoves() -> [Move] {
        var result: [Move] = []
        let king: Character = whiteToMove ? "K" : "k"
        for m in pseudoMoves() {
            let next = applying(m)
            guard let k = next.b.firstIndex(of: king) else { continue }
            if !next.isAttacked(k, byWhite: !whiteToMove) { result.append(m) }
        }
        return result
    }

    func applying(_ m: Move) -> Position {
        var n = self
        let p = b[m.from]
        let white = p.isUppercase
        var captured = b[m.to]
        let isPawn = p.lowercased() == "p"
        n.b[m.to] = p
        n.b[m.from] = "."
        if isPawn && m.to == ep && captured == "." && m.from % 8 != m.to % 8 {
            let capSq = white ? m.to - 8 : m.to + 8
            captured = n.b[capSq]
            n.b[capSq] = "."
        }
        if let pr = m.promo {
            n.b[m.to] = white ? Character(String(pr).uppercased()) : pr
        }
        if p.lowercased() == "k" && abs(m.to - m.from) == 2 {
            if m.to > m.from {
                n.b[m.from + 1] = n.b[m.from + 3]
                n.b[m.from + 3] = "."
            } else {
                n.b[m.from - 1] = n.b[m.from - 4]
                n.b[m.from - 4] = "."
            }
        }
        if p == "K" { n.castle = n.castle.filter { $0 != "K" && $0 != "Q" } }
        if p == "k" { n.castle = n.castle.filter { $0 != "k" && $0 != "q" } }
        for sq in [m.from, m.to] {
            if sq == 0 { n.castle = n.castle.filter { $0 != "Q" } }
            if sq == 7 { n.castle = n.castle.filter { $0 != "K" } }
            if sq == 56 { n.castle = n.castle.filter { $0 != "q" } }
            if sq == 63 { n.castle = n.castle.filter { $0 != "k" } }
        }
        n.ep = -1
        if isPawn && abs(m.to - m.from) == 16 { n.ep = (m.from + m.to) / 2 }
        n.half = (isPawn || captured != ".") ? 0 : half + 1
        if !white { n.full = full + 1 }
        n.whiteToMove = !whiteToMove
        return n
    }

    /// The legal move that matches an engine move such as "e2e4" or "e7e8q".
    func move(fromUCI s: String) -> Move? {
        guard s.count >= 4 else { return nil }
        let a = String(s.prefix(2))
        let c = String(s.dropFirst(2).prefix(2))
        guard let from = Chess.square(a), let to = Chess.square(c) else { return nil }
        let promo: Character? = s.count >= 5 ? s.last : nil
        let all = legalMoves()
        if let exact = all.first(where: { $0.from == from && $0.to == to && $0.promo == promo }) { return exact }
        return all.first(where: { $0.from == from && $0.to == to })
    }

    // MARK: end of game

    private var notEnoughMaterial: Bool {
        var others: [Character] = []
        for p in b where p != "." {
            let t = Character(p.lowercased())
            if t != "k" { others.append(t) }
        }
        if others.isEmpty { return true }
        if others.count == 1 && (others[0] == "n" || others[0] == "b") { return true }
        return false
    }

    func outcome(keys: [String]) -> String? {
        if legalMoves().isEmpty {
            if inCheck { return "Checkmate! " + (whiteToMove ? "Black" : "White") + " wins." }
            return "Stalemate: a draw."
        }
        if half >= 100 { return "Draw by the 50-move rule." }
        if notEnoughMaterial { return "Draw: not enough pieces to checkmate." }
        let k = key
        if keys.filter({ $0 == k }).count >= 3 { return "Draw by repetition." }
        return nil
    }
}
