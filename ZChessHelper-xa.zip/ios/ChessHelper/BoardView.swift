import SwiftUI

private let glyphs: [Character: String] = [
    "k": "\u{265A}\u{FE0E}", "q": "\u{265B}\u{FE0E}", "r": "\u{265C}\u{FE0E}",
    "b": "\u{265D}\u{FE0E}", "n": "\u{265E}\u{FE0E}", "p": "\u{265F}\u{FE0E}"
]

struct BoardView: View {
    @ObservedObject var game: GameModel

    private let light = Color(red: 0.93, green: 0.93, blue: 0.82)
    private let dark = Color(red: 0.46, green: 0.59, blue: 0.34)
    private let blue = Color(red: 0.18, green: 0.55, blue: 1.0)

    /// The square shown at a screen row/column (row 0 = top).
    private func square(row: Int, col: Int) -> Int {
        if game.myWhite {
            return (7 - row) * 8 + col
        }
        return row * 8 + (7 - col)
    }

    private func column(of sq: Int) -> Int {
        let f = sq % 8
        return game.myWhite ? f : 7 - f
    }

    private func row(of sq: Int) -> Int {
        let r = sq / 8
        return game.myWhite ? 7 - r : r
    }

    private func center(of sq: Int, cell: CGFloat) -> CGPoint {
        let x = (CGFloat(column(of: sq)) + 0.5) * cell
        let y = (CGFloat(row(of: sq)) + 0.5) * cell
        return CGPoint(x: x, y: y)
    }

    var body: some View {
        GeometryReader { geo in
            let size = min(geo.size.width, geo.size.height)
            let cell = size / 8
            ZStack(alignment: .topLeading) {
                squaresLayer(cell: cell)
                hintLayer(cell: cell)
                piecesLayer(cell: cell)
            }
            .frame(width: size, height: size)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0).onEnded { value in
                    let col = Int(value.location.x / cell)
                    let r = Int(value.location.y / cell)
                    if col >= 0 && col < 8 && r >= 0 && r < 8 {
                        game.tap(square(row: r, col: col))
                    }
                }
            )
        }
        .aspectRatio(1, contentMode: .fit)
    }

    @ViewBuilder
    private func squaresLayer(cell: CGFloat) -> some View {
        ForEach(0..<64, id: \.self) { i in
            let r = i / 8
            let c = i % 8
            let sq = square(row: r, col: c)
            let isDark = (r + c) % 2 == 1
            ZStack {
                Rectangle().fill(isDark ? dark : light)
                if game.selected == sq {
                    Rectangle().fill(Color.yellow.opacity(0.45))
                }
                if game.targets.contains(sq) {
                    Circle().fill(Color.black.opacity(0.25)).frame(width: cell * 0.3, height: cell * 0.3)
                }
            }
            .frame(width: cell, height: cell)
            .offset(x: CGFloat(c) * cell, y: CGFloat(r) * cell)
        }
    }

    @ViewBuilder
    private func piecesLayer(cell: CGFloat) -> some View {
        ForEach(0..<64, id: \.self) { i in
            let r = i / 8
            let c = i % 8
            let sq = square(row: r, col: c)
            let p = game.position.b[sq]
            if p != "." {
                let key = p.lowercased().first ?? "p"
                let text = glyphs[key] ?? "?"
                let isWhitePiece = p.isUppercase
                Text(text)
                    .font(.system(size: cell * 0.82))
                    .foregroundColor(isWhitePiece ? Color.white : Color.black)
                    .shadow(color: isWhitePiece ? Color.black : Color.white, radius: 0.8)
                    .shadow(color: isWhitePiece ? Color.black : Color.white, radius: 0.8)
                    .frame(width: cell, height: cell)
                    .offset(x: CGFloat(c) * cell, y: CGFloat(r) * cell)
                    .allowsHitTesting(false)
            }
        }
    }

    @ViewBuilder
    private func hintLayer(cell: CGFloat) -> some View {
        if let m = game.hint {
            let from = center(of: m.from, cell: cell)
            let to = center(of: m.to, cell: cell)
            ZStack(alignment: .topLeading) {
                Rectangle()
                    .stroke(blue, lineWidth: 4)
                    .frame(width: cell - 4, height: cell - 4)
                    .position(from)
                Rectangle()
                    .stroke(blue, lineWidth: 4)
                    .frame(width: cell - 4, height: cell - 4)
                    .position(to)
                ArrowShape(from: from, to: to, cell: cell)
                    .fill(blue.opacity(0.9))
            }
            .allowsHitTesting(false)
        }
    }
}

/// A straight arrow with a head, drawn from the middle of one square to the middle of another.
struct ArrowShape: Shape {
    let from: CGPoint
    let to: CGPoint
    let cell: CGFloat

    func path(in rect: CGRect) -> Path {
        var path = Path()
        let dx: CGFloat = to.x - from.x
        let dy: CGFloat = to.y - from.y
        let length: CGFloat = max(1, (dx * dx + dy * dy).squareRoot())
        let ux: CGFloat = dx / length
        let uy: CGFloat = dy / length
        let nx: CGFloat = -uy
        let ny: CGFloat = ux
        let shaft: CGFloat = cell * 0.09
        let headLength: CGFloat = cell * 0.38
        let headHalf: CGFloat = cell * 0.24
        let start = CGPoint(x: from.x + ux * cell * 0.3, y: from.y + uy * cell * 0.3)
        let tip = CGPoint(x: to.x - ux * cell * 0.12, y: to.y - uy * cell * 0.12)
        let baseX: CGFloat = tip.x - ux * headLength
        let baseY: CGFloat = tip.y - uy * headLength
        path.move(to: CGPoint(x: start.x + nx * shaft, y: start.y + ny * shaft))
        path.addLine(to: CGPoint(x: baseX + nx * shaft, y: baseY + ny * shaft))
        path.addLine(to: CGPoint(x: baseX + nx * headHalf, y: baseY + ny * headHalf))
        path.addLine(to: tip)
        path.addLine(to: CGPoint(x: baseX - nx * headHalf, y: baseY - ny * headHalf))
        path.addLine(to: CGPoint(x: baseX - nx * shaft, y: baseY - ny * shaft))
        path.addLine(to: CGPoint(x: start.x - nx * shaft, y: start.y - ny * shaft))
        path.closeSubpath()
        return path
    }
}
