import Foundation
import ChessKitEngine

/// One line of the engine's answer.
struct EngineLine {
    var multipv: Int
    var depth: Int
    var score: Int          // centipawns, from the side to move; forced mates are +-30000
    var move: String        // "e2e4"
}

/// Talks to the Stockfish that is built into the app (ChessKitEngine).
final class StockfishService {
    private let engine = Engine(type: .stockfish)
    private let lock = NSLock()
    private var lines: [Int: EngineLine] = [:]
    private var continuation: CheckedContinuation<[EngineLine], Never>?
    private var searching = false
    private var listener: Task<Void, Never>?
    private(set) var ready = false

    // MARK: start

    func start() async -> Bool {
        let cores = ProcessInfo.processInfo.activeProcessorCount
        await engine.start(coreCount: min(max(cores, 2), 5))
        guard let stream = await engine.responseStream else { return false }
        listener = Task { [weak self] in
            for await response in stream {
                self?.handle(response)
            }
        }
        for _ in 0..<600 {
            if await engine.isRunning { break }
            try? await Task.sleep(nanoseconds: 100_000_000)
        }
        guard await engine.isRunning else { return false }
        await engine.send(command: .setoption(id: "Hash", value: "64"))
        ready = true
        return true
    }

    // MARK: search

    /// Thinks about a position for `movetimeMs` milliseconds and returns the lines, best first.
    func search(fen: String, movetimeMs: Int, multipv: Int) async -> [EngineLine] {
        guard ready else { return [] }
        await cancelRunning()
        await engine.send(command: .setoption(id: "MultiPV", value: String(multipv)))
        await engine.send(command: .position(.fen(fen)))
        return await withCheckedContinuation { (cont: CheckedContinuation<[EngineLine], Never>) in
            self.begin(cont)
            Task {
                await self.engine.send(command: .go(movetime: movetimeMs))
            }
        }
    }

    func stopSearch() async {
        await cancelRunning()
    }

    func newGame() async {
        await cancelRunning()
        await engine.send(command: .ucinewgame)
    }

    // MARK: internals (the state is only touched through these small synchronous helpers)

    private func begin(_ cont: CheckedContinuation<[EngineLine], Never>) {
        lock.lock()
        lines = [:]
        continuation = cont
        searching = true
        lock.unlock()
    }

    private func takeContinuation() -> (CheckedContinuation<[EngineLine], Never>?, Bool) {
        lock.lock()
        let c = continuation
        continuation = nil
        let was = searching
        lock.unlock()
        return (c, was)
    }

    private func isSearching() -> Bool {
        lock.lock()
        let s = searching
        lock.unlock()
        return s
    }

    private func cancelRunning() async {
        let (c, was) = takeContinuation()
        c?.resume(returning: [])
        if was {
            await engine.send(command: .stop)
            for _ in 0..<40 {
                if !isSearching() { break }
                try? await Task.sleep(nanoseconds: 50_000_000)
            }
        }
    }

    private func store(_ line: EngineLine) {
        lock.lock()
        if let old = lines[line.multipv], old.depth > line.depth {
            lock.unlock()
            return
        }
        lines[line.multipv] = line
        lock.unlock()
    }

    private func finish(bestMove: String) {
        lock.lock()
        searching = false
        let c = continuation
        continuation = nil
        var result = lines.values.sorted { $0.multipv < $1.multipv }
        lock.unlock()
        guard let cont = c else { return }          // the search was cancelled: nobody waits for it
        if let i = result.firstIndex(where: { $0.move == bestMove }) {
            let best = result.remove(at: i)
            result.insert(best, at: 0)
        } else {
            let score = result.first?.score ?? 0
            result.insert(EngineLine(multipv: 1, depth: 0, score: score, move: bestMove), at: 0)
        }
        cont.resume(returning: result)
    }

    private func handle(_ response: EngineResponse) {
        switch response {
        case .info(let info):
            guard let pv = info.pv, let move = pv.first, let depth = info.depth, let score = info.score else { return }
            if score.lowerbound == true || score.upperbound == true { return }
            var value = 0
            if let mate = score.mate {
                value = mate > 0 ? 30000 - mate : -30000 - mate
            } else if let cp = score.cp {
                value = Int(cp)
            } else {
                return
            }
            store(EngineLine(multipv: info.multipv ?? 1, depth: depth, score: value, move: move))
        case .bestmove(let move, _):
            finish(bestMove: move)
        default:
            break
        }
    }
}
