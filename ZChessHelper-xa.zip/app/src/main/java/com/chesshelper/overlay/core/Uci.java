package com.chesshelper.overlay.core;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Talks to a real UCI chess engine (Stockfish) running as a separate process. Pure Java, no Android classes,
 * so it can be tested on a computer. Everything is synchronous: one analysis at a time.
 */
public final class Uci {
    /** One line of an analysis (one candidate move). */
    public static final class Line {
        public int multipv;
        public int depth;
        public int score;               // centipawns for the side to move; mates use the Engine.MATE scale
        public String move;             // e.g. "e2e4" (promotions "e7e8q")
    }

    private final Process proc;
    private final BufferedReader in;
    private final PrintWriter out;
    private volatile boolean alive = true;
    private int multiPv = 1;
    public String name = "UCI engine";
    /** How much this engine's opinion counts when it is a second engine: 2 = comparison engine, 1 = extra analysis. */
    public int weight = 2;

    private Uci(Process p) {
        this.proc = p;
        this.in = new BufferedReader(new InputStreamReader(p.getInputStream()));
        this.out = new PrintWriter(new OutputStreamWriter(p.getOutputStream()), true);
    }

    /** @return null when the engine cannot be started or does not answer */
    public static Uci start(String path, int threads, int hashMb) {
        Uci u = null;
        try {
            ProcessBuilder pb = new ProcessBuilder(path);
            pb.redirectErrorStream(true);
            u = new Uci(pb.start());
            u.send("uci");
            if (!u.waitFor("uciok", 20000)) {
                u.close();
                return null;
            }
            u.send("setoption name Threads value " + Math.max(1, threads));
            u.send("setoption name Hash value " + Math.max(1, hashMb));
            u.send("isready");
            if (!u.waitFor("readyok", 60000)) {                  // loading the network can take a moment
                u.close();
                return null;
            }
            return u;
        } catch (IOException | RuntimeException e) {
            if (u != null) u.close();
            return null;
        }
    }

    public boolean isAlive() {
        return alive;
    }

    private void send(String s) {
        out.println(s);
        if (out.checkError()) alive = false;
    }

    /** Reads the next line if one is waiting, else null (never blocks). */
    private String poll() throws IOException {
        if (in.ready()) return in.readLine();
        return null;
    }

    private boolean waitFor(String token, long timeoutMs) {
        long end = System.currentTimeMillis() + timeoutMs;
        try {
            while (System.currentTimeMillis() < end) {
                String l = poll();
                if (l == null) {
                    if (!procAlive()) return false;
                    Thread.sleep(5);
                    continue;
                }
                if (l.startsWith("id name ")) name = l.substring(8).trim();
                if (l.startsWith(token)) return true;
            }
        } catch (IOException | InterruptedException e) {
            return false;
        }
        return false;
    }

    private boolean procAlive() {
        try {
            proc.exitValue();
            return false;
        } catch (IllegalThreadStateException e) {
            return true;
        }
    }

    /** Forget the old game (call when a new game starts). */
    public synchronized void newGame() {
        if (!alive) return;
        send("ucinewgame");
        send("isready");
        waitFor("readyok", 10000);
    }

    /**
     * Analyses a position.
     *
     * @param fen        the position
     * @param multipv    how many best moves to report (1 = just the best)
     * @param ms         thinking time in milliseconds
     * @param cancel     set to true to stop early (the best result so far is still returned)
     * @param searchMove when not null, only this move (e.g. "e2e4") is analysed
     * @return the lines, best first; null when the engine failed
     */
    public synchronized List<Line> analyse(String fen, int multipv, int ms, AtomicBoolean cancel, String searchMove) {
        if (!alive) return null;
        try {
            if (multipv != multiPv) {
                send("setoption name MultiPV value " + multipv);
                multiPv = multipv;
            }
            send("position fen " + fen);
            send("go movetime " + Math.max(10, ms) + (searchMove != null ? " searchmoves " + searchMove : ""));
            Map<Integer, Line> lines = new HashMap<>();
            long start = System.currentTimeMillis();
            long hardLimit = start + ms + 8000;
            boolean stopped = false;
            while (true) {
                String l = poll();
                if (l == null) {
                    long now = System.currentTimeMillis();
                    if (!stopped && cancel != null && cancel.get()) {
                        send("stop");
                        stopped = true;
                    }
                    if (now > hardLimit || !procAlive()) {          // the engine hangs or died: give up on it
                        alive = false;
                        close();
                        return null;
                    }
                    Thread.sleep(1);
                    continue;
                }
                if (l.startsWith("bestmove")) {
                    if (lines.isEmpty()) {                           // e.g. a position with no legal move
                        return null;
                    }
                    break;
                }
                if (l.startsWith("info ")) parseInfo(l, lines);
            }
            List<Line> res = new ArrayList<>(lines.values());
            res.sort((a, b) -> a.multipv - b.multipv);
            return res;
        } catch (IOException | InterruptedException | RuntimeException e) {
            alive = false;
            close();
            return null;
        }
    }

    private static void parseInfo(String l, Map<Integer, Line> lines) {
        String[] t = l.split(" ");
        int depth = 0, mpv = 1;
        Integer score = null;
        String move = null;
        for (int i = 1; i < t.length; i++) {
            switch (t[i]) {
                case "depth":
                    depth = Integer.parseInt(t[++i]);
                    break;
                case "multipv":
                    mpv = Integer.parseInt(t[++i]);
                    break;
                case "score": {
                    String kind = t[++i];
                    int v = Integer.parseInt(t[++i]);
                    if (kind.equals("cp")) score = v;
                    else score = v > 0 ? Engine.MATE - (2 * v - 1) : 2 * (-v) - Engine.MATE;
                    if (i + 1 < t.length && (t[i + 1].equals("lowerbound") || t[i + 1].equals("upperbound"))) {
                        return;                                      // not a finished score
                    }
                    break;
                }
                case "pv":
                    if (i + 1 < t.length) move = t[i + 1];
                    i = t.length;
                    break;
                default:
                    break;
            }
        }
        if (score == null || move == null) return;
        Line old = lines.get(mpv);
        if (old != null && old.depth > depth) return;
        Line ln = new Line();
        ln.multipv = mpv;
        ln.depth = depth;
        ln.score = score;
        ln.move = move;
        lines.put(mpv, ln);
    }

    public synchronized void close() {
        alive = false;
        try {
            out.println("quit");
            out.flush();
        } catch (RuntimeException ignored) {
        }
        try {
            proc.destroy();
        } catch (RuntimeException ignored) {
        }
    }
}
