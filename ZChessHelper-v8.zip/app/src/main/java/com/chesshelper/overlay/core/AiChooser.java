package com.chesshelper.overlay.core;

import java.util.Locale;

/**
 * Asks Gemini to pick the best move from a short list that the built-in engine has already approved,
 * so the AI can never play a bad or illegal move.
 */
public final class AiChooser implements Brain.Chooser {
    private final AiPool pool;

    public AiChooser(AiPool pool) {
        this.pool = pool;
    }

    @Override
    public Brain.Choice choose(Position pos, int[] moves, int[] scores) throws Exception {
        StringBuilder list = new StringBuilder();
        for (int i = 0; i < moves.length; i++) {
            list.append(Rules.sqName(Move.from(moves[i]))).append(Rules.sqName(Move.to(moves[i])));
            list.append(" (engine ").append(String.format(Locale.US, "%+.2f", scores[i] / 100.0)).append(")");
            if (i < moves.length - 1) list.append(", ");
        }
        String prompt = "You are a chess grandmaster. Position (FEN): " + Fen.of(pos) + "\n"
                + (pos.white ? "White" : "Black") + " is to move. A chess engine approved these legal candidate "
                + "moves (from-square then to-square): " + list + ".\n"
                + "Pick the ONE best practical move from that list, thinking about tactics, king safety and the plan. "
                + "Reply with JSON only: {\"move\":\"e2e4\",\"why\":\"max 12 words\"}. The move MUST be one of the list.";
        AiPool.Answer a = pool.ask(prompt);
        String text = a.text;
        int i = text.indexOf('{'), j = text.lastIndexOf('}');
        if (i < 0 || j <= i) return null;
        Object root = MiniJson.parse(text.substring(i, j + 1));
        Object mv = MiniJson.get(root, "move");
        if (!(mv instanceof String)) return null;
        String want = ((String) mv).toLowerCase(Locale.US).replace("-", "").replace("x", "").replace(" ", "");
        for (int k = 0; k < moves.length; k++) {
            String c = Rules.sqName(Move.from(moves[k])) + Rules.sqName(Move.to(moves[k]));
            if (want.startsWith(c)) {
                Brain.Choice ch = new Brain.Choice();
                ch.move = moves[k];
                Object why = MiniJson.get(root, "why");
                ch.why = why instanceof String ? (String) why : "";
                ch.model = a.model + ", key " + a.keyNumber;
                return ch;
            }
        }
        return null;
    }
}
