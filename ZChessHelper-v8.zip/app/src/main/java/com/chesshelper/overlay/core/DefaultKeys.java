package com.chesshelper.overlay.core;

/**
 * Gemini keys used when the person leaves the key box blank. They are tried in order and the next one is
 * used automatically when a key hits its free limit. (Supplied by the owner of the app for their own use.)
 */
public final class DefaultKeys {
    private DefaultKeys() {
    }

    public static final String[] KEYS = {
            "AQ.Ab8RN6JIMim-VHhpu__PPPgtPF-H6tDD8G4ekfJluI7ZnbOOXQ",
            "AQ.Ab8RN6LnDGoORdHKwhCQPF6fXm1MnURcuGxk0oO8cyss-Ce4_A",
            "AQ.Ab8RN6JHTIjq_UGLbpPk8a9o8kQlgUDXvhkZB5TfWw2pizPg0w",
            "AQ.Ab8RN6JjigZzevGkYxVKRI1kaZbuHwhsCk5AetDbcVjqBUL2UQ",
    };
}
