package com.chesshelper.overlay.core;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Human-readable descriptions for the Helper window. */
public final class Texts {
    private Texts() {
    }

    public static String pieceName(char upper) {
        switch (upper) {
            case 'P':
                return "Pawn";
            case 'N':
                return "Knight";
            case 'B':
                return "Bishop";
            case 'R':
                return "Rook";
            case 'Q':
                return "Queen";
            default:
                return "King";
        }
    }

    public static String glyph(char upper) {
        switch (upper) {
            case 'P':
                return "♟︎";
            case 'N':
                return "♞";
            case 'B':
                return "♝";
            case 'R':
                return "♜";
            case 'Q':
                return "♛";
            default:
                return "♚";
        }
    }

    public static final class Described {
        public String text;                       // e.g. "Knight g1 -> f3"
        public List<String> tags = new ArrayList<>();
    }

    public static Described describe(Position pos, int m) {
        int f = Move.from(m), t = Move.to(m);
        char p = Character.toUpperCase(pos.b[f]);
        Described d = new Described();
        d.text = pieceName(p) + " " + Rules.sqName(f) + " → " + Rules.sqName(t);
        char cap = pos.b[t];
        if (cap != '.') d.tags.add("captures a " + pieceName(Character.toUpperCase(cap)).toLowerCase(Locale.ROOT));
        else if (p == 'P' && t == pos.ep) d.tags.add("captures en passant");
        if (p == 'K' && Math.abs(t - f) == 2) d.tags.add("castles " + (t > f ? "kingside" : "queenside"));
        char pr = Move.promo(m);
        if (pr != 0) d.tags.add("promotes to a " + pieceName(pr).toLowerCase(Locale.ROOT));
        Position child = Rules.apply(pos, m);
        if (Rules.inCheck(child)) d.tags.add(Rules.legalMoves(child).length == 0 ? "CHECKMATE!" : "gives check");
        return d;
    }

    public static String evalText(int score) {
        if (score >= Engine.MATE - 200)
            return "Forced checkmate in " + ((Engine.MATE - score + 1) / 2) + " move(s)!";
        if (score <= -Engine.MATE + 200)
            return "Danger: you may be mated in " + Math.max(1, (Engine.MATE + score) / 2) + " move(s).";
        String word;
        if (score > 300) word = "winning";
        else if (score > 100) word = "clearly better";
        else if (score > 30) word = "slightly better";
        else if (score >= -30) word = "about equal";
        else if (score >= -100) word = "slightly worse";
        else if (score >= -300) word = "clearly worse";
        else word = "losing";
        return String.format(Locale.US, "Evaluation %+.2f (%s)", score / 100.0, word);
    }

    public static double winChance(int score) {
        if (score >= Engine.MATE - 200) return 1.0;
        if (score <= -Engine.MATE + 200) return 0.0;
        return 1.0 / (1.0 + Math.pow(10, -score / 400.0));
    }
}
