package com.chesshelper.overlay.core;

import java.util.Arrays;
import java.util.List;

/** Chess rules: attacks, move generation, making moves, game end. */
public final class Rules {
    private Rules() {
    }

    public static final String START_FEN = "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1";

    private static final int[][] KNIGHT_D = {{-2, -1}, {-2, 1}, {-1, -2}, {-1, 2}, {1, -2}, {1, 2}, {2, -1}, {2, 1}};
    private static final int[][] KING_D = {{-1, -1}, {-1, 0}, {-1, 1}, {0, -1}, {0, 1}, {1, -1}, {1, 0}, {1, 1}};
    private static final int[][] BISHOP_D = {{-1, -1}, {-1, 1}, {1, -1}, {1, 1}};
    private static final int[][] ROOK_D = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

    public static String sqName(int i) {
        return "" + "abcdefgh".charAt(i & 7) + (8 - (i >> 3));
    }

    public static int nameSq(String s) {
        return (8 - (s.charAt(1) - '0')) * 8 + (s.charAt(0) - 'a');
    }

    public static boolean isWhite(char p) {
        return p >= 'A' && p <= 'Z';
    }

    /** Is square sq attacked by the given colour? */
    public static boolean attacked(char[] b, int sq, boolean byWhite) {
        int r = sq >> 3, c = sq & 7;
        int pr = byWhite ? r + 1 : r - 1;
        if (pr >= 0 && pr < 8) {
            char pawn = byWhite ? 'P' : 'p';
            if (c > 0 && b[pr * 8 + c - 1] == pawn) return true;
            if (c < 7 && b[pr * 8 + c + 1] == pawn) return true;
        }
        char knight = byWhite ? 'N' : 'n';
        for (int[] d : KNIGHT_D) {
            int nr = r + d[0], nc = c + d[1];
            if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8 && b[nr * 8 + nc] == knight) return true;
        }
        char king = byWhite ? 'K' : 'k';
        for (int[] d : KING_D) {
            int nr = r + d[0], nc = c + d[1];
            if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8 && b[nr * 8 + nc] == king) return true;
        }
        char bishop = byWhite ? 'B' : 'b', queen = byWhite ? 'Q' : 'q', rook = byWhite ? 'R' : 'r';
        for (int[] d : BISHOP_D) {
            int nr = r + d[0], nc = c + d[1];
            while (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
                char p = b[nr * 8 + nc];
                if (p != '.') {
                    if (p == bishop || p == queen) return true;
                    break;
                }
                nr += d[0];
                nc += d[1];
            }
        }
        for (int[] d : ROOK_D) {
            int nr = r + d[0], nc = c + d[1];
            while (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
                char p = b[nr * 8 + nc];
                if (p != '.') {
                    if (p == rook || p == queen) return true;
                    break;
                }
                nr += d[0];
                nc += d[1];
            }
        }
        return false;
    }

    /** Is the king of the given colour attacked? */
    public static boolean kingInCheck(char[] b, boolean white) {
        char k = white ? 'K' : 'k';
        for (int i = 0; i < 64; i++) {
            if (b[i] == k) return attacked(b, i, !white);
        }
        return false;
    }

    public static boolean inCheck(Position pos) {
        return kingInCheck(pos.b, pos.white);
    }

    private static void addPromos(IntList out, int f, int t) {
        out.add(Move.make(f, t, 'Q'));
        out.add(Move.make(f, t, 'R'));
        out.add(Move.make(f, t, 'B'));
        out.add(Move.make(f, t, 'N'));
    }

    /** All moves that obey piece movement (king safety is checked later). */
    public static void pseudoMoves(Position pos, IntList out) {
        char[] b = pos.b;
        boolean white = pos.white;
        out.clear();
        for (int f = 0; f < 64; f++) {
            char p = b[f];
            if (p == '.' || isWhite(p) != white) continue;
            int r = f >> 3, c = f & 7;
            char u = Character.toUpperCase(p);
            if (u == 'P') {
                int d = white ? -1 : 1, start = white ? 6 : 1, last = white ? 0 : 7, nr = r + d;
                if (nr >= 0 && nr < 8) {
                    int t = nr * 8 + c;
                    if (b[t] == '.') {
                        if (nr == last) {
                            addPromos(out, f, t);
                        } else {
                            out.add(Move.make(f, t, '\0'));
                            if (r == start && b[t + d * 8] == '.') out.add(Move.make(f, t + d * 8, '\0'));
                        }
                    }
                    for (int dc = -1; dc <= 1; dc += 2) {
                        int nc = c + dc;
                        if (nc >= 0 && nc < 8) {
                            int t2 = nr * 8 + nc;
                            char tp = b[t2];
                            if ((tp != '.' && isWhite(tp) != white) || t2 == pos.ep) {
                                if (nr == last) addPromos(out, f, t2);
                                else out.add(Move.make(f, t2, '\0'));
                            }
                        }
                    }
                }
            } else if (u == 'N' || u == 'K') {
                for (int[] d : (u == 'N' ? KNIGHT_D : KING_D)) {
                    int nr = r + d[0], nc = c + d[1];
                    if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
                        int t = nr * 8 + nc;
                        char tp = b[t];
                        if (tp == '.' || isWhite(tp) != white) out.add(Move.make(f, t, '\0'));
                    }
                }
                if (u == 'K') {
                    if (white && f == 60 && !attacked(b, 60, false)) {
                        if (pos.castle.indexOf('K') >= 0 && b[61] == '.' && b[62] == '.' && b[63] == 'R'
                                && !attacked(b, 61, false) && !attacked(b, 62, false))
                            out.add(Move.make(60, 62, '\0'));
                        if (pos.castle.indexOf('Q') >= 0 && b[59] == '.' && b[58] == '.' && b[57] == '.'
                                && b[56] == 'R' && !attacked(b, 59, false) && !attacked(b, 58, false))
                            out.add(Move.make(60, 58, '\0'));
                    } else if (!white && f == 4 && !attacked(b, 4, true)) {
                        if (pos.castle.indexOf('k') >= 0 && b[5] == '.' && b[6] == '.' && b[7] == 'r'
                                && !attacked(b, 5, true) && !attacked(b, 6, true))
                            out.add(Move.make(4, 6, '\0'));
                        if (pos.castle.indexOf('q') >= 0 && b[3] == '.' && b[2] == '.' && b[1] == '.'
                                && b[0] == 'r' && !attacked(b, 3, true) && !attacked(b, 2, true))
                            out.add(Move.make(4, 2, '\0'));
                    }
                }
            } else {
                int[][][] sets;                         // bishop, rook or queen (both)
                if (u == 'B') sets = new int[][][]{BISHOP_D};
                else if (u == 'R') sets = new int[][][]{ROOK_D};
                else sets = new int[][][]{BISHOP_D, ROOK_D};
                for (int[][] ds : sets) {
                    for (int[] d : ds) {
                        int nr = r + d[0], nc = c + d[1];
                        while (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) {
                            int t = nr * 8 + nc;
                            char tp = b[t];
                            if (tp == '.') {
                                out.add(Move.make(f, t, '\0'));
                            } else {
                                if (isWhite(tp) != white) out.add(Move.make(f, t, '\0'));
                                break;
                            }
                            nr += d[0];
                            nc += d[1];
                        }
                    }
                }
            }
        }
    }

    /** Returns a NEW position after move m. */
    public static Position apply(Position pos, int m) {
        int f = Move.from(m), t = Move.to(m);
        char promo = Move.promo(m);
        char[] b = pos.b.clone();
        char p = b[f];
        char captured = b[t];
        boolean white = isWhite(p);
        boolean pawn = p == 'P' || p == 'p';
        if (pawn && t == pos.ep && captured == '.' && (f & 7) != (t & 7)) {
            b[(f >> 3) * 8 + (t & 7)] = '.';           // en passant capture
            captured = 'p';
        }
        b[t] = p;
        b[f] = '.';
        if (promo != 0) b[t] = white ? promo : Character.toLowerCase(promo);
        if ((p == 'K' || p == 'k') && Math.abs(t - f) == 2) {      // castling: move the rook
            if (t > f) {
                b[f + 1] = b[f + 3];
                b[f + 3] = '.';
            } else {
                b[f - 1] = b[f - 4];
                b[f - 4] = '.';
            }
        }
        String castle = pos.castle;
        if (!castle.isEmpty()) {
            if (p == 'K') castle = castle.replace("K", "").replace("Q", "");
            else if (p == 'k') castle = castle.replace("k", "").replace("q", "");
            if (f == 63 || t == 63) castle = castle.replace("K", "");
            if (f == 56 || t == 56) castle = castle.replace("Q", "");
            if (f == 7 || t == 7) castle = castle.replace("k", "");
            if (f == 0 || t == 0) castle = castle.replace("q", "");
        }
        int ep = (pawn && Math.abs(t - f) == 16) ? (f + t) / 2 : -1;
        int half = (pawn || captured != '.') ? 0 : pos.half + 1;
        int full = pos.full + (pos.white ? 0 : 1);
        return new Position(b, !pos.white, castle, ep, half, full);
    }

    public static int[] legalMoves(Position pos) {
        IntList l = new IntList();
        pseudoMoves(pos, l);
        int[] out = new int[l.n];
        int k = 0;
        for (int i = 0; i < l.n; i++) {
            Position c = apply(pos, l.a[i]);
            if (!kingInCheck(c.b, pos.white)) out[k++] = l.a[i];
        }
        return Arrays.copyOf(out, k);
    }

    public static boolean insufficient(char[] b) {
        int others = 0;
        char only = 0;
        for (char p : b) {
            if (p != '.' && Character.toUpperCase(p) != 'K') {
                others++;
                only = Character.toUpperCase(p);
            }
        }
        if (others == 0) return true;
        return others == 1 && (only == 'N' || only == 'B');
    }

    /** Text describing how the game ended, or null if it goes on. */
    public static String outcome(Position pos, List<String> keys, int[] legal) {
        if (legal == null) legal = legalMoves(pos);
        if (legal.length == 0) {
            if (inCheck(pos)) return "Checkmate! " + (pos.white ? "Black" : "White") + " wins.";
            return "Stalemate - draw.";
        }
        if (pos.half >= 100) return "Draw by the 50-move rule.";
        if (insufficient(pos.b)) return "Draw - not enough material.";
        if (keys != null) {
            String k = pos.key();
            int n = 0;
            for (String s : keys) if (s.equals(k)) n++;
            if (n >= 3) return "Draw by repetition.";
        }
        return null;
    }
}
