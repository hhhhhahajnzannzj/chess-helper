package com.chesshelper.overlay.core;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Tiny JSON reader (objects -> Map, arrays -> List, numbers -> Double). Pure Java, no Android classes. */
public final class MiniJson {
    private final String s;
    private int i;

    private MiniJson(String s) {
        this.s = s;
    }

    public static Object parse(String text) {
        MiniJson p = new MiniJson(text);
        p.ws();
        Object v = p.value();
        p.ws();
        if (p.i != text.length()) throw new IllegalArgumentException("Unexpected text at " + p.i);
        return v;
    }

    /** Follow a path of String keys / Integer indexes; null when anything is missing. */
    public static Object get(Object root, Object... path) {
        Object cur = root;
        for (Object k : path) {
            if (cur instanceof Map && k instanceof String) cur = ((Map<?, ?>) cur).get(k);
            else if (cur instanceof List && k instanceof Integer) {
                List<?> l = (List<?>) cur;
                int idx = (Integer) k;
                cur = idx >= 0 && idx < l.size() ? l.get(idx) : null;
            } else return null;
            if (cur == null) return null;
        }
        return cur;
    }

    private void ws() {
        while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
    }

    private char next() {
        if (i >= s.length()) throw new IllegalArgumentException("Unexpected end of JSON");
        return s.charAt(i++);
    }

    private void expect(char c) {
        if (next() != c) throw new IllegalArgumentException("Expected '" + c + "' at " + (i - 1));
    }

    private Object value() {
        if (i >= s.length()) throw new IllegalArgumentException("Unexpected end of JSON");
        char c = s.charAt(i);
        if (c == '{') return object();
        if (c == '[') return array();
        if (c == '"') return string();
        if (s.startsWith("true", i)) {
            i += 4;
            return Boolean.TRUE;
        }
        if (s.startsWith("false", i)) {
            i += 5;
            return Boolean.FALSE;
        }
        if (s.startsWith("null", i)) {
            i += 4;
            return null;
        }
        return number();
    }

    private Map<String, Object> object() {
        Map<String, Object> m = new LinkedHashMap<String, Object>();
        expect('{');
        ws();
        if (i < s.length() && s.charAt(i) == '}') {
            i++;
            return m;
        }
        while (true) {
            ws();
            String k = string();
            ws();
            expect(':');
            ws();
            m.put(k, value());
            ws();
            char c = next();
            if (c == ',') continue;
            if (c == '}') return m;
            throw new IllegalArgumentException("Expected ',' or '}' at " + (i - 1));
        }
    }

    private List<Object> array() {
        List<Object> l = new ArrayList<Object>();
        expect('[');
        ws();
        if (i < s.length() && s.charAt(i) == ']') {
            i++;
            return l;
        }
        while (true) {
            ws();
            l.add(value());
            ws();
            char c = next();
            if (c == ',') continue;
            if (c == ']') return l;
            throw new IllegalArgumentException("Expected ',' or ']' at " + (i - 1));
        }
    }

    private String string() {
        expect('"');
        StringBuilder sb = new StringBuilder();
        while (true) {
            char c = next();
            if (c == '"') return sb.toString();
            if (c != '\\') {
                sb.append(c);
                continue;
            }
            char e = next();
            switch (e) {
                case 'n':
                    sb.append('\n');
                    break;
                case 't':
                    sb.append('\t');
                    break;
                case 'r':
                    sb.append('\r');
                    break;
                case 'b':
                    sb.append('\b');
                    break;
                case 'f':
                    sb.append('\f');
                    break;
                case 'u':
                    if (i + 4 > s.length()) throw new IllegalArgumentException("Bad \\u escape");
                    sb.append((char) Integer.parseInt(s.substring(i, i + 4), 16));
                    i += 4;
                    break;
                default:
                    sb.append(e);          // \" \\ \/
            }
        }
    }

    private Double number() {
        int st = i;
        while (i < s.length() && "+-0123456789.eE".indexOf(s.charAt(i)) >= 0) i++;
        if (st == i) throw new IllegalArgumentException("Unexpected character '" + s.charAt(i) + "' at " + i);
        return Double.valueOf(s.substring(st, i));
    }
}
