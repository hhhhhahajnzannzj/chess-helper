package com.chesshelper.overlay.core;

import com.chesshelper.overlay.core.GeminiClient.GeminiException;

/**
 * Several Gemini keys behind one door. It sticks to the key that works; when a key is rate-limited
 * (free quota used up) or refused, it moves on to the next key by itself.
 */
public final class AiPool {
    public static final class Answer {
        public String text;
        public String model;
        public int keyNumber;               // 1-based position in the key list
    }

    private final String[] keys;
    private final GeminiClient[] clients;
    private final long[] cooldownUntil;
    private final boolean[] dead;
    private final long budgetMs;
    private int cur;

    public AiPool(String[] keys, String base, String[] models, int readTimeoutMs, long budgetMs) {
        this.keys = keys;
        this.budgetMs = budgetMs;
        clients = new GeminiClient[keys.length];
        cooldownUntil = new long[keys.length];
        dead = new boolean[keys.length];
        for (int i = 0; i < keys.length; i++) {
            clients[i] = new GeminiClient(keys[i], base, models);
            clients[i].setReadTimeoutMs(readTimeoutMs);
        }
    }

    public int size() {
        return keys.length;
    }

    public synchronized Answer ask(String prompt) throws GeminiException {
        long start = System.currentTimeMillis();
        String last = "no key";
        int n = keys.length;
        for (int i = 0; i < n; i++) {
            int k = (cur + i) % n;
            long now = System.currentTimeMillis();
            if (now - start > budgetMs) {
                last = "out of time";
                break;
            }
            if (dead[k] || cooldownUntil[k] > now) continue;
            try {
                String[] r = clients[k].askJson(prompt);
                cur = k;
                Answer a = new Answer();
                a.text = r[0];
                a.model = r[1];
                a.keyNumber = k + 1;
                return a;
            } catch (GeminiClient.GeminiException e) {
                last = "key " + (k + 1) + ": " + e.getMessage();
                if (e.fatal) dead[k] = true;
                else cooldownUntil[k] = System.currentTimeMillis() + Math.max(5, e.waitSeconds) * 1000L;
            }
        }
        boolean allDead = true;
        for (boolean d : dead) if (!d) allDead = false;
        throw new GeminiClient.GeminiException("No Gemini key could answer (" + last + ")", allDead, 10);
    }
}
