package com.chesshelper.overlay.core;

import java.util.Arrays;

/** Board picture geometry: orientation mapping and snapping a rough selection to the real grid. */
public final class BoardGeometry {
    private BoardGeometry() {
    }

    /** Square number (0 = a8 ... 63 = h1) of the i-th displayed cell (row-major, top-left first). */
    public static int imgIndex(int i, boolean flipped) {
        int r = i / 8, c = i % 8;
        return flipped ? (7 - r) * 8 + (7 - c) : i;
    }

    /**
     * @param rows    8 strings of 8 chars, top displayed row first
     * @param flipped true when Black is at the bottom of the screen
     * @return board in rules order (0 = a8), or null when rows are malformed
     */
    public static char[] rowsToBoard(String[] rows, boolean flipped) {
        if (rows == null || rows.length != 8) return null;
        char[] b = new char[64];
        for (int r = 0; r < 8; r++) {
            if (rows[r] == null || rows[r].length() != 8) return null;
            for (int c = 0; c < 8; c++) b[imgIndex(r * 8 + c, flipped)] = rows[r].charAt(c);
        }
        return b;
    }

    // ------------------------------------------------------------------ snap selection to the grid
    private static int[] peaks(double[] profile, double icpt, double slope, int[] ks, double frac) {
        int[] pos = new int[ks.length];
        for (int i = 0; i < ks.length; i++) {
            double c = icpt + ks[i] * slope;
            int lo = Math.max((int) (c - frac * slope), 0);
            int hi = Math.min((int) (c + frac * slope), profile.length - 1);
            if (hi <= lo) return null;
            int arg = lo;
            for (int j = lo + 1; j < hi; j++) if (profile[j] > profile[arg]) arg = j;
            pos[i] = arg + 1;
        }
        return pos;
    }

    /** least-squares line through (ks, pos) -> {intercept, slope} */
    private static double[] polyfit(int[] ks, int[] pos) {
        double mk = 0, mp = 0;
        for (int i = 0; i < ks.length; i++) {
            mk += ks[i];
            mp += pos[i];
        }
        mk /= ks.length;
        mp /= ks.length;
        double num = 0, den = 0;
        for (int i = 0; i < ks.length; i++) {
            num += (ks[i] - mk) * (pos[i] - mp);
            den += (ks[i] - mk) * (ks[i] - mk);
        }
        double slope = num / den;
        return new double[]{mp - slope * mk, slope};
    }

    private static double[] fit(double[] profile, double origin, double step) {
        int[] ks = {1, 2, 3, 4, 5, 6, 7};
        int[] pos = peaks(profile, origin, step, ks, 0.25);            // rough fit
        if (pos == null) return null;
        double[] f = polyfit(ks, pos);
        if (Math.abs(f[1] - step) > 0.2 * step || Math.abs(f[0] - origin) > 0.8 * step) return null;
        pos = peaks(profile, f[0], f[1], ks, 0.1);                     // then a tight fit
        if (pos == null) return null;
        return polyfit(ks, pos);
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    private static int diff(int c0, int c1) {
        return Math.abs(((c1 >> 16) & 255) - ((c0 >> 16) & 255))
                + Math.abs(((c1 >> 8) & 255) - ((c0 >> 8) & 255))
                + Math.abs((c1 & 255) - (c0 & 255));
    }

    private static double median(double[] a, int n) {
        Arrays.sort(a, 0, n);
        return n % 2 == 1 ? a[n / 2] : (a[n / 2 - 1] + a[n / 2]) / 2;
    }

    /**
     * Snap a rough board rectangle to the real square grid, using the checkerboard's edges
     * (works in any position: a median over many rows/columns ignores the pieces).
     *
     * @param px screenshot (width W, height H) with a little margin around the board
     * @return {x, y, w, h} in px coordinates, or the input rectangle when it can't tell
     */
    public static int[] refineBoard(int[] px, int W, int H, int ax, int ay, int aw, int ah) {
        int[] approx = {ax, ay, aw, ah};
        double cw = aw / 8.0, chh = ah / 8.0;
        int xa = clamp((int) (ax + 0.1 * cw), 0, W - 1), xb = clamp((int) (ax + aw - 0.1 * cw), 0, W - 1);
        int ya = clamp((int) (ay + 0.1 * chh), 0, H - 1), yb = clamp((int) (ay + ah - 0.1 * chh), 0, H - 1);
        if (W < 3 || H < 3 || xb - xa < 16 || yb - ya < 16) return approx;
        double[] xprof = new double[W - 1];
        double[] tmp = new double[Math.max(xb - xa, yb - ya)];
        for (int x = 0; x < W - 1; x++) {                              // vertical edges: median over rows
            for (int y = ya; y < yb; y++) tmp[y - ya] = diff(px[y * W + x], px[y * W + x + 1]);
            xprof[x] = median(tmp, yb - ya);
        }
        double[] yprof = new double[H - 1];
        for (int y = 0; y < H - 1; y++) {                              // horizontal edges: median over columns
            for (int x = xa; x < xb; x++) tmp[x - xa] = diff(px[y * W + x], px[(y + 1) * W + x]);
            yprof[y] = median(tmp, xb - xa);
        }
        double[] fx = fit(xprof, ax, cw);
        double[] fy = fit(yprof, ay, chh);
        if (fx == null || fy == null) return approx;
        return new int[]{(int) Math.round(fx[0]), (int) Math.round(fy[0]),
                (int) Math.round(8 * fx[1]), (int) Math.round(8 * fy[1])};
    }
}
