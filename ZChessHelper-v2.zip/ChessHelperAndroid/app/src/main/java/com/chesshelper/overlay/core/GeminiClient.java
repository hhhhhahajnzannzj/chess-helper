package com.chesshelper.overlay.core;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Base64;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Reads a chess board from a picture using the Gemini API (free tier).
 *
 * It tries the models in order. When a model is rate-limited (HTTP 429) or unavailable it moves
 * on to the next one, so the free quotas of several models add up. Pure Java: no Android classes.
 */
public final class GeminiClient {
    public static final String DEFAULT_BASE = "https://generativelanguage.googleapis.com";

    /** Best first. All of them are on Google's free tier and accept images. */
    public static final String[] DEFAULT_MODELS = {
            "gemini-3.5-flash",
            "gemini-2.5-flash",
            "gemini-3.1-flash-lite",
            "gemini-3-flash-preview",
            "gemini-2.5-flash-lite"};

    static final String PROMPT =
            "You are a precise chess board reader. The image is a screenshot of ONE chess board "
                    + "(8x8 squares). Read every square and reply with JSON only, in exactly this shape:\n"
                    + "{\"rows\":[\"........\",\"........\",\"........\",\"........\",\"........\",\"........\","
                    + "\"........\",\"........\"],\"turn\":\"white\"}\n"
                    + "Rules:\n"
                    + "- rows[0] is the TOP row of the picture and rows[7] the BOTTOM row. Each row is a string of "
                    + "exactly 8 characters, LEFT to RIGHT as displayed. Do not mirror, flip or rotate the board.\n"
                    + "- Use K Q R B N P for WHITE pieces (king, queen, rook, bishop, knight, pawn) and "
                    + "k q r b n p for BLACK pieces. Use '.' for an empty square.\n"
                    + "- White pieces are the light-coloured pieces, black pieces the dark-coloured ones.\n"
                    + "- Ignore coordinate letters/numbers, arrows, dots, circles and coloured square highlights: "
                    + "they are not pieces.\n"
                    + "- Each side has exactly one king. Look carefully at every square and make sure every row "
                    + "has exactly 8 characters.\n"
                    + "- \"turn\" = which side is to move next (white or black) if you can tell, for example from the "
                    + "last-move highlight (the side that did NOT just move); otherwise \"unknown\".";

    public static final class Reading {
        public String[] rows;               // 8 strings of 8 chars, top row first (as displayed)
        public String turn = "unknown";     // "white", "black" or "unknown"
        public String model;                // model that answered
    }

    public static final class GeminiException extends Exception {
        private static final long serialVersionUID = 1L;
        public final boolean fatal;         // true = retrying will not help (bad key, no model...)
        public final int waitSeconds;       // when not fatal: try again after this long

        public GeminiException(String message, boolean fatal, int waitSeconds) {
            super(message);
            this.fatal = fatal;
            this.waitSeconds = waitSeconds;
        }
    }

    private static final class Http {
        int code;
        String body;
    }

    private static final class Out {
        String text;
        String model;
    }

    private final String key, base;
    private final String[] models;
    private final long[] blockedUntil;
    private final boolean[] dead;

    public GeminiClient(String apiKey, String baseUrl, String[] models) {
        this.key = apiKey == null ? "" : apiKey.trim();
        this.base = baseUrl;
        this.models = models;
        this.blockedUntil = new long[models.length];
        this.dead = new boolean[models.length];
    }

    // ------------------------------------------------------------------ public API
    public Reading readBoard(byte[] jpeg) throws GeminiException {
        Out out = generate(buildBody(PROMPT, jpeg));
        Reading r = parseReading(out.text);
        if (r == null) {
            throw new GeminiException("Gemini's answer was not a readable board", false, 2);
        }
        r.model = out.model;
        return r;
    }

    /** Sends a tiny text request to check that the key works. @return the model that answered */
    public String ping() throws GeminiException {
        String body = "{\"contents\":[{\"parts\":[{\"text\":" + quote("Reply with exactly the word OK.")
                + "}]}],\"generationConfig\":{\"temperature\":0}}";
        return generate(body).model;
    }

    // ------------------------------------------------------------------ request / response
    static String buildBody(String prompt, byte[] jpeg) {
        return "{\"contents\":[{\"parts\":[{\"text\":" + quote(prompt) + "},{\"inline_data\":{\"mime_type\":"
                + "\"image/jpeg\",\"data\":\"" + Base64.getEncoder().encodeToString(jpeg) + "\"}}]}],"
                + "\"generationConfig\":{\"temperature\":0,\"response_mime_type\":\"application/json\"}}";
    }

    static String quote(String s) {
        StringBuilder sb = new StringBuilder("\"");
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"':
                    sb.append("\\\"");
                    break;
                case '\\':
                    sb.append("\\\\");
                    break;
                case '\n':
                    sb.append("\\n");
                    break;
                case '\r':
                    sb.append("\\r");
                    break;
                case '\t':
                    sb.append("\\t");
                    break;
                default:
                    if (c < 0x20) sb.append(String.format("\\u%04x", (int) c));
                    else sb.append(c);
            }
        }
        return sb.append('"').toString();
    }

    private Http post(String model, String body) throws IOException {
        URL url = new URL(base + "/v1beta/models/" + model + ":generateContent");
        HttpURLConnection c = (HttpURLConnection) url.openConnection();
        try {
            c.setRequestMethod("POST");
            c.setConnectTimeout(15000);
            c.setReadTimeout(45000);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("x-goog-api-key", key);
            byte[] data = body.getBytes(Charset.forName("UTF-8"));
            c.setFixedLengthStreamingMode(data.length);
            OutputStream os = c.getOutputStream();
            os.write(data);
            os.close();
            Http h = new Http();
            h.code = c.getResponseCode();
            InputStream is = h.code < 400 ? c.getInputStream() : c.getErrorStream();
            h.body = is == null ? "" : readAll(is);
            return h;
        } finally {
            c.disconnect();
        }
    }

    private static String readAll(InputStream is) throws IOException {
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
        is.close();
        return new String(bos.toByteArray(), Charset.forName("UTF-8"));
    }

    private Out generate(String body) throws GeminiException {
        if (key.isEmpty()) throw new GeminiException("No Gemini API key. Paste it in the Chess Helper app.", true, 0);
        int attempts = 0;
        String lastMsg = "";
        for (int k = 0; k < models.length && attempts < 3; k++) {
            long now = System.currentTimeMillis();
            if (dead[k] || blockedUntil[k] > now) continue;
            attempts++;
            try {
                Http h = post(models[k], body);
                if (h.code == 200) {
                    String t = extractText(h.body);
                    if (t != null && !t.trim().isEmpty()) {
                        Out o = new Out();
                        o.text = t;
                        o.model = models[k];
                        return o;
                    }
                    blockedUntil[k] = now + 10000;
                    lastMsg = models[k] + ": empty answer";
                    continue;
                }
                String msg = errorMessage(h.body);
                lastMsg = models[k] + ": HTTP " + h.code + " " + msg;
                if (h.code == 429) {
                    blockedUntil[k] = now + retrySeconds(h.body) * 1000L;
                    continue;
                }
                if (h.code >= 500) {
                    blockedUntil[k] = now + 15000;
                    continue;
                }
                if (h.code == 401 || keyProblem(h.body)) {
                    throw new GeminiException("Gemini did not accept the API key (" + msg + ")", true, 0);
                }
                dead[k] = true;                 // 400/403/404: this model can't be used here
            } catch (IOException e) {
                blockedUntil[k] = now + 15000;
                lastMsg = models[k] + ": " + e;
            }
        }
        long now = System.currentTimeMillis();
        long soonest = Long.MAX_VALUE;
        for (int k = 0; k < models.length; k++) {
            if (!dead[k]) soonest = Math.min(soonest, Math.max(blockedUntil[k], now));
        }
        if (soonest == Long.MAX_VALUE) {
            throw new GeminiException("No Gemini model worked with this key. Last error: " + lastMsg, true, 0);
        }
        int wait = (int) Math.max(3, Math.min(90, (soonest - now) / 1000 + 1));
        throw new GeminiException("Gemini is busy or the free limit is reached (" + lastMsg + ")", false, wait);
    }

    private static boolean keyProblem(String body) {
        String b = body == null ? "" : body;
        return b.contains("API key not valid") || b.contains("API_KEY_INVALID") || b.contains("API key expired")
                || b.contains("unregistered callers") || b.contains("location is not supported");
    }

    private static int retrySeconds(String body) {
        Matcher m = Pattern.compile("\"retryDelay\"\\s*:\\s*\"(\\d+(?:\\.\\d+)?)s\"").matcher(body == null ? "" : body);
        if (m.find()) {
            int s = (int) Math.ceil(Double.parseDouble(m.group(1))) + 1;
            return Math.max(5, Math.min(120, s));
        }
        return 60;
    }

    private static String errorMessage(String body) {
        try {
            Object m = MiniJson.get(MiniJson.parse(body), "error", "message");
            if (m instanceof String) return (String) m;
        } catch (RuntimeException ignored) {
        }
        String b = body == null ? "" : body.trim();
        return b.length() > 160 ? b.substring(0, 160) : b;
    }

    /** candidates[0].content.parts[*].text joined (thought parts are skipped). */
    static String extractText(String responseBody) {
        try {
            Object parts = MiniJson.get(MiniJson.parse(responseBody), "candidates", 0, "content", "parts");
            if (!(parts instanceof List)) return null;
            StringBuilder sb = new StringBuilder();
            for (Object p : (List<?>) parts) {
                if (!(p instanceof Map)) continue;
                Map<?, ?> pm = (Map<?, ?>) p;
                if (Boolean.TRUE.equals(pm.get("thought"))) continue;
                Object t = pm.get("text");
                if (t instanceof String) sb.append((String) t);
            }
            return sb.toString();
        } catch (RuntimeException e) {
            return null;
        }
    }

    // ------------------------------------------------------------------ reading the answer
    /** Turns Gemini's text into a validated Reading (model not set); null if it is not a proper board. */
    static Reading parseReading(String text) {
        if (text == null) return null;
        int a = text.indexOf('{'), b = text.lastIndexOf('}');
        if (a < 0 || b <= a) return null;
        Object root;
        try {
            root = MiniJson.parse(text.substring(a, b + 1));
        } catch (RuntimeException e) {
            return null;
        }
        Object rowsObj = MiniJson.get(root, "rows");
        if (!(rowsObj instanceof List) || ((List<?>) rowsObj).size() != 8) return null;
        String[] rows = new String[8];
        for (int r = 0; r < 8; r++) {
            Object o = ((List<?>) rowsObj).get(r);
            if (!(o instanceof String)) return null;
            StringBuilder sb = new StringBuilder();
            for (char c : ((String) o).toCharArray()) {
                if (c >= '1' && c <= '8') {
                    for (int k = 0; k < c - '0'; k++) sb.append('.');           // tolerate FEN-style digits
                } else if ("KQRBNPkqrbnp.".indexOf(c) >= 0) {
                    sb.append(c);
                } else if (c == '-' || c == '_' || c == '0') {
                    sb.append('.');
                }                                                               // spaces, '|' ... ignored
            }
            if (sb.length() != 8) return null;
            rows[r] = sb.toString();
        }
        Reading rd = new Reading();
        rd.rows = rows;
        Object t = MiniJson.get(root, "turn");
        String turn = t instanceof String ? ((String) t).trim().toLowerCase() : "unknown";
        rd.turn = turn.startsWith("w") ? "white" : turn.startsWith("b") ? "black" : "unknown";
        return rd;
    }
}
