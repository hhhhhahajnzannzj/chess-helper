# Chess Helper (Android)

A floating chess board. You tap the moves (yours and the opponent's) on it, and on your turn it shows the best
move on its own board with a BLUE box on the piece, a BLUE box on the target square and an ARROW.
It reads nothing from the screen (no screen capture). Internet is used only by "Use AI", which talks to your own server (see `server/SETUP.md`); the Gemini key lives only on that server.

Window controls: Done (plays the shown move for you), Undo move, New game, Choose your mode (Bullet / Blitz
(Lightning) / Rapid / Daily), Think (Auto, Instant, 1-8 s), Unpredictable, Only Brilliant (strict: real, deeply verified piece sacrifice), Use best Gambit/Trap
(~380 book lines from Wikipedia's lists; falls back to another gambit, then 100% accurate play), Fast Checkmate 100% (dedicated mate finder, ~0.1 s),
Humanize (natural, varied, never a blunder, with a short changing pause), Use AI (your server's Gemini picks among engine-approved moves), Worst move (red box + arrow), Mid move (yellow box + arrow), My pieces, Board size. The gear in the title bar hides/shows all feature buttons (long-press: choose which)
of these; the X asks "Are you sure to close?".

Build: upload the zip to a GitHub repo; the Actions workflow builds `ChessHelper.apk` and publishes it under Releases.
Use for practice and games against the computer; most chess sites forbid engine help in games against people.
