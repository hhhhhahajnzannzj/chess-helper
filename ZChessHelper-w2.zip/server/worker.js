// Chess Helper AI server (Cloudflare Worker).
//
// The Gemini key(s) live ONLY here, as encrypted Cloudflare secrets. They are never in the app or on GitHub.
// The app sends a position and a few moves that the chess engine already approved; this server asks Gemini
// to pick one and returns it. It can't be used for anything else: the prompt is built here, the input is
// strictly checked, and every call needs your app password.
//
// Secrets / variables to set in Cloudflare (Settings > Variables and Secrets):
//   GEMINI_KEYS  (secret)   one or more Gemini API keys, separated by commas or new lines (rotates when one is limited)
//   APP_TOKEN    (secret)   a password you invent; type the same one in the app
//   MODELS       (optional) comma list of model names to try first, e.g. gemini-2.5-flash,gemini-2.5-flash-lite
//   RATE_PER_MIN (optional) max requests per minute per phone/IP (default 20)

const API = "https://generativelanguage.googleapis.com/v1beta";
const FALLBACK_MODELS = ["gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.0-flash"];
const KEY_REST_MS = 10 * 60 * 1000;      // a limited / refused key rests this long
const MODEL_REST_MS = 5 * 60 * 1000;     // a model that says "not found" or "quota" rests this long

// memory that lives as long as this worker instance (best effort, it is fine if it resets)
const state = { keyRest: new Map(), modelRest: new Map(), models: null, modelsAt: 0, hits: new Map(), next: 0 };

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json; charset=utf-8" } });

function keysOf(env) {
  return String(env.GEMINI_KEYS || env.GEMINI_API_KEY || "")
    .split(/[\s,;]+/).map((s) => s.trim()).filter(Boolean);
}

function tooMany(ip, env) {
  const limit = Math.max(1, parseInt(env.RATE_PER_MIN || "20", 10) || 20);
  const now = Date.now();
  const arr = (state.hits.get(ip) || []).filter((t) => now - t < 60000);
  arr.push(now);
  state.hits.set(ip, arr);
  if (state.hits.size > 2000) state.hits.clear();
  return arr.length > limit;
}

function sameText(a, b) {              // constant-time-ish comparison
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

const FEN_RE = /^[1-8pnbrqkPNBRQK/]{15,100} [wb] (?:-|[KQkq]{1,4}) (?:-|[a-h][36]) \d{1,3} \d{1,4}$/;
const UCI_RE = /^[a-h][1-8][a-h][1-8][qrbn]?$/;

function validate(body) {
  if (!body || typeof body !== "object") return "bad body";
  if (typeof body.fen !== "string" || !FEN_RE.test(body.fen)) return "bad fen";
  if (!Array.isArray(body.moves) || body.moves.length < 2 || body.moves.length > 6) return "bad moves";
  for (const m of body.moves) {
    if (!m || typeof m.uci !== "string" || !UCI_RE.test(m.uci)) return "bad move";
    if (typeof m.cp !== "number" || !isFinite(m.cp) || Math.abs(m.cp) > 200000) return "bad score";
  }
  if (new Set(body.moves.map((m) => m.uci)).size !== body.moves.length) return "duplicate moves";
  return null;
}

function buildPrompt(body) {
  const side = body.fen.split(" ")[1] === "w" ? "White" : "Black";
  const list = body.moves
    .map((m, i) => `${i + 1}. ${m.uci}  (engine score ${(m.cp / 100).toFixed(2)} pawns for ${side})`)
    .join("\n");
  return (
    `You are a strong chess coach. Position (FEN): ${body.fen}\n` +
    `${side} is to move. A chess engine already checked these candidate moves and all are sound:\n${list}\n\n` +
    `Pick the ONE move that is the most practical and instructive (initiative, safety, clear plan). ` +
    `Never pick a move that is not in the list. Reply with JSON only: {"move":"<uci from the list>","why":"<at most 14 words>"}`
  );
}

async function listModels(key) {
  if (state.models && Date.now() - state.modelsAt < 3600 * 1000) return state.models;
  try {
    const r = await fetch(`${API}/models?pageSize=200`, { headers: { "x-goog-api-key": key } });
    if (!r.ok) return null;
    const data = await r.json();
    const names = (data.models || [])
      .filter((m) => (m.supportedGenerationMethods || []).includes("generateContent"))
      .map((m) => String(m.name || "").replace(/^models\//, ""))
      .filter((n) => /flash/i.test(n) && !/(image|tts|live|audio|embed|robot|computer|thinking-exp|vision|learnlm)/i.test(n));
    const score = (n) => {                // newest version first, plain flash before flash-lite, stable before preview
      const v = (n.match(/gemini-(\d+(?:\.\d+)?)/) || [0, 0])[1];
      return parseFloat(v) * 100 + (/lite/i.test(n) ? 0 : 30) + (/preview|exp/i.test(n) ? 0 : 10);
    };
    names.sort((a, b) => score(b) - score(a));
    state.models = names;
    state.modelsAt = Date.now();
    return names;
  } catch (e) {
    return null;
  }
}

async function modelOrder(env, key) {
  const wanted = String(env.MODELS || "").split(/[\s,;]+/).map((s) => s.trim()).filter(Boolean);
  const found = (await listModels(key)) || [];
  const out = [];
  for (const n of [...wanted, ...found.slice(0, 4), ...FALLBACK_MODELS]) if (!out.includes(n)) out.push(n);
  return out.slice(0, 8);
}

async function askGemini(key, model, prompt, withThinkingOff) {
  const generationConfig = {
    temperature: 0.7,
    maxOutputTokens: 256,
    responseMimeType: "application/json",
  };
  if (withThinkingOff) generationConfig.thinkingConfig = { thinkingBudget: 0 };
  return fetch(`${API}/models/${encodeURIComponent(model)}:generateContent`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-goog-api-key": key },
    body: JSON.stringify({ contents: [{ role: "user", parts: [{ text: prompt }] }], generationConfig }),
  });
}

function textOf(data) {
  const parts = (((data || {}).candidates || [])[0] || {}).content?.parts || [];
  return parts.map((p) => p.text || "").join("");
}

function parseChoice(text, body) {
  let obj = null;
  try {
    obj = JSON.parse(text);
  } catch (e) {
    const m = text.match(/\{[\s\S]*?\}/);
    if (m) {
      try {
        obj = JSON.parse(m[0]);
      } catch (e2) {
        /* fall through */
      }
    }
  }
  if (!obj || typeof obj.move !== "string") return null;
  const mv = obj.move.trim().toLowerCase();
  if (!body.moves.some((m) => m.uci === mv)) return null;       // must be one of the engine-approved moves
  const why = String(obj.why || "").replace(/[\r\n\t]+/g, " ").slice(0, 120);
  return { move: mv, why };
}

async function choose(env, body) {
  const keys = keysOf(env);
  if (!keys.length) return { status: 500, error: "server has no GEMINI_KEYS secret" };
  const prompt = buildPrompt(body);
  const start = state.next++ % keys.length;
  const now = Date.now();
  let last = "no key could answer";
  let anyKeyTried = false;
  for (let k = 0; k < keys.length; k++) {
    const idx = (start + k) % keys.length;
    const key = keys[idx];
    if ((state.keyRest.get(key) || 0) > now) continue;
    anyKeyTried = true;
    const models = await modelOrder(env, key);
    for (const model of models) {
      if ((state.modelRest.get(model) || 0) > Date.now()) continue;
      let resp;
      try {
        resp = await askGemini(key, model, prompt, true);
        if (resp.status === 400) resp = await askGemini(key, model, prompt, false);   // model has no thinkingBudget
      } catch (e) {
        last = "network: " + String(e).slice(0, 60);
        continue;
      }
      if (resp.ok) {
        let data = null;
        try {
          data = await resp.json();
        } catch (e) {
          last = "unreadable answer";
          continue;
        }
        const choice = parseChoice(textOf(data), body);
        if (choice) return { status: 200, ok: { move: choice.move, why: choice.why, model, key: idx + 1 } };
        last = "model gave no valid move";
        continue;
      }
      last = `gemini ${resp.status}`;
      if (resp.status === 429) {                         // quota used up: rest this model, and if all of them say so, the key
        state.modelRest.set(model, Date.now() + MODEL_REST_MS);
        continue;
      }
      if (resp.status === 401 || resp.status === 403) {  // key refused (revoked, wrong, blocked): next key
        state.keyRest.set(key, Date.now() + KEY_REST_MS);
        break;
      }
      if (resp.status === 404) state.modelRest.set(model, Date.now() + MODEL_REST_MS);
    }
    if (last === "gemini 429") state.keyRest.set(key, Date.now() + 60 * 1000);       // all models limited on this key
  }
  if (!anyKeyTried) {                                     // every key is resting: give them one more chance
    state.keyRest.clear();
    state.modelRest.clear();
  }
  return { status: 503, error: last };
}

export default {
  async fetch(request, env) {
    if (request.method === "GET") return json({ ok: true, name: "chess-helper-ai" });     // quick "is it alive" check
    if (request.method !== "POST") return json({ error: "use POST" }, 405);
    if (!env.APP_TOKEN) return json({ error: "server has no APP_TOKEN secret" }, 500);
    const given = request.headers.get("x-app-token") || "";
    if (!sameText(given, String(env.APP_TOKEN))) return json({ error: "wrong app password" }, 401);
    const ip = request.headers.get("cf-connecting-ip") || "x";
    if (tooMany(ip, env)) return json({ error: "too many requests, slow down" }, 429);
    const raw = await request.text();
    if (raw.length > 3000) return json({ error: "too big" }, 413);
    let body;
    try {
      body = JSON.parse(raw);
    } catch (e) {
      return json({ error: "bad json" }, 400);
    }
    const bad = validate(body);
    if (bad) return json({ error: bad }, 400);
    const res = await choose(env, body);
    return res.ok ? json(res.ok) : json({ error: res.error }, res.status);
  },
};
