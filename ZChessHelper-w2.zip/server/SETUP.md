# Chess Helper AI server (free, phone only)

The Gemini key stays on this server as an encrypted secret. The app only knows the server address and a password
you invent. Nothing secret goes to GitHub or into the APK.

1. Get a NEW Gemini key: aistudio.google.com/apikey (sign in, "Create API key"). Never paste it into GitHub,
   a zip, or a chat. You can make 2-4 keys (one per Google account) and use them all.
2. Make a free account at dash.cloudflare.com. Open Workers & Pages > Create > Create Worker (Hello World) > Deploy.
3. Tap Edit code, delete everything, paste the whole text of `worker.js`, tap Deploy.
4. Open the worker > Settings > Variables and Secrets > Add. Add these as type "Secret":
   - `GEMINI_KEYS` = your key(s), separated by commas (more keys = it switches when one is limited)
   - `APP_TOKEN`   = a password you invent (long, random)
   Deploy again if it asks.
5. Copy the worker address (looks like https://something.yourname.workers.dev). Open it in Chrome: you should see
   {"ok":true,"name":"chess-helper-ai"}.
6. In the Chess Helper start screen, type the address and the same password, tap Save, then turn on "Use AI".

Free limits: Cloudflare Workers free plan = 100,000 requests/day. Gemini free keys have their own daily limits; when
they run out the app simply shows the engine's move.
