package com.chesshelper.overlay.core;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * "Use AI": asks YOUR Chess Helper AI server (the Cloudflare Worker in /server) to pick one of the moves the
 * engine approved. The Gemini key lives only on that server; this class knows just the server address and the
 * app password, which you type on the phone (they are not in the code).
 */
public final class AiClient implements Brain.Chooser {
    private final String url, token;
    private final int timeoutMs;

    public AiClient(String url, String token, int timeoutMs) {
        this.url = url == null ? "" : url.trim();
        this.token = token == null ? "" : token.trim();
        this.timeoutMs = timeoutMs;
    }

    static String uci(int m) {
        int promo = Move.promo(m);
        return Rules.sqName(Move.from(m)) + Rules.sqName(Move.to(m))
                + (promo != 0 && Character.toUpperCase((char) promo) != 'Q' ? String.valueOf(Character.toLowerCase((char) promo)) : "");
    }

    /** JSON body for the server (only the position and the approved moves). */
    static String body(Position pos, int[] moves, int[] scores) {
        StringBuilder sb = new StringBuilder("{\"fen\":\"").append(Fen.of(pos)).append("\",\"moves\":[");
        for (int i = 0; i < moves.length; i++) {
            if (i > 0) sb.append(',');
            sb.append("{\"uci\":\"").append(uci(moves[i])).append("\",\"cp\":").append(scores[i]).append('}');
        }
        return sb.append("]}").toString();
    }

    private static String field(String json, String name) {
        Matcher m = Pattern.compile("\"" + name + "\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(json);
        return m.find() ? m.group(1).replace("\\\"", "\"").replace("\\\\", "\\") : null;
    }

    @Override
    public Brain.Choice choose(Position pos, int[] moves, int[] scores) throws Exception {
        if (url.isEmpty()) throw new Exception("no AI server address (set it on the start screen)");
        boolean local = url.startsWith("http://127.0.0.1") || url.startsWith("http://localhost");
        if (!url.startsWith("https://") && !local) throw new Exception("the AI server address must start with https://");
        // underpromotions are not offered
        int n = 0;
        int[] mv = new int[moves.length], sc = new int[moves.length];
        for (int i = 0; i < moves.length; i++) {
            int p = Move.promo(moves[i]);
            if (p != 0 && Character.toUpperCase((char) p) != 'Q') continue;
            mv[n] = moves[i];
            sc[n] = scores[i];
            n++;
        }
        if (n < 2) return null;
        mv = java.util.Arrays.copyOf(mv, n);
        sc = java.util.Arrays.copyOf(sc, n);
        byte[] out = body(pos, mv, sc).getBytes(StandardCharsets.UTF_8);

        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setRequestMethod("POST");
            c.setConnectTimeout(Math.min(timeoutMs, 6000));
            c.setReadTimeout(timeoutMs);
            c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            c.setRequestProperty("x-app-token", token);
            OutputStream os = c.getOutputStream();
            os.write(out);
            os.close();
            int code = c.getResponseCode();
            String text = read(code >= 400 ? c.getErrorStream() : c.getInputStream());
            if (code != 200) {
                String why = field(text, "error");
                throw new Exception("server " + code + (why == null ? "" : ": " + why));
            }
            String move = field(text, "move");
            if (move == null) throw new Exception("server gave no move");
            for (int i = 0; i < n; i++) {
                if (uci(mv[i]).equals(move.trim().toLowerCase())) {
                    Brain.Choice ch = new Brain.Choice();
                    ch.move = mv[i];
                    ch.why = field(text, "why");
                    ch.model = field(text, "model");
                    if (ch.model == null) ch.model = "AI";
                    return ch;
                }
            }
            throw new Exception("server picked a move that is not in the list");
        } finally {
            c.disconnect();
        }
    }

    private static String read(InputStream is) throws Exception {
        if (is == null) return "";
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[2048];
        int k;
        while ((k = is.read(buf)) > 0 && bo.size() < 20000) bo.write(buf, 0, k);
        is.close();
        return new String(bo.toByteArray(), StandardCharsets.UTF_8);
    }
}
