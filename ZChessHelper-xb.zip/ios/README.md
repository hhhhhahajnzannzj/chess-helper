# Chess Helper for iPhone / iPad

A normal iOS app (SwiftUI) with its own board. iOS does not allow a floating window over other apps, so it cannot
float over a chess app the way the Android version does. It is for practice and bot games.

* Tap every move on the board (the opponent's and yours). On your turn Stockfish 17 (built into the app) shows the
  best move with two blue boxes and a blue arrow. "Done" plays it, "Undo move", "New game" (asks first),
  "Think time" (Instant to 30 s), "My pieces" (White/Black), pawn promotion chooser.
* Not in the iPhone version: Safe Mode, Unpredictable, With Brilliant, Gambits/Traps and SuperChess (Stockfish plus the
  companion engines Reckless, Triumviratus, PlentyChess, ShashChess). Those exist only in the Android and Windows apps.

## How it is built (no Mac, no paid account)
GitHub Actions (`.github/workflows/ios.yml`) builds it on a free macOS runner with XcodeGen + xcodebuild and packs an
**unsigned** `ChessHelper-iOS.ipa`, published in Releases (tag `ios-N`).

## Installing an unsigned .ipa
Apple only runs signed apps, so you sign it yourself with a free Apple ID, using one of:
* **Sideloadly** (Windows/Mac), **AltStore** or **SideStore**: free Apple ID, the app must be re-signed every 7 days.
* **TrollStore** (only on some iOS versions): permanent.
I could not test the app on a real iPhone.
