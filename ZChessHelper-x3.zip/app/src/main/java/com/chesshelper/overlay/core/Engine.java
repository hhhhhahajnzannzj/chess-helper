package com.chesshelper.overlay.core;

import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Chess engine: iterative-deepening negamax with alpha-beta and quiescence search.
 * It scores every candidate move within `margin` centipawns of the best one and then
 * picks randomly among them (softmax), so the advice is strong but not predictable.
 * Forced mates are always chosen.
 */
public final class Engine {
    public static final int MATE = 100000;
    private static final int INF = 1000000000;

    public static final class Result {
        public int move;
        public int score;          // from the point of view of the side to move
        public int depth;
        public int[] alternatives;
        public long nodes;
        public boolean hasExtremes;   // worst / wild were worked out
        public int worst, wild;
        public int worstScore, wildScore;
        public int bestMove, bestScore;
        public boolean avoidedRepeat;               // a repetition was declined because we are better
        public int[] candidates, candidateScores;   // moves within the margin of the best, best first   // the engine's own top choice (before any random pick)
    }

    private static final class Stopped extends RuntimeException {
        Stopped() {
            super("stopped", null, false, false);
        }
    }

    private static final class Scored {
        int[] moves;
        int[] scores;
        int n;
    }

    private final AtomicBoolean cancel;
    private long nodes;
    private long deadline = Long.MAX_VALUE;

    public Engine(AtomicBoolean cancel) {
        this.cancel = cancel != null ? cancel : new AtomicBoolean(false);
    }

    // ------------------------------------------------------------------ evaluation
    private static final int[] PAWN = {
            0, 0, 0, 0, 0, 0, 0, 0,
            50, 50, 50, 50, 50, 50, 50, 50,
            10, 10, 20, 30, 30, 20, 10, 10,
            5, 5, 10, 25, 25, 10, 5, 5,
            0, 0, 0, 20, 20, 0, 0, 0,
            5, -5, -10, 0, 0, -10, -5, 5,
            5, 10, 10, -20, -20, 10, 10, 5,
            0, 0, 0, 0, 0, 0, 0, 0};
    private static final int[] KNIGHT = {
            -50, -40, -30, -30, -30, -30, -40, -50,
            -40, -20, 0, 0, 0, 0, -20, -40,
            -30, 0, 10, 15, 15, 10, 0, -30,
            -30, 5, 15, 20, 20, 15, 5, -30,
            -30, 0, 15, 20, 20, 15, 0, -30,
            -30, 5, 10, 15, 15, 10, 5, -30,
            -40, -20, 0, 5, 5, 0, -20, -40,
            -50, -40, -30, -30, -30, -30, -40, -50};
    private static final int[] BISHOP = {
            -20, -10, -10, -10, -10, -10, -10, -20,
            -10, 0, 0, 0, 0, 0, 0, -10,
            -10, 0, 5, 10, 10, 5, 0, -10,
            -10, 5, 5, 10, 10, 5, 5, -10,
            -10, 0, 10, 10, 10, 10, 0, -10,
            -10, 10, 10, 10, 10, 10, 10, -10,
            -10, 5, 0, 0, 0, 0, 5, -10,
            -20, -10, -10, -10, -10, -10, -10, -20};
    private static final int[] ROOK = {
            0, 0, 0, 0, 0, 0, 0, 0,
            5, 10, 10, 10, 10, 10, 10, 5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            -5, 0, 0, 0, 0, 0, 0, -5,
            0, 0, 0, 5, 5, 0, 0, 0};
    private static final int[] QUEEN = {
            -20, -10, -10, -5, -5, -10, -10, -20,
            -10, 0, 0, 0, 0, 0, 0, -10,
            -10, 0, 5, 5, 5, 5, 0, -10,
            -5, 0, 5, 5, 5, 5, 0, -5,
            0, 0, 5, 5, 5, 5, 0, -5,
            -10, 5, 5, 5, 5, 5, 0, -10,
            -10, 0, 5, 0, 0, 0, 0, -10,
            -20, -10, -10, -5, -5, -10, -10, -20};
    private static final int[] KING_MID = {
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -30, -40, -40, -50, -50, -40, -40, -30,
            -20, -30, -30, -40, -40, -30, -30, -20,
            -10, -20, -20, -20, -20, -20, -20, -10,
            20, 20, 0, 0, 0, 0, 20, 20,
            20, 30, 10, 0, 0, 10, 30, 20};
    private static final int[] KING_END = {
            -50, -40, -30, -20, -20, -30, -40, -50,
            -30, -20, -10, 0, 0, -10, -20, -30,
            -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -10, 30, 40, 40, 30, -10, -30,
            -30, -10, 30, 40, 40, 30, -10, -30,
            -30, -10, 20, 30, 30, 20, -10, -30,
            -30, -30, 0, 0, 0, 0, -30, -30,
            -50, -30, -30, -30, -30, -30, -30, -50};

    private static int val(char u) {
        switch (u) {
            case 'P':
                return 100;
            case 'N':
                return 320;
            case 'B':
                return 330;
            case 'R':
                return 500;
            case 'Q':
                return 900;
            default:
                return 0;
        }
    }

    private static int[] pst(char u) {
        switch (u) {
            case 'P':
                return PAWN;
            case 'N':
                return KNIGHT;
            case 'B':
                return BISHOP;
            case 'R':
                return ROOK;
            default:
                return QUEEN;
        }
    }

    private static final int[] PASSED = {0, 8, 14, 24, 44, 76, 120, 0};
    private static final int[][] KN = {{-2, -1}, {-2, 1}, {-1, -2}, {-1, 2}, {1, -2}, {1, 2}, {2, -1}, {2, 1}};
    private static final int[][] DIAG = {{-1, -1}, {-1, 1}, {1, -1}, {1, 1}};
    private static final int[][] ORTH = {{-1, 0}, {1, 0}, {0, -1}, {0, 1}};

    private static final class Scratch {
        final int[] wMin = new int[8], wMax = new int[8], bMin = new int[8], bMax = new int[8];
        final int[] wCnt = new int[8], bCnt = new int[8];
    }

    private static final ThreadLocal<Scratch> SCRATCH = new ThreadLocal<Scratch>() {
        @Override
        protected Scratch initialValue() {
            return new Scratch();
        }
    };

    /** Squares a sliding piece reaches (empty squares plus the first enemy piece). */
    private static int slide(char[] b, int row, int col, int[][] dirs, boolean white) {
        int cnt = 0;
        for (int[] d : dirs) {
            int r = row + d[0], c = col + d[1];
            while (r >= 0 && r < 8 && c >= 0 && c < 8) {
                char q = b[r * 8 + c];
                if (q == '.') {
                    cnt++;
                } else {
                    if (Rules.isWhite(q) != white) cnt++;
                    break;
                }
                r += d[0];
                c += d[1];
            }
        }
        return cnt;
    }

    /**
     * Score in centipawns from the point of view of the side to move. Material, piece-square tables
     * (king blended between middlegame and endgame), pawn structure (passed, doubled, isolated pawns),
     * bishop pair, rooks on open files, piece mobility, king shelter, and a mop-up term that drives a lone
     * king into the corner when the other side is winning.
     */
    public static int evaluate(Position pos) {
        char[] b = pos.b;
        Scratch sc = SCRATCH.get();
        for (int i = 0; i < 8; i++) {
            sc.wMin[i] = 9;
            sc.bMin[i] = 9;
            sc.wMax[i] = -1;
            sc.bMax[i] = -1;
            sc.wCnt[i] = 0;
            sc.bCnt[i] = 0;
        }
        int score = 0, wnpm = 0, bnpm = 0, wk = 0, bk = 0, wB = 0, bB = 0, pawns = 0;
        for (int i = 0; i < 64; i++) {
            char p = b[i];
            if (p == 'P') {
                int r = i >> 3, c = i & 7;
                sc.wCnt[c]++;
                if (r < sc.wMin[c]) sc.wMin[c] = r;
                if (r > sc.wMax[c]) sc.wMax[c] = r;
                pawns++;
            } else if (p == 'p') {
                int r = i >> 3, c = i & 7;
                sc.bCnt[c]++;
                if (r < sc.bMin[c]) sc.bMin[c] = r;
                if (r > sc.bMax[c]) sc.bMax[c] = r;
                pawns++;
            }
        }
        for (int i = 0; i < 64; i++) {
            char p = b[i];
            if (p == '.') continue;
            char u = Character.toUpperCase(p);
            boolean w = p == u;
            if (u == 'K') {
                if (w) wk = i;
                else bk = i;
                continue;
            }
            int v = val(u);
            if (u != 'P') {
                if (w) wnpm += v;
                else bnpm += v;
            }
            int row = i >> 3, col = i & 7;
            int s = v + pst(u)[w ? i : i ^ 56];
            switch (u) {
                case 'P': {
                    int adv = w ? 7 - row : row;
                    boolean passed = true;
                    for (int cc = Math.max(0, col - 1); cc <= Math.min(7, col + 1) && passed; cc++) {
                        if (w ? sc.bMin[cc] < row : sc.wMax[cc] > row) passed = false;
                    }
                    if (passed) s += PASSED[adv];
                    int[] own = w ? sc.wCnt : sc.bCnt;
                    if (own[col] > 1) s -= 8;
                    boolean iso = (col == 0 || own[col - 1] == 0) && (col == 7 || own[col + 1] == 0);
                    if (iso) s -= 12;
                    break;
                }
                case 'N': {
                    int cnt = 0;
                    for (int[] d : KN) {
                        int r = row + d[0], c = col + d[1];
                        if (r < 0 || r > 7 || c < 0 || c > 7) continue;
                        char q = b[r * 8 + c];
                        if (q == '.' || Rules.isWhite(q) != w) cnt++;
                    }
                    s += (cnt - 4) * 4;
                    break;
                }
                case 'B':
                    s += (slide(b, row, col, DIAG, w) - 6) * 3;
                    if (w) wB++;
                    else bB++;
                    break;
                case 'R': {
                    s += (slide(b, row, col, ORTH, w) - 7) * 2;
                    int[] own = w ? sc.wCnt : sc.bCnt, opp = w ? sc.bCnt : sc.wCnt;
                    if (own[col] == 0) s += opp[col] == 0 ? 20 : 10;
                    break;
                }
                default:
                    break;
            }
            score += w ? s : -s;
        }
        int npm = wnpm + bnpm;
        if (pawns == 0 && npm <= 330) return 0;                       // a lone minor piece cannot mate
        if (wB >= 2) score += 30;
        if (bB >= 2) score -= 30;
        int mg = Math.min(256, npm * 256 / 6400), eg = 256 - mg;
        int[] ktM = KING_MID, ktE = KING_END;
        score += (ktM[wk] * mg + ktE[wk] * eg) / 256 - (ktM[bk ^ 56] * mg + ktE[bk ^ 56] * eg) / 256;
        // king shelter (matters in the middlegame only)
        score += shelter(b, wk, true, sc) * mg / 256 - shelter(b, bk, false, sc) * mg / 256;
        // mop-up: the stronger side drives the bare king to the edge and brings its own king closer
        if (score > 400 && bnpm <= 330 && sc.bCnt[0] + sc.bCnt[1] + sc.bCnt[2] + sc.bCnt[3] + sc.bCnt[4] + sc.bCnt[5]
                + sc.bCnt[6] + sc.bCnt[7] == 0) score += mopUp(wk, bk);
        else if (score < -400 && wnpm <= 330 && sc.wCnt[0] + sc.wCnt[1] + sc.wCnt[2] + sc.wCnt[3] + sc.wCnt[4]
                + sc.wCnt[5] + sc.wCnt[6] + sc.wCnt[7] == 0) score -= mopUp(bk, wk);
        score += pos.white ? 8 : -8;                                  // the move itself is worth a little
        return pos.white ? score : -score;
    }

    private static int mopUp(int strongKing, int weakKing) {
        int wr = weakKing >> 3, wc = weakKing & 7, sr = strongKing >> 3, scc = strongKing & 7;
        int centre = Math.max(3 - wc, wc - 4) + Math.max(3 - wr, wr - 4);
        int dist = Math.abs(wr - sr) + Math.abs(wc - scc);
        return centre * 12 + (14 - dist) * 5;
    }

    /** Pawns in front of a king that is tucked away on its first two ranks; open files next to it cost points. */
    private static int shelter(char[] b, int king, boolean white, Scratch sc) {
        int row = king >> 3, col = king & 7;
        if (white ? row < 6 : row > 1) return 0;
        char pawn = white ? 'P' : 'p';
        int step = white ? -1 : 1;
        int total = 0;
        for (int c = Math.max(0, col - 1); c <= Math.min(7, col + 1); c++) {
            int r1 = row + step, r2 = row + 2 * step;
            if (b[r1 * 8 + c] == pawn) total += 12;
            else if (r2 >= 0 && r2 < 8 && b[r2 * 8 + c] == pawn) total += 6;
            else total -= 8;
            int[] own = white ? sc.wCnt : sc.bCnt;
            if (own[c] == 0) total -= 10;
        }
        return total;
    }

    private static int moveScore(Position pos, int m) {
        int f = Move.from(m), t = Move.to(m);
        char[] b = pos.b;
        int s = 0;
        char cap = b[t];
        if (cap != '.') s += 10 * val(Character.toUpperCase(cap)) - val(Character.toUpperCase(b[f]));
        else if ((b[f] == 'P' || b[f] == 'p') && t == pos.ep) s += 900;
        char pr = Move.promo(m);
        if (pr != 0) s += val(pr);
        return s;
    }

    /** Moves sorted best-first (stable). */
    private static int[] ordered(Position pos, IntList l) {
        int n = l.n;
        int[] mv = new int[n];
        int[] sc = new int[n];
        for (int i = 0; i < n; i++) {
            mv[i] = l.a[i];
            sc[i] = moveScore(pos, mv[i]);
        }
        for (int i = 1; i < n; i++) {
            int m = mv[i], s = sc[i], j = i - 1;
            while (j >= 0 && sc[j] < s) {
                mv[j + 1] = mv[j];
                sc[j + 1] = sc[j];
                j--;
            }
            mv[j + 1] = m;
            sc[j + 1] = s;
        }
        return mv;
    }

    // ------------------------------------------------------------------ search
    private static final int MAXPLY = 96;
    private static final long[][] ZP = new long[12][64];
    private static final long[] ZC = new long[16];
    private static final long[] ZE = new long[9];
    private static final long ZSIDE;

    static {
        long x = 0x9E3779B97F4A7C15L;
        for (int i = 0; i < 12; i++) for (int j = 0; j < 64; j++) {
            x = mix(x);
            ZP[i][j] = x;
        }
        for (int i = 0; i < 16; i++) {
            x = mix(x);
            ZC[i] = x;
        }
        for (int i = 0; i < 9; i++) {
            x = mix(x);
            ZE[i] = x;
        }
        x = mix(x);
        ZSIDE = x;
    }

    private static long mix(long z) {
        z += 0x9E3779B97F4A7C15L;
        z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
        z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
        return z ^ (z >>> 31);
    }

    private static int zIndex(char c) {
        switch (c) {
            case 'P': return 0;
            case 'N': return 1;
            case 'B': return 2;
            case 'R': return 3;
            case 'Q': return 4;
            case 'K': return 5;
            case 'p': return 6;
            case 'n': return 7;
            case 'b': return 8;
            case 'r': return 9;
            case 'q': return 10;
            default: return 11;
        }
    }

    /** A 64-bit fingerprint of a position (pieces, side to move, castling rights, en passant file). */
    public static long hash(Position pos) {
        long h = 0;
        char[] b = pos.b;
        for (int i = 0; i < 64; i++) if (b[i] != '.') h ^= ZP[zIndex(b[i])][i];
        if (!pos.white) h ^= ZSIDE;
        int c = 0;
        String cs = pos.castle;
        if (cs.indexOf('K') >= 0) c |= 1;
        if (cs.indexOf('Q') >= 0) c |= 2;
        if (cs.indexOf('k') >= 0) c |= 4;
        if (cs.indexOf('q') >= 0) c |= 8;
        h ^= ZC[c];
        h ^= ZE[pos.ep < 0 ? 8 : (pos.ep & 7)];
        return h;
    }

    // transposition table: key and packed data (move 15 bits | depth 8 | flag 2 | score 21)
    private long[] ttKey, ttData;
    private int ttMask;
    private final int[] killer = new int[MAXPLY * 2];
    private final int[][] historyTable = new int[2][4096];
    private long[] stack = new long[MAXPLY + 8];           // hashes of the game so far + the search path (repetitions)
    private int base;

    /** Hashes of the positions already played in the game (before the one that is searched). */
    public void setGameHistory(long[] before) {
        base = before == null ? 0 : before.length;
        stack = new long[base + MAXPLY + 8];
        if (before != null) System.arraycopy(before, 0, stack, 0, base);
    }

    private int ttBits = 18;

    /** Smaller table = quicker start for very short searches. Call before searching. */
    public void setTableBits(int bits) {
        ttBits = Math.max(12, Math.min(22, bits));
        ttKey = null;
    }

    private void setRoot(Position pos) {
        stack[base] = hash(pos);
        if (ttKey == null) {
            int bits = ttBits;
            ttKey = new long[1 << bits];
            ttData = new long[1 << bits];
            ttMask = (1 << bits) - 1;
        }
    }

    private void tick() {
        nodes++;
        if ((nodes & 511) == 0 && (cancel.get() || System.nanoTime() > deadline)) throw new Stopped();
    }

    private static boolean isQuiet(Position pos, int m) {
        int f = Move.from(m), t = Move.to(m);
        return pos.b[t] == '.' && Move.promo(m) == 0 && !((pos.b[f] == 'P' || pos.b[f] == 'p') && t == pos.ep);
    }

    private int quiesce(Position pos, int alpha, int beta, int qd) {
        tick();
        int stand = evaluate(pos);
        if (stand >= beta) return stand;
        if (stand > alpha) alpha = stand;
        if (qd >= 10) return alpha;
        IntList all = new IntList();
        Rules.pseudoMoves(pos, all);
        IntList caps = new IntList();
        for (int i = 0; i < all.n; i++) {
            int m = all.a[i];
            int f = Move.from(m), t = Move.to(m);
            boolean ep = (pos.b[f] == 'P' || pos.b[f] == 'p') && t == pos.ep;
            if (pos.b[t] != '.' || Move.promo(m) != 0 || ep) {
                if (Move.promo(m) == 0 && !ep && stand + val(Character.toUpperCase(pos.b[t])) + 200 < alpha) continue;   // hopeless capture
                caps.add(m);
            }
        }
        for (int m : ordered(pos, caps)) {
            Position child = Rules.apply(pos, m);
            if (Rules.kingInCheck(child.b, pos.white)) continue;
            int s = -quiesce(child, -beta, -alpha, qd + 1);
            if (s >= beta) return s;
            if (s > alpha) alpha = s;
        }
        return alpha;
    }

    private static boolean hasPieces(Position pos) {
        for (char c : pos.b) {
            if (c == '.' || Rules.isWhite(c) != pos.white) continue;
            char u = Character.toUpperCase(c);
            if (u == 'N' || u == 'B' || u == 'R' || u == 'Q') return true;
        }
        return false;
    }

    private int ttScoreOut(int s, int ply) {
        if (s >= MATE - 200) return s - ply;
        if (s <= -MATE + 200) return s + ply;
        return s;
    }

    private int ttScoreIn(int s, int ply) {
        if (s >= MATE - 200) return s + ply;
        if (s <= -MATE + 200) return s - ply;
        return s;
    }

    private int negamax(Position pos, int depth, int alpha, int beta, int ply) {
        return search(pos, depth, alpha, beta, ply, true);
    }

    private int search(Position pos, int depth, int alpha, int beta, int ply, boolean nullOk) {
        tick();
        if (pos.half >= 100) return 0;
        if (ply >= MAXPLY - 2) return evaluate(pos);
        long h = hash(pos);
        int idx = base + ply;
        stack[idx] = h;
        for (int j = idx - 2, lo = Math.max(0, idx - pos.half); j >= lo; j -= 2) if (stack[j] == h) return 0;   // repetition
        boolean checked = Rules.inCheck(pos);
        if (checked && ply < 24) depth++;
        if (depth <= 0) return quiesce(pos, alpha, beta, 0);
        boolean pv = beta - alpha > 1;
        int origAlpha = alpha;

        int ttMove = 0;
        int slot = (int) (h ^ (h >>> 32)) & ttMask;
        if (ttKey[slot] == h) {
            long d = ttData[slot];
            ttMove = (int) (d & 0x7FFF);
            int td = (int) ((d >> 15) & 0xFF), flag = (int) ((d >> 23) & 3);
            int ts = ttScoreOut((int) (d >> 25) - (1 << 20), ply);
            if (td >= depth && !pv) {
                if (flag == 0) return ts;
                if (flag == 1 && ts >= beta) return ts;
                if (flag == 2 && ts <= alpha) return ts;
            }
        }

        int stat = checked ? -INF : evaluate(pos);
        if (!pv && !checked && Math.abs(beta) < MATE - 200) {
            if (depth <= 3 && stat - 110 * depth >= beta) return stat - 110 * depth;            // reverse futility
            if (nullOk && depth >= 3 && stat >= beta && hasPieces(pos)) {                       // null move
                int r = 2 + depth / 4;
                Position np = new Position(pos.b, !pos.white, pos.castle, -1, pos.half + 1, pos.full);
                int s = -search(np, depth - 1 - r, -beta, -beta + 1, ply + 1, false);
                if (s >= beta) return s >= MATE - 200 ? beta : s;
            }
        }

        IntList all = new IntList();
        Rules.pseudoMoves(pos, all);
        int n = all.n;
        int[] mv = new int[n];
        int[] sc = new int[n];
        int side = pos.white ? 0 : 1;
        for (int i = 0; i < n; i++) {
            int m = all.a[i];
            mv[i] = m;
            int ms;
            if ((m & 0x7FFF) == ttMove && ttMove != 0) ms = 10_000_000;
            else if (!isQuiet(pos, m)) ms = 1_000_000 + moveScore(pos, m);
            else if (m == killer[ply * 2]) ms = 900_000;
            else if (m == killer[ply * 2 + 1]) ms = 800_000;
            else ms = historyTable[side][(Move.from(m) << 6) | Move.to(m)];
            sc[i] = ms;
        }
        int best = -INF, bestMove = 0, legalSeen = 0, tried = 0;
        boolean futile = !pv && !checked && depth <= 2 && stat + 140 * depth <= alpha && Math.abs(alpha) < MATE - 200;
        for (int i = 0; i < n; i++) {
            int bi = i;                                                  // pick the best remaining move
            for (int j = i + 1; j < n; j++) if (sc[j] > sc[bi]) bi = j;
            int m = mv[bi];
            int ms = sc[bi];
            mv[bi] = mv[i];
            sc[bi] = sc[i];
            Position child = Rules.apply(pos, m);
            if (Rules.kingInCheck(child.b, pos.white)) continue;
            legalSeen++;
            boolean quiet = isQuiet(pos, m);
            boolean givesCheck = false;
            if (quiet && (futile || (depth >= 3 && tried >= 3))) givesCheck = Rules.inCheck(child);
            if (futile && quiet && tried > 0 && !givesCheck) continue;
            int s;
            if (tried == 0) {
                s = -search(child, depth - 1, -beta, -alpha, ply + 1, true);
            } else {
                int red = 0;
                if (depth >= 3 && tried >= 3 && quiet && !checked && !givesCheck && ms < 800_000) red = tried >= 8 ? 2 : 1;
                s = -search(child, depth - 1 - red, -alpha - 1, -alpha, ply + 1, true);
                if (s > alpha && red > 0) s = -search(child, depth - 1, -alpha - 1, -alpha, ply + 1, true);
                if (s > alpha && s < beta) s = -search(child, depth - 1, -beta, -alpha, ply + 1, true);
            }
            tried++;
            if (s > best) {
                best = s;
                bestMove = m;
            }
            if (s > alpha) alpha = s;
            if (alpha >= beta) {
                if (quiet) {
                    if (killer[ply * 2] != m) {
                        killer[ply * 2 + 1] = killer[ply * 2];
                        killer[ply * 2] = m;
                    }
                    int hi = (Move.from(m) << 6) | Move.to(m);
                    historyTable[side][hi] = Math.min(700_000, historyTable[side][hi] + depth * depth);
                }
                break;
            }
        }
        if (legalSeen == 0) return checked ? -MATE + ply : 0;
        if (tried == 0) return alpha;                                    // every move was pruned as futile
        int flag = best <= origAlpha ? 2 : best >= beta ? 1 : 0;
        long data = (bestMove & 0x7FFF) | ((long) Math.min(depth, 255) << 15) | ((long) flag << 23)
                | ((long) (ttScoreIn(best, ply) + (1 << 20)) << 25);
        ttKey[slot] = h;
        ttData[slot] = data;
        return best;
    }

    /** Scores every root move within `margin` of the best one. */
    private Scored root(Position pos, int[] ordered, int depth, int margin) {
        int best = -INF;
        int[] mv = new int[ordered.length];
        int[] sc = new int[ordered.length];
        int n = 0;
        for (int m : ordered) {
            Position child = Rules.apply(pos, m);
            int alpha = best == -INF ? -INF : best - margin;
            int s = -negamax(child, depth - 1, -INF, -alpha, 1);
            if (s > alpha) {
                mv[n] = m;
                sc[n] = s;
                n++;
                if (s > best) best = s;
            }
        }
        Scored out = new Scored();
        out.moves = new int[n];
        out.scores = new int[n];
        int k = 0;
        for (int i = 0; i < n; i++) {
            if (sc[i] >= best - margin) {
                out.moves[k] = mv[i];
                out.scores[k] = sc[i];
                k++;
            }
        }
        out.n = k;
        for (int i = 1; i < k; i++) {                       // stable sort, best first
            int m = out.moves[i], s = out.scores[i], j = i - 1;
            while (j >= 0 && out.scores[j] < s) {
                out.moves[j + 1] = out.moves[j];
                out.scores[j + 1] = out.scores[j];
                j--;
            }
            out.moves[j + 1] = m;
            out.scores[j + 1] = s;
        }
        return out;
    }

    /**
     * The WORST move (lowest score) and a MID move (the middle of the ranking: neither strong nor terrible),
     * judged by a quick shallow search of every legal move.
     *
     * @param best the move that is shown as best (never returned as mid or worst)
     * @return {mid, worst}; -1 where there is no such move (very few legal moves), or null when stopped
     */
    public int[] midAndWorst(Position pos, int best, double maxSeconds) {
        int[] moves = Rules.legalMoves(pos);
        int n = moves.length;
        if (n < 2) return new int[]{-1, -1};
        int[] sc = new int[n];
        Uci u = uci;
        boolean done = false;
        if (u != null) {                                              // Stockfish ranks every move at once
            List<Uci.Line> ls = u.analyse(Fen.of(pos), Math.min(n, 200), (int) Math.max(150, maxSeconds * 1000), cancel, null);
            if (ls != null && ls.size() == n) {
                java.util.Arrays.fill(sc, Integer.MIN_VALUE);
                for (Uci.Line l : ls) {
                    int m = Gambits.parse(pos, l.move);
                    for (int i = 0; i < n; i++) if (moves[i] == m) sc[i] = l.score;
                }
                done = true;
                for (int i = 0; i < n; i++) if (sc[i] == Integer.MIN_VALUE) done = false;
            } else if (!u.isAlive()) {
                uci = null;
            }
        }
        if (!done) {
            setRoot(pos);
            deadline = System.nanoTime() + (long) (maxSeconds * 1e9);
            try {
                for (int i = 0; i < n; i++) sc[i] = -negamax(Rules.apply(pos, moves[i]), 2, -INF, INF, 1);
            } catch (Stopped e) {
                return null;
            }
        }
        Integer[] idx = new Integer[n];
        for (int i = 0; i < n; i++) idx[i] = i;
        java.util.Arrays.sort(idx, (x, y) -> sc[y] - sc[x]);          // best first
        int worst = -1, mid = -1;
        for (int i = n - 1; i >= 0; i--) if (moves[idx[i]] != best) { worst = moves[idx[i]]; break; }
        int target = n / 2;                                          // the middle of the ranking
        for (int d = 0; d < n && mid < 0; d++) {
            for (int sgn = -1; sgn <= 1; sgn += 2) {
                int i = target + sgn * d;
                if (i < 0 || i >= n) continue;
                int m = moves[idx[i]];
                if (m != best && m != worst) {
                    mid = m;
                    break;
                }
            }
        }
        return new int[]{mid, worst};
    }

    /**
     * Adds the WORST move (lowest score) and a WILD move (playable but surprising: clearly worse than the
     * best, not a blunder) to a result. Quick: every legal move is scored at a shallow depth.
     */
    public void addExtremes(Position pos, Result r, Random rng, double maxSeconds) {
        int[] moves = Rules.legalMoves(pos);
        if (moves.length < 2) return;
        setRoot(pos);
        deadline = System.nanoTime() + (long) (maxSeconds * 1e9);
        int[] sc = new int[moves.length];
        try {
            for (int i = 0; i < moves.length; i++) {
                sc[i] = -negamax(Rules.apply(pos, moves[i]), 2, -INF, INF, 1);
            }
        } catch (Stopped e) {
            return;
        }
        int top = -INF, wi = 0;
        for (int i = 0; i < sc.length; i++) {
            if (sc[i] > top) top = sc[i];
            if (sc[i] < sc[wi]) wi = i;
        }
        r.worst = moves[wi];
        r.worstScore = sc[wi];
        int[] pool = new int[moves.length];
        int n = 0;
        for (int i = 0; i < moves.length; i++) {                 // playable but not the best: 120..450 cp below
            if (moves[i] != r.move && moves[i] != r.worst && sc[i] <= top - 120 && sc[i] >= top - 450) pool[n++] = i;
        }
        if (n == 0) {                                            // quiet position: anything but best/worst
            for (int i = 0; i < moves.length; i++) {
                if (moves[i] != r.move && moves[i] != r.worst) pool[n++] = i;
            }
        }
        if (n == 0) {
            r.wild = r.worst;
            r.wildScore = r.worstScore;
        } else {
            int k = pool[rng.nextInt(n)];
            r.wild = moves[k];
            r.wildScore = sc[k];
        }
        r.hasExtremes = true;
    }

    // ------------------------------------------------------------------ sacrifices ("brilliant" moves)
    /** Material of the side to move minus the other side (kings ignored). */
    private static int material(Position pos) {
        int sum = 0;
        for (char c : pos.b) {
            if (c == '.') continue;
            int v = val(Character.toUpperCase(c));
            sum += Rules.isWhite(c) == pos.white ? v : -v;
        }
        return sum;
    }

    /** Material balance (side to move's view) once all captures are played out. */
    private int materialQ(Position pos, int alpha, int beta, int qd) {
        int stand = material(pos);
        if (stand >= beta) return stand;
        if (stand > alpha) alpha = stand;
        if (qd >= 8) return alpha;
        IntList all = new IntList();
        Rules.pseudoMoves(pos, all);
        IntList caps = new IntList();
        for (int i = 0; i < all.n; i++) {
            int m = all.a[i];
            int f = Move.from(m), t = Move.to(m);
            if (pos.b[t] != '.' || ((pos.b[f] == 'P' || pos.b[f] == 'p') && t == pos.ep)) caps.add(m);
        }
        for (int m : ordered(pos, caps)) {
            Position child = Rules.apply(pos, m);
            if (Rules.kingInCheck(child.b, pos.white)) continue;
            int s = -materialQ(child, -beta, -alpha, qd + 1);
            if (s >= beta) return s;
            if (s > alpha) alpha = s;
        }
        return alpha;
    }

    /**
     * How much material (centipawns) the mover gives up with move m, compared with what would happen
     * anyway if the mover simply passed. Trades are 0, winning material is negative, a real sacrifice
     * is a large positive number.
     */
    public int sacrifice(Position pos, int m) {
        int before;
        if (Rules.inCheck(pos)) {
            before = material(pos);
        } else {
            Position pass = new Position(pos.b.clone(), !pos.white, pos.castle, -1, pos.half, pos.full);
            before = -materialQ(pass, -INF, INF, 0);
        }
        Position c = Rules.apply(pos, m);
        int after = -materialQ(c, -INF, INF, 0);
        return before - after;
    }

    /** Score (mover's view) of playing m, searched to `depth`; Integer.MIN_VALUE if time ran out. */
    public int scoreMove(Position pos, int m, int depth, double seconds) {
        Uci u = uci;
        if (u != null) {
            List<Uci.Line> ls = u.analyse(Fen.of(pos), 1, (int) Math.max(40, seconds * 1000), cancel, moveText(m));
            if (ls != null && !ls.isEmpty()) return ls.get(0).score;
            if (!u.isAlive()) uci = null;
        }
        setRoot(pos);
        deadline = System.nanoTime() + (long) (seconds * 1e9);
        try {
            return -negamax(Rules.apply(pos, m), Math.max(1, depth - 1), -INF, INF, 1);
        } catch (Stopped e) {
            return Integer.MIN_VALUE;
        }
    }

    // ------------------------------------------------------------------ fast checkmate
    private long mateEnd = Long.MAX_VALUE;

    /** First move after which the side to move forces mate in n (attacker plays checks only, except at the root). */
    private int mateMove(Position pos, int n, boolean root) {
        if ((++nodes & 127) == 0 && (cancel.get() || System.nanoTime() > mateEnd)) throw new Stopped();
        int[] legal = Rules.legalMoves(pos);
        for (int pass = 0; pass < 2; pass++) {                    // checking moves first, then (root only) quiet ones
            for (int m : legal) {
                Position c = Rules.apply(pos, m);
                boolean check = Rules.inCheck(c);
                if (check != (pass == 0)) continue;
                if (!check && !(root && n > 1)) continue;
                int[] replies = Rules.legalMoves(c);
                if (replies.length == 0) {
                    if (check) return m;                             // checkmate
                    continue;                                        // stalemate: not a win
                }
                if (n == 1) continue;
                boolean all = true;
                for (int r : replies) {
                    if (mateMove(Rules.apply(c, r), n - 1, false) < 0) {
                        all = false;
                        break;
                    }
                }
                if (all) return m;
            }
        }
        return -1;
    }

    // ---- complete mate solver: every attacking move and every defence is tried (quiet moves, sacrifices,
    //      underpromotions, en passant, castling, zugzwang), stalemates are never counted as wins
    private final java.util.HashMap<Long, Boolean> mateTT = new java.util.HashMap<>();
    private final int[] mateKiller = new int[16];

    private static long hashPos(Position p, int n) {
        long h = 1469598103934665603L;
        for (char c : p.b) {
            h ^= c;
            h *= 1099511628211L;
        }
        h ^= p.white ? 1 : 2;
        h *= 1099511628211L;
        for (int i = 0; i < p.castle.length(); i++) {
            h ^= p.castle.charAt(i);
            h *= 1099511628211L;
        }
        h ^= (p.ep + 2) * 0x9E3779B97F4A7C15L;
        h *= 1099511628211L;
        h ^= n * 0xC2B2AE3D27D4EB4FL;
        return h;
    }

    private boolean mateWins(Position pos, int n) {
        long key = hashPos(pos, n);
        Boolean v = mateTT.get(key);
        if (v != null) return v;
        boolean r = mateFull(pos, n, null);
        if (mateTT.size() > 400000) mateTT.clear();
        mateTT.put(key, r);
        return r;
    }

    /** True when the side to move (the attacker) can force mate in n moves. With winners != null every winning move is collected. */
    private boolean mateFull(Position pos, int n, IntList winners) {
        if ((++nodes & 63) == 0 && (cancel.get() || System.nanoTime() > mateEnd)) throw new Stopped();
        int[] legal = Rules.legalMoves(pos);
        int cnt = legal.length;
        Position[] child = new Position[cnt];
        boolean[] chk = new boolean[cnt];
        for (int i = 0; i < cnt; i++) {
            child[i] = Rules.apply(pos, legal[i]);
            chk[i] = Rules.inCheck(child[i]);
        }
        boolean found = false;
        for (int pass = 0; pass < 3; pass++) {                    // checks, then captures, then quiet moves
            for (int i = 0; i < cnt; i++) {
                int m = legal[i];
                Position c = child[i];
                boolean check = chk[i];
                boolean cap = pos.b[Move.to(m)] != '.' || Move.promo(m) != 0;
                if (n == 1) {                                        // the last move must give mate
                    if (pass != 0 || !check) continue;
                    if (Rules.legalMoves(c).length == 0) {
                        if (winners == null) return true;
                        winners.add(m);
                        found = true;
                    }
                    continue;
                }
                if (pass == 0 && !check) continue;
                if (pass == 1 && (check || !cap)) continue;
                if (pass == 2 && (check || cap)) continue;
                int[] replies = Rules.legalMoves(c);
                if (replies.length == 0) {
                    if (check) {
                        if (winners == null) return true;
                        winners.add(m);
                        found = true;
                    }
                    continue;                                        // stalemate is not a win
                }
                boolean all = true;
                int k = mateKiller[n];
                for (int pass2 = 0; pass2 < 3 && all; pass2++) {     // killer reply first, then captures, then the rest
                    for (int r : replies) {
                        boolean isK = r == k;
                        boolean isCap = c.b[Move.to(r)] != '.';
                        if (pass2 == 0 && !isK) continue;
                        if (pass2 == 1 && (isK || !isCap)) continue;
                        if (pass2 == 2 && (isK || isCap)) continue;
                        if (!mateWins(Rules.apply(c, r), n - 1)) {
                            mateKiller[n] = r;
                            all = false;
                            break;
                        }
                    }
                }
                if (all) {
                    if (winners == null) return true;
                    winners.add(m);
                    found = true;
                }
            }
        }
        return found;
    }

    /**
     * Fastest forced mate for the side to move.
     * First a quick forcing search (checks only after the first move, up to maxForcing moves) gives a candidate;
     * then the complete solver proves or finds anything shorter, up to maxFull moves, within the time.
     * Every mate returned is a real forced mate. A longer mate that needs quiet moves after move maxFull may be missed.
     *
     * @param rng picks among equally fast mates when not null
     * @return {move, number of moves to mate}, or null when none was found in time
     */
    public int[] findMate(Position pos, int maxFull, int maxForcing, double seconds, Random rng) {
        long start = System.nanoTime();
        long total = start + (long) (seconds * 1e9);
        mateTT.clear();
        java.util.Arrays.fill(mateKiller, 0);
        int[] fc = null;
        try {
            mateEnd = start + (long) (seconds * 0.25e9);
            for (int n = 1; n <= maxForcing; n++) {
                int m = mateMove(pos, n, true);
                if (m >= 0) {
                    fc = new int[]{m, n};
                    break;
                }
            }
        } catch (Stopped e) {
            fc = null;
        }
        int limit = fc == null ? maxFull : Math.min(maxFull, fc[1] - 1);
        mateEnd = total;
        for (int n = 1; n <= limit; n++) {
            try {
                IntList w = new IntList();
                mateFull(pos, n, w);
                if (w.n > 0) return new int[]{w.a[rng == null ? 0 : rng.nextInt(w.n)], n};
            } catch (Stopped e) {
                break;
            }
        }
        return fc;
    }

    // ------------------------------------------------------------------ brilliant moves
    private int matSearch(Position pos, int depth, int alpha, int beta) {
        if (depth == 0) return materialQ(pos, alpha, beta, 0);
        int[] mv = Rules.legalMoves(pos);
        if (mv.length == 0) return Rules.inCheck(pos) ? -MATE : 0;
        int best = -INF;
        for (int m : ordered(pos, listOf(mv))) {
            int sc = -matSearch(Rules.apply(pos, m), depth - 1, -beta, -alpha);
            if (sc > best) best = sc;
            if (sc > alpha) alpha = sc;
            if (alpha >= beta) break;
        }
        return best;
    }

    private static IntList listOf(int[] mv) {
        IntList l = new IntList();
        for (int m : mv) l.add(m);
        return l;
    }

    /** Material balance (mover's view) if the mover passed and everything were traded off. */
    private int materialBefore(Position pos) {
        if (Rules.inCheck(pos)) return material(pos);
        Position pass = new Position(pos.b.clone(), !pos.white, pos.castle, -1, pos.half, pos.full);
        return -materialQ(pass, -INF, INF, 0);
    }

    /** The material is still given up three moves later (not just a trade or a quick combination), or it mates. */
    private boolean sacrificeHolds(Position pos, int m) {
        int before = materialBefore(pos);
        int after = -matSearch(Rules.apply(pos, m), 3, -INF, INF);
        return after >= MATE - 200 || before - after >= 250;
    }

    /**
     * A real brilliant move, as strict as possible:
     *  - a genuine piece sacrifice (at least about a minor piece) that is still a sacrifice three moves later,
     *  - the mover is not already far ahead in material (nothing to prove),
     *  - a deeper search rates it as good as the best move (within 15 cp) and the position is not worse than equal,
     *    or it forces mate.
     *
     * @return the move, or -1 when there is none
     */
    public int findBrilliant(Position pos, Result r, Random rng, boolean randomPick, double seconds) {
        return findBrilliant(pos, r, rng, randomPick, seconds, 30);
    }

    /**
     * With the real Stockfish: one MultiPV analysis lists its ten best moves with their scores; any of them that is a
     * real sacrifice (still a sacrifice three moves later) and is rated within `tol` centipawns of the best move,
     * without being a worse position, is brilliant. Without Stockfish the built-in search is used (below).
     *
     * @param tol how much worse than the best move a brilliant move may be rated (centipawns)
     */
    public int findBrilliant(Position pos, Result r, Random rng, boolean randomPick, double seconds, int tol) {
        Uci u = uci;
        if (u != null) {
            int ms = (int) Math.max(200, seconds * 1000);
            List<Uci.Line> ls = u.analyse(Fen.of(pos), 10, ms, cancel, null);
            if (ls != null) {
                if (ls.isEmpty()) return -1;
                int ref = ls.get(0).score;
                boolean refMate = ref >= MATE - 200;
                if (!refMate && (ref >= 800 || materialBefore(pos) >= 700)) return -1;   // already winning: nothing to prove
                int[] good = new int[ls.size()];
                int[] goodScore = new int[ls.size()];
                int g = 0;
                for (Uci.Line l : ls) {
                    int m = Gambits.parse(pos, l.move);
                    if (m < 0) continue;
                    boolean mate = l.score >= MATE - 200;
                    boolean sound = l.score >= ref - tol && l.score >= -20;
                    if (!mate && !sound) continue;
                    if (sacrifice(pos, m) < 200 || !sacrificeHolds(pos, m)) continue;
                    good[g] = m;
                    goodScore[g] = l.score;
                    g++;
                }
                if (g == 0) return -1;
                if (randomPick) return good[rng.nextInt(g)];
                int bi = 0;
                for (int i = 1; i < g; i++) if (goodScore[i] > goodScore[bi]) bi = i;
                return good[bi];
            }
            if (!u.isAlive()) uci = null;
        }
        return findBrilliantBuiltIn(pos, r, rng, randomPick, seconds, tol);
    }

    private int findBrilliantBuiltIn(Position pos, Result r, Random rng, boolean randomPick, double seconds, int tol) {
        long end = System.nanoTime() + (long) (seconds * 1e9);
        boolean aheadAlready = materialBefore(pos) >= 700;
        int[] moves = Rules.legalMoves(pos);
        int n = 0;
        int[] cand = new int[moves.length];
        int[] sac = new int[moves.length];
        for (int m : moves) {
            int sc = sacrifice(pos, m);
            if (sc >= 200) {
                cand[n] = m;
                sac[n] = sc;
                n++;
            }
        }
        if (n == 0) return -1;
        for (int i = 1; i < n; i++) {                           // biggest sacrifice first
            int m = cand[i], sc = sac[i], j = i - 1;
            while (j >= 0 && sac[j] < sc) {
                cand[j + 1] = cand[j];
                sac[j + 1] = sac[j];
                j--;
            }
            cand[j + 1] = m;
            sac[j + 1] = sc;
        }
        int[] real = new int[Math.min(n, 8)];
        int k = 0;
        for (int i = 0; i < n && k < real.length; i++) {
            if (System.nanoTime() > end) break;
            if (sacrificeHolds(pos, cand[i])) real[k++] = cand[i];
        }
        if (k == 0) return -1;
        int depth = Math.max(8, r.depth + 2);
        double total = Math.max(0.2, (end - System.nanoTime()) / 1e9);
        int ref = scoreMove(pos, r.bestMove, depth, total * 0.3);
        if (ref == Integer.MIN_VALUE) {                          // too slow: compare at the normal depth instead
            depth = Math.max(4, r.depth);
            ref = r.bestScore;
        }
        int[] sc = new int[k];
        for (int i = 0; i < k; i++) {
            double left = (end - System.nanoTime()) / 1e9;
            if (real[i] == r.bestMove) sc[i] = ref;
            else sc[i] = left <= 0.05 ? Integer.MIN_VALUE : scoreMove(pos, real[i], depth, left / (k - i));
            if (sc[i] != Integer.MIN_VALUE && sc[i] > ref) ref = sc[i];
        }
        int[] good = new int[k];
        int[] goodScore = new int[k];
        int g = 0;
        for (int i = 0; i < k; i++) {
            if (sc[i] == Integer.MIN_VALUE) continue;
            boolean mate = sc[i] >= MATE - 200;
            boolean sound = sc[i] >= ref - tol && sc[i] >= -20 && ref < 800 && !aheadAlready;
            if (mate || sound) {
                good[g] = real[i];
                goodScore[g] = sc[i];
                g++;
            }
        }
        if (g == 0) return -1;
        if (randomPick) return good[rng.nextInt(g)];
        int bi = 0;
        for (int i = 1; i < g; i++) if (goodScore[i] > goodScore[bi]) bi = i;
        return good[bi];
    }

    /**
     * @param margin centipawns a move may be worse than the best and still be a candidate
     * @param temp   how evenly the candidates are mixed (bigger = more random)
     * @return null when there is no legal move
     */
    /** When set (by the app), the real Stockfish does the thinking; the built-in search is the fallback. */
    public static volatile Uci uci;

    private static String moveText(int m) {
        char pr = Move.promo(m);
        return Rules.sqName(Move.from(m)) + Rules.sqName(Move.to(m)) + (pr == 0 ? "" : String.valueOf(Character.toLowerCase(pr)));
    }

    private static int pickIndex(int[] scores, int n, int temp, Random rng) {
        int best = scores[0];
        if (n < 2 || best >= MATE - 200 || best <= -MATE + 200) return 0;
        double[] w = new double[n];
        double total = 0;
        for (int i = 0; i < n; i++) {
            w[i] = Math.exp((scores[i] - best) / Math.max(temp, 0.5));
            total += w[i];
        }
        double x = rng.nextDouble() * total;
        int ci = 0;
        for (int i = 0; i < n; i++) {
            x -= w[i];
            ci = i;
            if (x <= 0) break;
        }
        return ci;
    }

    /**
     * Stockfish treats a draw by repetition as equal and happily repeats even when it is better (it no longer has a
     * "contempt" setting). When the best move would repeat a position of this game while we are clearly better,
     * prefer a nearly-as-good move that does not.
     *
     * @param repeats how many times the position after each move already occurred in this game
     * @return the index of the move to play (0 = the engine's best)
     */
    static int preferNonRepeating(int[] repeats, int[] scores, int n) {
        int best = scores[0];
        if (n < 2 || repeats[0] == 0 || best <= 30 || best >= MATE - 200) return 0;
        int tolerance = repeats[0] >= 2 ? 80 : 35;
        for (int i = 1; i < n; i++) {
            if (repeats[i] == 0 && scores[i] >= best - tolerance && scores[i] > 0) return i;
        }
        return 0;
    }

    /** "Engine Agent": extra UCI engines (shipped inside the app) that give a second opinion. */
    public static volatile java.util.List<Uci> agents = new java.util.concurrent.CopyOnWriteArrayList<>();
    public static volatile boolean agentsOn;
    /** How far (centipawns) the second opinion may move the choice away from the main engine's best move. */
    public static volatile int agentTolerance = 20;

    private static Uci.Line copyLine(Uci.Line l) {
        Uci.Line c = new Uci.Line();
        c.multipv = 1;
        c.depth = l.depth;
        c.score = l.score;
        c.move = l.move;
        return c;
    }

    /** How many second engines may think at once (the app lowers this on phones with little memory). */
    public static volatile int agentLimit = 2;

    /** One second engine, kept for the old single-agent call. */
    static List<Uci.Line> committee(Position pos, List<Uci.Line> ls, List<Uci.Line> al, int tol) {
        List<List<Uci.Line>> all = new java.util.ArrayList<>();
        all.add(al);
        return committee(pos, ls, all, new int[]{2}, tol);
    }

    /**
     * The engines decide together. Stockfish's list is the base.
     *  - If an agent sees a faster forced mate, that mating move is chosen (the move must be legal; the quickest
     *    mate of all agents wins).
     *  - Otherwise the agents only break near-ties: among Stockfish's top three moves that are within `tol`
     *    centipawns of its best, the move the engines rank highest wins (Stockfish counts 3, a comparison engine 2,
     *    an analysis engine 1). It never overrides a clearly better move and never walks away from a mate.
     *
     * @param als     the agents' lists (null or empty = no answer)
     * @param weights the weight of each agent, same order as als
     */
    static List<Uci.Line> committee(Position pos, List<Uci.Line> ls, List<List<Uci.Line>> als, int[] weights, int tol) {
        if (ls == null || ls.isEmpty() || als == null || als.isEmpty()) return ls;
        Uci.Line pb = ls.get(0);
        Uci.Line mate = null;
        for (List<Uci.Line> al : als) {
            if (al == null || al.isEmpty()) continue;
            Uci.Line ab = al.get(0);
            if (ab.score >= MATE - 200 && ab.score > pb.score && (mate == null || ab.score > mate.score)
                    && Gambits.parse(pos, ab.move) >= 0) {
                mate = ab;
            }
        }
        if (mate != null) {
            if (mate.move.equals(pb.move)) return ls;
            List<Uci.Line> res = new java.util.ArrayList<>();
            res.add(copyLine(mate));
            for (Uci.Line l : ls) if (!l.move.equals(mate.move)) res.add(l);
            return res;
        }
        if (pb.score >= MATE - 200 || pb.score <= -MATE + 200) return ls;
        int n1 = Math.min(3, ls.size());
        int bestIdx = 0, bestPts = -1;
        for (int i = 0; i < n1; i++) {
            if (ls.get(i).score < pb.score - tol) break;
            int pts = 3 * (n1 - i);
            for (int k = 0; k < als.size(); k++) {
                List<Uci.Line> al = als.get(k);
                if (al == null) continue;
                int n2 = Math.min(3, al.size());
                int w = weights != null && k < weights.length ? weights[k] : 1;
                for (int j = 0; j < n2; j++) if (al.get(j).move.equals(ls.get(i).move)) pts += w * (n2 - j);
            }
            if (pts > bestPts) {
                bestPts = pts;
                bestIdx = i;
            }
        }
        if (bestIdx == 0) return ls;
        List<Uci.Line> res = new java.util.ArrayList<>(ls);
        Uci.Line chosen = res.remove(bestIdx);
        res.add(0, chosen);
        return res;
    }

    private Result searchUci(Uci u, Position pos, double thinkSeconds, int margin, int temp, Random rng) {
        int mpv = Math.max(margin > 0 ? 5 : 1, base > 0 ? 3 : 1);
        final int ms = (int) (thinkSeconds * 1000);
        // the second engines think at the same time (each in its own thread), so the answer is no slower
        final List<Uci> active = new java.util.ArrayList<>();
        if (agentsOn && agents != null) {
            for (Uci a : agents) {
                if (!a.isAlive()) {
                    agents.remove(a);                                       // it died earlier: drop it
                } else if (active.size() < Math.max(0, agentLimit)) {
                    active.add(a);
                }
            }
        }
        final Thread[] threads = new Thread[active.size()];
        final Object[] boxes = new Object[active.size()];
        final String fenNow = Fen.of(pos);
        for (int i = 0; i < threads.length; i++) {
            final int k = i;
            final Uci agent = active.get(i);
            threads[i] = new Thread(() -> boxes[k] = agent.analyse(fenNow, 3, ms, cancel, null));
            threads[i].setDaemon(true);
            threads[i].start();
        }
        List<Uci.Line> ls = u.analyse(fenNow, mpv, ms, cancel, null);
        if (threads.length > 0) {
            List<List<Uci.Line>> als = new java.util.ArrayList<>();
            int[] ws = new int[threads.length];
            long until = System.currentTimeMillis() + ms + 9000L;
            for (int i = 0; i < threads.length; i++) {
                try {
                    threads[i].join(Math.max(1, until - System.currentTimeMillis()));
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
                ws[i] = active.get(i).weight;
                if (!threads[i].isAlive()) {
                    @SuppressWarnings("unchecked")
                    List<Uci.Line> al = (List<Uci.Line>) boxes[i];
                    if (al == null && !active.get(i).isAlive()) agents.remove(active.get(i));   // it died: drop it
                    als.add(al);
                } else {
                    als.add(null);                                          // too slow: ignore its answer this time
                }
            }
            if (ls != null && !ls.isEmpty()) ls = committee(pos, ls, als, ws, agentTolerance);
        }
        if (ls == null || ls.isEmpty()) return null;
        boolean avoided = false;
        if (base > 0 && ls.size() > 1) {
            int k = ls.size();
            int[] reps = new int[k], scs = new int[k];
            for (int i = 0; i < k; i++) {
                int m = Gambits.parse(pos, ls.get(i).move);
                scs[i] = ls.get(i).score;
                if (m < 0) {
                    reps[i] = 1;
                    continue;
                }
                long h = hash(Rules.apply(pos, m));
                for (int j = 0; j < base; j++) if (stack[j] == h) reps[i]++;
            }
            int pick = preferNonRepeating(reps, scs, k);
            if (pick != 0) {
                List<Uci.Line> re = new java.util.ArrayList<>(ls);
                Uci.Line chosen = re.remove(pick);
                re.add(0, chosen);
                ls = re;
                avoided = true;
            }
        }
        if (avoided) {                                              // play exactly that move, no random pick
            int m = Gambits.parse(pos, ls.get(0).move);
            Result r = new Result();
            r.move = m;
            r.bestMove = m;
            r.score = ls.get(0).score;
            r.bestScore = r.score;
            r.depth = ls.get(0).depth;
            r.alternatives = new int[0];
            r.candidates = new int[]{m};
            r.candidateScores = new int[]{r.score};
            r.avoidedRepeat = true;
            return r;
        }
        int[] mv = new int[ls.size()], sc = new int[ls.size()];
        int n = 0, best = ls.get(0).score, depth = ls.get(0).depth;
        for (Uci.Line l : ls) {
            int m = Gambits.parse(pos, l.move);
            if (m < 0) continue;
            if (n > 0 && l.score < best - margin) break;
            mv[n] = m;
            sc[n] = l.score;
            n++;
        }
        if (n == 0) return null;
        int ci = pickIndex(sc, n, temp, rng);
        Result r = new Result();
        r.move = mv[ci];
        r.score = sc[ci];
        r.bestMove = mv[0];
        r.bestScore = sc[0];
        r.depth = depth;
        int[] alts = new int[Math.min(2, n - 1)];
        int a = 0;
        for (int i = 0; i < n && a < alts.length; i++) if (i != ci) alts[a++] = mv[i];
        r.alternatives = alts;
        r.candidates = java.util.Arrays.copyOf(mv, n);
        r.candidateScores = java.util.Arrays.copyOf(sc, n);
        return r;
    }

    public Result search(Position pos, int maxDepth, double thinkSeconds, int margin, int temp, Random rng) {
        int[] moves = Rules.legalMoves(pos);
        if (moves.length == 0) return null;
        Uci u = uci;
        if (u != null) {
            Result r = searchUci(u, pos, thinkSeconds, margin, temp, rng);
            if (r != null) return r;
            if (!u.isAlive()) uci = null;                          // it died: carry on with the built-in engine
        }
        setRoot(pos);
        long start = System.nanoTime();
        IntList l = new IntList();
        for (int m : moves) l.add(m);
        int[] ord = ordered(pos, l);
        Scored result = null;
        int resultDepth = 0;
        for (int depth = 1; depth <= maxDepth; depth++) {
            deadline = depth == 1 ? Long.MAX_VALUE : start + (long) (thinkSeconds * 1e9);
            Scored sc;
            try {
                sc = root(pos, ord, depth, margin);
            } catch (Stopped e) {
                break;
            }
            result = sc;
            resultDepth = depth;
            int[] next = new int[ord.length];
            int k = 0;
            for (int i = 0; i < sc.n; i++) next[k++] = sc.moves[i];
            for (int m : ord) {
                boolean seen = false;
                for (int i = 0; i < sc.n; i++) if (sc.moves[i] == m) seen = true;
                if (!seen) next[k++] = m;
            }
            ord = next;
            if (sc.scores[0] >= MATE - 200) break;                          // forced mate found
            if ((System.nanoTime() - start) / 1e9 > thinkSeconds * 0.45) break;  // next depth too slow
        }
        if (result == null) {
            result = new Scored();
            result.moves = new int[]{ord[0]};
            result.scores = new int[]{0};
            result.n = 1;
        }
        int best = result.scores[0];
        int ci = 0;
        if (!(best >= MATE - 200 || best <= -MATE + 200) && result.n > 1) {
            double[] w = new double[result.n];
            double total = 0;
            for (int i = 0; i < result.n; i++) {
                w[i] = Math.exp((result.scores[i] - best) / Math.max(temp, 0.5));
                total += w[i];
            }
            double x = rng.nextDouble() * total;
            for (int i = 0; i < result.n; i++) {
                x -= w[i];
                if (x <= 0) {
                    ci = i;
                    break;
                }
                ci = i;
            }
        }
        Result r = new Result();
        r.move = result.moves[ci];
        r.score = result.scores[ci];
        r.bestMove = result.moves[0];
        r.bestScore = result.scores[0];
        r.depth = resultDepth;
        r.nodes = nodes;
        int[] alts = new int[Math.min(2, result.n - 1)];
        int a = 0;
        for (int i = 0; i < result.n && a < alts.length; i++) if (i != ci) alts[a++] = result.moves[i];
        r.alternatives = alts;
        r.candidates = java.util.Arrays.copyOf(result.moves, result.n);
        r.candidateScores = java.util.Arrays.copyOf(result.scores, result.n);
        return r;
    }
}
