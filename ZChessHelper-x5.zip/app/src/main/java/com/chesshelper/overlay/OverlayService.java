package com.chesshelper.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chesshelper.overlay.core.BoardGeometry;
import com.chesshelper.overlay.core.Brain;
import com.chesshelper.overlay.core.Engine;
import com.chesshelper.overlay.core.Gambits;
import com.chesshelper.overlay.core.Uci;
import com.chesshelper.overlay.core.GameTracker;
import com.chesshelper.overlay.core.Move;
import com.chesshelper.overlay.core.Position;
import com.chesshelper.overlay.core.Rules;
import com.chesshelper.overlay.core.Texts;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The floating "Chess Helper" window. It holds its own chess board: you tap every move (yours and the
 * opponent's) on it, and when it is your turn the best move is shown on that board with an ARROW and a
 * BLUE box. Nothing is read from the screen and nothing is sent anywhere.
 */
public class OverlayService extends Service {
    public static final String ACTION_STOP = "com.chesshelper.overlay.STOP";
    public static final String PREFS = "chess_helper";
    private static final String CHANNEL_ID = "chess_helper";
    private static final int NOTIF_ID = 7;
    public static volatile boolean running;

    private static final int GREEN = Color.rgb(0, 224, 0);
    private static final int BLUE = Color.rgb(47, 139, 255);
    private static final int BG = 0xFF1F2430, BAR = 0xFF11151C, FG = 0xFFE8E8E8, BTN = 0xFF323A4D;

    // Think: Instant (default) or a number of seconds. The chosen mode caps it (Bullet < Blitz < Rapid < Daily).
    private static final double[] THINK_SECONDS = {0.05, 1, 2, 3, 5, 8, 15, 30};
    private static final String[] AUTO_DONE_NAMES = {"Off", "1s", "2s", "3s", "4s", "5s"};
    private static final int RED = 0xFFE53935, RED_FILL = 0x55E53935, RED_ARROW = 0xEEE53935;
    private static final int YELLOW = 0xFFFFD600, YELLOW_FILL = 0x55FFD600, YELLOW_ARROW = 0xEEFFD600;
    private static final String[] THINK_NAMES = {"Instant", "1s", "2s", "3s", "5s", "8s", "15s", "30s"};
    private static final int[] BOARD_DP = {210, 260, 310};
    private static final String[] SIZE_NAMES = {"Small", "Medium", "Large"};

    // Choose your mode (like the Chess.com time controls). Faster mode = faster thinking, kept balanced.
    private static final String[] MODE_GROUPS = {"Bullet", "Blitz (Lightning)", "Rapid", "Daily"};
    private static final String[] MODE_LABELS = {"1 min", "1 + 1", "2 + 1", "3 min", "3 + 2", "5 min",
            "10 min", "10 + 5", "15 + 10", "1 day", "3 days", "7 days"};
    private static final double[] MODE_SECONDS = {0.3, 0.4, 0.5, 0.8, 1.0, 1.3, 2, 2.5, 3, 6, 8, 10};
    private static final int[] MODE_MARGIN = {25, 25, 25, 35, 35, 35, 45, 45, 45, 45, 45, 45};

    // features that can be shown or hidden in the window
    private static final String[] FEATURE_KEYS = {"done", "undo", "newgame", "mode", "think", "maxstrength", "safe", "noblunder", "unpred", "brill",
            "gambit", "mate", "counter", "agent", "worst", "mid", "autodone", "autosave", "side", "size"};
    private static final String[] FEATURE_NAMES = {"Done button", "Undo move", "New game", "Choose your mode",
            "Think time", "Max strength", "Safe Mode", "No blunder (Risk check)", "Unpredictable", "With Brilliant", "Use best Gambit/Trap", "Fast Checkmate 100%",
            "Counter Gambit/Trap", "Engine Agent", "Worst move (red)", "Mid move (yellow)", "Automatic Done", "Auto Save",
            "My pieces", "Board size"};

    private WindowManager wm;
    private Handler ui;
    private ExecutorService engineExec;
    private Uci stockfish;                                   // the real Stockfish (a native program shipped inside the app)
    private volatile String engineName = "built-in engine";
    private int screenW, screenH;

    // views
    private LinearLayout panel, bodyView;
    private android.widget.ScrollView bodyScroll, settingsScrollView;
    private WindowManager.LayoutParams panelParams;
    private TextView statusView, btnSide, btnThink, btnSize, btnMode, btnDone;
    private TextView btnUnpredictable, btnBrilliant, btnGambit, btnMate, btnCounter, btnWorst, btnMid, btnAutoDone, btnAutoSave;
    private TextView btnSafe, btnNoBlunder, btnAgent, btnMax;
    private int pendFrom = -1, pendTo = -1, pendMid = -1, pendWorst = -1;
    private boolean pendBrilliant;
    private View confirmDialog;
    private final List<Uci> agentList = new ArrayList<>();                // the second engines that really started
    private TextView[] modeButtons = new TextView[MODE_LABELS.length];
    private LinearLayout modeBox, settingsView, doneRow;
    private boolean featuresCollapsed;
    private TextView[] featureToggles = new TextView[FEATURE_KEYS.length];
    private View[] featureViews = new View[FEATURE_KEYS.length];
    private final boolean[] featureShown = new boolean[FEATURE_KEYS.length];
    private final List<LinearLayout> bodyRows = new ArrayList<>();
    private View closeDialog, promoDialog;
    private BoardView boardView;

    // game state (UI thread only)
    private final GameTracker tracker = new GameTracker(true);
    private final List<Position> history = new ArrayList<>();
    private final List<Integer> moveInts = new ArrayList<>();      // the moves played so far (for Counter + Auto Save)
    private final Set<String> failedGambits = new HashSet<>();
    private boolean myWhite = true;
    private boolean unpredictable = true, onlyBrilliant, bestGambit, fastMate, counter, showWorst, showMid, autoSave = true;
    private boolean safeMode, noBlunder = true, agentOn = true;
    private boolean maxStrength = true;                   // only the engine's real best move, at least 3 s of thinking
    private volatile String agentName = "";               // the second engine, when this build has one
    private int thinkIdx = 0, sizeIdx = 0, modeIdx = 7, autoDoneIdx = 0;      // the board starts small
    private int hintMove = -1;                         // the move behind the blue hint (for Done)
    private int job;                                   // bumps whenever work is cancelled / restarted
    private AtomicBoolean cancelFlag = new AtomicBoolean(false);
    // Pondering (like Stockfish): while you play your move and wait, the engine predicts the opponent's reply and
    // already works out its answer, so when that reply is tapped the answer is ready at once.
    private final java.util.concurrent.ConcurrentHashMap<String, Brain.Decision> ponderCache = new java.util.concurrent.ConcurrentHashMap<>();
    private volatile AtomicBoolean ponderCancel = new AtomicBoolean(true);
    private String hintStatus = "";

    // ================================================================== lifecycle
    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        ui = new Handler(Looper.getMainLooper());
        engineExec = Executors.newSingleThreadExecutor();
        engineExec.execute(this::startStockfish);            // first in the queue: every think waits for it
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running || intent == null) return START_NOT_STICKY;
        try {
            createChannel();
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NOTIF_ID, n);
            }
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
            loadConfig();
            buildUi();
            running = true;
            if (restoreGame()) {
                boardView.clearSelection();
                advance();
            } else {
                newGame();
            }
        } catch (Exception e) {
            Toast.makeText(this, "Chess Helper could not start: " + e.getMessage(), Toast.LENGTH_LONG).show();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        cancelAll();
        ui.removeCallbacksAndMessages(null);
        try {
            if (closeDialog != null) wm.removeViewImmediate(closeDialog);
            if (confirmDialog != null) wm.removeViewImmediate(confirmDialog);
            if (promoDialog != null) wm.removeViewImmediate(promoDialog);
            if (panel != null) wm.removeViewImmediate(panel);
        } catch (Exception ignored) {
        }
        engineExec.shutdownNow();
        Engine.uci = null;
        Engine.agentsOn = false;
        Engine.agents.clear();
        if (stockfish != null) stockfish.close();
        for (Uci a : agentList) a.close();
        super.onDestroy();
    }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Chess Helper",
                NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification.Action action = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", pi).build();
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Chess Helper is running")
                .setContentText("Tap Stop to close the helper.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .addAction(action)
                .setOngoing(true)
                .build();
    }

    // ================================================================== UI helpers
    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private TextView makeButton(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(FG);
        t.setTextSize(11.5f);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(4), dp(6), dp(4), dp(6));
        t.setBackground(rounded(BTN, dp(8)));
        t.setClickable(true);
        t.setOnClickListener(l);
        return t;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(3);
        r.setLayoutParams(lp);
        return r;
    }

    private void addWeighted(LinearLayout row, View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(2);
        lp.rightMargin = dp(2);
        row.addView(v, lp);
    }

    private TextView smallText(int color, float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setTextColor(color);
        t.setTextSize(sp);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private int boardPx() {
        int want = dp(BOARD_DP[sizeIdx]);
        return Math.min(want, screenW - dp(28));
    }

    private void buildUi() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(rounded(BG, dp(14)));

        // ---- title bar (drag handle) ----
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(rounded(BAR, dp(14)));
        TextView title = smallText(GREEN, 15, true);
        title.setText("♞  Chess Helper");
        title.setPadding(dp(12), dp(8), dp(8), dp(8));
        bar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView gear = smallText(0xFFAAB0C0, 17, false);
        gear.setText("⚙");
        gear.setPadding(dp(12), dp(4), dp(10), dp(4));
        gear.setOnClickListener(v -> {                       // tap: hide / show all the feature buttons
            featuresCollapsed = !featuresCollapsed;
            applyFeatureVisibility();
            saveConfig();
        });
        gear.setOnLongClickListener(v -> {                   // long-press: choose which features to show
            toggleSettings();
            return true;
        });
        bar.addView(gear);
        TextView collapse = smallText(0xFFAAB0C0, 20, false);
        collapse.setText("–");
        collapse.setPadding(dp(14), dp(4), dp(14), dp(4));
        collapse.setOnClickListener(v -> {
            boolean open = bodyScroll.getVisibility() == View.VISIBLE || settingsView.getVisibility() == View.VISIBLE;
            if (open) {
                bodyScroll.setVisibility(View.GONE);
                settingsView.setVisibility(View.GONE);
            } else {
                bodyScroll.setVisibility(View.VISIBLE);
            }
        });
        bar.addView(collapse);
        TextView close = smallText(0xFFAAB0C0, 18, false);
        close.setText("✕");
        close.setPadding(dp(14), dp(4), dp(14), dp(4));
        close.setOnClickListener(v -> askClose());
        bar.addView(close);
        bar.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = panelParams.x;
                        sy = panelParams.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelParams.x = sx + (int) (e.getRawX() - tx);
                        // keep the title bar on the screen, and let the scroll area fit the room that is left
                        panelParams.y = Math.max(0, Math.min(screenHeight() - dp(150), sy + (int) (e.getRawY() - ty)));
                        bodyScroll.requestLayout();
                        settingsScrollView.requestLayout();
                        wm.updateViewLayout(panel, panelParams);
                        return true;
                    default:
                        return false;
                }
            }
        });
        panel.addView(bar);

        // ---- body ----
        bodyView = new LinearLayout(this);
        bodyView.setOrientation(LinearLayout.VERTICAL);
        bodyView.setPadding(dp(10), dp(6), dp(10), dp(10));
        // The body scrolls when it is taller than the screen (small board = narrow window = taller buttons).
        bodyScroll = new android.widget.ScrollView(this) {
            @Override
            protected void onMeasure(int widthSpec, int heightSpec) {
                int room = screenHeight() - Math.max(0, panelParams.y) - dp(150);  // title bar + system bars
                int max = Math.max(dp(140), room);
                super.onMeasure(widthSpec, View.MeasureSpec.makeMeasureSpec(max, View.MeasureSpec.AT_MOST));
            }
        };
        bodyScroll.setVerticalScrollBarEnabled(true);
        bodyScroll.setScrollbarFadingEnabled(false);
        bodyScroll.addView(bodyView);
        panel.addView(bodyScroll);

        statusView = smallText(FG, 12, true);
        bodyView.addView(statusView);

        boardView = new BoardView(this);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(boardPx(), boardPx());
        blp.topMargin = dp(6);
        blp.gravity = Gravity.CENTER_HORIZONTAL;
        bodyView.addView(boardView, blp);

        // ---- Done ----
        btnDone = makeButton("Done ✔  (place the move)", v -> done());
        btnDone.setTextSize(13);
        btnDone.setTypeface(null, android.graphics.Typeface.BOLD);
        btnDone.setTextColor(Color.WHITE);
        btnDone.setBackground(rounded(0xFF1B8A1B, dp(10)));
        LinearLayout rDone = row();
        doneRow = rDone;
        addWeighted(rDone, btnDone);
        bodyView.addView(rDone);
        bodyRows.add(rDone);
        featureViews[idx("done")] = btnDone;

        LinearLayout r1 = row();
        TextView btnUndo = makeButton("Undo move", v -> undo());
        TextView btnNew = makeButton("New game", v -> askConfirm("Are you sure to start a new game?",
                "The game on the helper board is cleared.", "Yes", "No", 0xFFB3261E, this::newGame));
        addWeighted(r1, btnUndo);
        addWeighted(r1, btnNew);
        bodyView.addView(r1);
        bodyRows.add(r1);
        featureViews[idx("undo")] = btnUndo;
        featureViews[idx("newgame")] = btnNew;

        // ---- Choose your mode (+ the picker) ----
        btnMode = makeButton("", v -> modeBox.setVisibility(
                modeBox.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        LinearLayout rMode = row();
        addWeighted(rMode, btnMode);
        bodyView.addView(rMode);
        bodyRows.add(rMode);
        featureViews[idx("mode")] = btnMode;
        buildModeBox();
        bodyView.addView(modeBox);

        LinearLayout rM = row();
        btnMax = makeButton("", v -> {
            maxStrength = !maxStrength;
            optionsChanged();
            setStatus(maxStrength
                    ? "Max strength is on: only Stockfish's best move, thinking at least 3 s."
                    : "Max strength is off: Unpredictable, Safe Mode and the other switches work again (a little weaker).");
        });
        addWeighted(rM, btnMax);
        bodyView.addView(rM);
        bodyRows.add(rM);
        featureViews[idx("maxstrength")] = btnMax;

        LinearLayout rS = row();
        btnSafe = makeButton("", v -> {
            if (maxStrength) {
                setStatus("Max strength is on, so Safe Mode is off. Turn Max strength off to use Safe Mode.");
                return;
            }
            safeMode = !safeMode;
            optionsChanged();
        });
        btnNoBlunder = makeButton("", v -> {
            if (maxStrength) {
                setStatus("Max strength is on: it already shows the engine's best move. Turn it off to use No blunder.");
                return;
            }
            if (safeMode) {
                setStatus("Safe Mode already keeps No blunder on.");
                return;
            }
            noBlunder = !noBlunder;
            optionsChanged();
        });
        addWeighted(rS, btnSafe);
        addWeighted(rS, btnNoBlunder);
        bodyView.addView(rS);
        bodyRows.add(rS);
        featureViews[idx("safe")] = btnSafe;
        featureViews[idx("noblunder")] = btnNoBlunder;

        LinearLayout r2 = row();
        btnUnpredictable = makeButton("", v -> {
            if (maxStrength) {
                setStatus("Max strength is on, so Unpredictable is off. Turn Max strength off to use it.");
                return;
            }
            if (safeMode) {
                setStatus("Safe Mode is on, so Unpredictable is off. Turn Safe Mode off to use it.");
                return;
            }
            unpredictable = !unpredictable;
            optionsChanged();
        });
        btnBrilliant = makeButton("", v -> {
            if (maxStrength) {
                setStatus("Max strength is on, so With Brilliant is off. Turn Max strength off to use it.");
                return;
            }
            if (safeMode) {
                setStatus("Safe Mode is on, so With Brilliant is off. Turn Safe Mode off to use it.");
                return;
            }
            onlyBrilliant = !onlyBrilliant;
            optionsChanged();
        });
        addWeighted(r2, btnUnpredictable);
        addWeighted(r2, btnBrilliant);
        bodyView.addView(r2);
        bodyRows.add(r2);
        featureViews[idx("unpred")] = btnUnpredictable;
        featureViews[idx("brill")] = btnBrilliant;

        LinearLayout r3 = row();
        btnGambit = makeButton("", v -> {
            if (maxStrength) {
                setStatus("Max strength is on, so gambits and traps are off. Turn Max strength off to use them.");
                return;
            }
            if (safeMode) {
                setStatus("Safe Mode is on, so gambits and traps are off. Turn Safe Mode off to use them.");
                return;
            }
            bestGambit = !bestGambit;
            failedGambits.clear();
            optionsChanged();
        });
        btnMate = makeButton("", v -> {
            fastMate = !fastMate;
            optionsChanged();
        });
        addWeighted(r3, btnGambit);
        addWeighted(r3, btnMate);
        bodyView.addView(r3);
        bodyRows.add(r3);
        featureViews[idx("gambit")] = btnGambit;
        featureViews[idx("mate")] = btnMate;

        LinearLayout r4 = row();
        btnThink = makeButton("", v -> {
            thinkIdx = (thinkIdx + 1) % THINK_SECONDS.length;
            optionsChanged();
        });
        btnAutoDone = makeButton("", v -> {
            autoDoneIdx = (autoDoneIdx + 1) % AUTO_DONE_NAMES.length;
            optionsChanged();
        });
        addWeighted(r4, btnThink);
        addWeighted(r4, btnAutoDone);
        bodyView.addView(r4);
        bodyRows.add(r4);
        featureViews[idx("think")] = btnThink;
        featureViews[idx("autodone")] = btnAutoDone;

        LinearLayout rC = row();
        btnCounter = makeButton("", v -> {
            counter = !counter;
            optionsChanged();
        });
        btnAutoSave = makeButton("", v -> {
            autoSave = !autoSave;
            if (!autoSave) clearSaved();
            optionsChanged();
            saveGame();
        });
        addWeighted(rC, btnCounter);
        addWeighted(rC, btnAutoSave);
        bodyView.addView(rC);
        bodyRows.add(rC);
        featureViews[idx("counter")] = btnCounter;
        featureViews[idx("autosave")] = btnAutoSave;

        LinearLayout rA = row();
        btnAgent = makeButton("", v -> {
            if (maxStrength) {
                setStatus("Max strength is on: Stockfish gets the whole phone, so the second engines rest. Turn Max strength off to use Engine Agent.");
                return;
            }
            if (agentName.isEmpty()) {
                setStatus("This build has no second engine. It is added when the build can make one (see the README).");
                return;
            }
            agentOn = !agentOn;
            optionsChanged();
        });
        addWeighted(rA, btnAgent);
        bodyView.addView(rA);
        bodyRows.add(rA);
        featureViews[idx("agent")] = btnAgent;

        LinearLayout rW = row();
        btnWorst = makeButton("", v -> {
            showWorst = !showWorst;
            optionsChanged();
        });
        btnMid = makeButton("", v -> {
            showMid = !showMid;
            optionsChanged();
        });
        addWeighted(rW, btnWorst);
        addWeighted(rW, btnMid);
        bodyView.addView(rW);
        bodyRows.add(rW);
        featureViews[idx("worst")] = btnWorst;
        featureViews[idx("mid")] = btnMid;

        LinearLayout r5 = row();
        btnSide = makeButton("", v -> askConfirm("Change side?",
                "This starts a new game and clears the board.", "Yes", "No", 0xFFB3261E, this::toggleSide));
        btnSize = makeButton("", v -> {
            sizeIdx = (sizeIdx + 1) % BOARD_DP.length;
            applySize();
            saveConfig();
            refreshButtons();
        });
        addWeighted(r5, btnSide);
        addWeighted(r5, btnSize);
        bodyView.addView(r5);
        bodyRows.add(r5);
        featureViews[idx("side")] = btnSide;
        featureViews[idx("size")] = btnSize;

        buildSettingsView();
        settingsScrollView = new android.widget.ScrollView(this) {   // scrolls too, so every switch can be reached
            @Override
            protected void onMeasure(int widthSpec, int heightSpec) {
                int room = screenHeight() - Math.max(0, panelParams.y) - dp(150);
                super.onMeasure(widthSpec, View.MeasureSpec.makeMeasureSpec(Math.max(dp(140), room), View.MeasureSpec.AT_MOST));
            }
        };
        settingsScrollView.addView(settingsView);
        panel.addView(settingsScrollView);

        refreshButtons();
        applyFeatureVisibility();

        panelParams = new WindowManager.LayoutParams(panelWidth(), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = dp(8);
        panelParams.y = dp(48);
        wm.addView(panel, panelParams);
    }

    /** The height of the screen right now (it changes when the phone is turned). */
    private int screenHeight() {
        int h = getResources().getDisplayMetrics().heightPixels;
        return h > 0 ? h : screenH;
    }

    private int panelWidth() {
        return boardPx() + dp(20);
    }

    private void applySize() {
        LinearLayout.LayoutParams blp = (LinearLayout.LayoutParams) boardView.getLayoutParams();
        blp.width = boardPx();
        blp.height = boardPx();
        boardView.setLayoutParams(blp);
        panelParams.width = panelWidth();
        wm.updateViewLayout(panel, panelParams);
    }

    private void toggleButton(TextView b, String name, boolean on) {
        toggleButton(b, name, on, "ON", "OFF");
    }

    private void toggleButton(TextView b, String name, boolean on, String onText, String offText) {
        b.setText(name + ": " + (on ? onText : offText));
        b.setTextColor(on ? GREEN : FG);
        b.setBackground(rounded(on ? 0xFF1B4A24 : BTN, dp(8)));
    }

    /** A switch that Safe Mode (or the build) fixes: shown greyed with the reason. */
    private void lockedButton(TextView b, String name, String state, boolean green) {
        b.setText(name + ": " + state);
        b.setTextColor(green ? GREEN : 0xFF8890A0);
        b.setBackground(rounded(green ? 0xFF1B4A24 : 0xFF262C3A, dp(8)));
    }

    private void refreshButtons() {
        toggleButton(btnMax, "Max strength", maxStrength, "ON (best move only, 3 s+)", "OFF");
        if (maxStrength) {
            lockedButton(btnSafe, "Safe Mode", "OFF (Max strength)", false);
            lockedButton(btnNoBlunder, "No blunder (Risk check)", "OFF (Max strength)", false);
            lockedButton(btnUnpredictable, "Unpredictable", "OFF (Max strength)", false);
            lockedButton(btnBrilliant, "With Brilliant (!!)", "OFF (Max strength)", false);
            lockedButton(btnGambit, "Use best Gambit/Trap", "OFF (Max strength)", false);
        } else {
            toggleButton(btnSafe, "Safe Mode", safeMode);
            if (safeMode) {
                lockedButton(btnNoBlunder, "No blunder (Risk check)", "ON (Safe Mode)", true);
                lockedButton(btnUnpredictable, "Unpredictable", "OFF (Safe Mode)", false);
                lockedButton(btnBrilliant, "With Brilliant (!!)", "OFF (Safe Mode)", false);
                lockedButton(btnGambit, "Use best Gambit/Trap", "OFF (Safe Mode)", false);
            } else {
                toggleButton(btnNoBlunder, "No blunder (Risk check)", noBlunder);
                toggleButton(btnUnpredictable, "Unpredictable", unpredictable);
                toggleButton(btnBrilliant, "With Brilliant (!!)", onlyBrilliant);
                toggleButton(btnGambit, "Use best Gambit/Trap", bestGambit);
            }
        }
        if (maxStrength) {
            lockedButton(btnAgent, "Engine Agent", "resting (Max strength)", false);
        } else if (agentName.isEmpty()) {
            lockedButton(btnAgent, "Engine Agent", "none in this build", false);
        } else {
            toggleButton(btnAgent, "Engine Agent", agentOn, "ON (" + agentName + ")", "OFF");
        }
        toggleButton(btnMate, "Fast Checkmate 100%", fastMate);
        toggleButton(btnCounter, "Counter Gambit/Trap", counter);
        toggleButton(btnAutoSave, "Auto Save", autoSave);
        btnAutoDone.setText("Automatic Done: " + AUTO_DONE_NAMES[autoDoneIdx]);
        toggleButton(btnWorst, "Worst move (red)", showWorst);
        toggleButton(btnMid, "Mid move (yellow)", showMid);
        btnSide.setText("My pieces: " + (myWhite ? "White" : "Black"));
        btnThink.setText("Think: " + THINK_NAMES[thinkIdx] + (maxStrength && THINK_SECONDS[thinkIdx] < Brain.MAX_STRENGTH_SECONDS ? " (3s+ in Max)" : ""));
        btnSize.setText("Board size: " + SIZE_NAMES[sizeIdx]);
        btnMode.setText("Choose your mode  ·  " + modeGroupOf(modeIdx) + " " + MODE_LABELS[modeIdx]);
        for (int i = 0; i < modeButtons.length; i++) {
            boolean on = i == modeIdx;
            modeButtons[i].setTextColor(on ? GREEN : FG);
            GradientDrawable g = rounded(BTN, dp(8));
            if (on) g.setStroke(dp(2), GREEN);
            modeButtons[i].setBackground(g);
        }
    }

    private static String modeGroupOf(int i) {
        return MODE_GROUPS[i / 3];
    }

    private int idx(String key) {
        for (int i = 0; i < FEATURE_KEYS.length; i++) if (FEATURE_KEYS[i].equals(key)) return i;
        return -1;
    }

    private void buildModeBox() {
        modeBox = new LinearLayout(this);
        modeBox.setOrientation(LinearLayout.VERTICAL);
        modeBox.setVisibility(View.GONE);
        modeBox.setBackground(rounded(0xFF181C25, dp(10)));
        modeBox.setPadding(dp(6), dp(4), dp(6), dp(6));
        for (int g = 0; g < MODE_GROUPS.length; g++) {
            TextView head = smallText(0xFFFFFFFF, 13, true);
            head.setText(MODE_GROUPS[g]);
            head.setPadding(dp(4), dp(6), 0, 0);
            modeBox.addView(head);
            LinearLayout r = row();
            for (int k = 0; k < 3; k++) {
                final int index = g * 3 + k;
                TextView b = makeButton(MODE_LABELS[index], v -> {
                    modeIdx = index;
                    thinkIdx = 0;                              // the mode sets the thinking time
                    modeBox.setVisibility(View.GONE);
                    optionsChanged();
                });
                modeButtons[index] = b;
                addWeighted(r, b);
            }
            modeBox.addView(r);
        }
    }

    private void buildSettingsView() {
        settingsView = new LinearLayout(this);
        settingsView.setOrientation(LinearLayout.VERTICAL);
        settingsView.setPadding(dp(10), dp(6), dp(10), dp(10));
        settingsView.setVisibility(View.GONE);
        TextView head = smallText(FG, 13, true);
        head.setText("Settings: show or hide features.\nA hidden feature keeps its current setting.");
        settingsView.addView(head);
        LinearLayout r = null;
        for (int i = 0; i < FEATURE_KEYS.length; i++) {
            if (i % 2 == 0) {
                r = row();
                settingsView.addView(r);
            }
            final int index = i;
            featureToggles[i] = makeButton("", v -> {
                featureShown[index] = !featureShown[index];
                applyFeatureVisibility();
                saveConfig();
            });
            addWeighted(r, featureToggles[i]);
        }
        LinearLayout ra = row();
        addWeighted(ra, makeButton("Show all", v -> setAllFeatures(true)));
        addWeighted(ra, makeButton("Hide all", v -> setAllFeatures(false)));
        settingsView.addView(ra);
        LinearLayout rb = row();
        addWeighted(rb, makeButton("Back to the board", v -> toggleSettings()));
        settingsView.addView(rb);
    }

    private void setAllFeatures(boolean show) {
        java.util.Arrays.fill(featureShown, show);
        applyFeatureVisibility();
        saveConfig();
    }

    private void toggleSettings() {
        boolean open = settingsView.getVisibility() == View.VISIBLE;
        settingsView.setVisibility(open ? View.GONE : View.VISIBLE);
        bodyScroll.setVisibility(open ? View.VISIBLE : View.GONE);
    }

    private void applyFeatureVisibility() {
        for (int i = 0; i < FEATURE_KEYS.length; i++) {
            if (featureViews[i] != null) featureViews[i].setVisibility(featureShown[i] ? View.VISIBLE : View.GONE);
            toggleButton(featureToggles[i], FEATURE_NAMES[i], featureShown[i], "SHOWN", "HIDDEN");
        }
        for (LinearLayout row : bodyRows) {
            boolean any = false;
            for (int c = 0; c < row.getChildCount(); c++) if (row.getChildAt(c).getVisibility() == View.VISIBLE) any = true;
            boolean keep = !featuresCollapsed || row == doneRow;      // collapsed: only the Done button stays
            row.setVisibility(any && keep ? View.VISIBLE : View.GONE);
        }
        if (!featureShown[idx("mode")] || featuresCollapsed) modeBox.setVisibility(View.GONE);
    }

    private void setStatus(String s) {
        statusView.setText(s);
    }

    // ================================================================== close pop-up
    private void askClose() {
        if (closeDialog != null) return;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rounded(0xFF2A3042, dp(16)));
        card.setPadding(dp(22), dp(20), dp(22), dp(18));
        TextView q = smallText(Color.WHITE, 17, true);
        q.setText("Are you sure to close?");
        q.setGravity(Gravity.CENTER);
        card.addView(q);
        LinearLayout r = row();
        TextView yes = makeButton("Yes", v -> stopSelf());
        yes.setTextSize(16);
        yes.setBackground(rounded(0xFFB3261E, dp(10)));
        yes.setTextColor(Color.WHITE);
        TextView no = makeButton("No", v -> dismissClose());
        no.setTextSize(16);
        no.setBackground(rounded(0xFF1B8A1B, dp(10)));
        no.setTextColor(Color.WHITE);
        addWeighted(r, yes);
        addWeighted(r, no);
        LinearLayout.LayoutParams rp = (LinearLayout.LayoutParams) r.getLayoutParams();
        rp.topMargin = dp(16);
        card.addView(r);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(Math.min(dp(300), screenW - dp(40)),
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_DIM_BEHIND,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.CENTER;
        lp.dimAmount = 0.55f;
        try {
            wm.addView(card, lp);
            closeDialog = card;
        } catch (Exception e) {
            stopSelf();
        }
    }

    /** A small Yes/No pop-up over everything (used to stop accidental taps). */
    private void askConfirm(String title, String body, String yesText, String noText, int yesColor, Runnable onYes) {
        if (confirmDialog != null) return;
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rounded(0xFF2A3042, dp(16)));
        card.setPadding(dp(22), dp(20), dp(22), dp(18));
        TextView q = smallText(Color.WHITE, 17, true);
        q.setText(title);
        q.setGravity(Gravity.CENTER);
        card.addView(q);
        if (body != null && !body.isEmpty()) {
            TextView b = smallText(0xFFC8CEDC, 13, false);
            b.setText(body);
            b.setGravity(Gravity.CENTER);
            b.setPadding(0, dp(8), 0, 0);
            card.addView(b);
        }
        LinearLayout r = row();
        TextView yes = makeButton(yesText, v -> {
            dismissConfirm();
            onYes.run();
        });
        yes.setTextSize(16);
        yes.setBackground(rounded(yesColor, dp(10)));
        yes.setTextColor(Color.WHITE);
        TextView no = makeButton(noText, v -> dismissConfirm());
        no.setTextSize(16);
        no.setBackground(rounded(0xFF3A4156, dp(10)));
        no.setTextColor(Color.WHITE);
        addWeighted(r, yes);
        addWeighted(r, no);
        LinearLayout.LayoutParams rp = (LinearLayout.LayoutParams) r.getLayoutParams();
        rp.topMargin = dp(16);
        card.addView(r);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(Math.min(dp(320), screenW - dp(40)),
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_DIM_BEHIND,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.CENTER;
        lp.dimAmount = 0.55f;
        try {
            wm.addView(card, lp);
            confirmDialog = card;
        } catch (Exception e) {
            onYes.run();
        }
    }

    private void dismissConfirm() {
        if (confirmDialog == null) return;
        try {
            wm.removeViewImmediate(confirmDialog);
        } catch (Exception ignored) {
        }
        confirmDialog = null;
    }

    private void dismissClose() {
        if (closeDialog == null) return;
        try {
            wm.removeViewImmediate(closeDialog);
        } catch (Exception ignored) {
        }
        closeDialog = null;
    }

    /** Removes the hint (the move, box and arrow) from the board. */
    private void clearHint() {
        hintMove = -1;
        pendFrom = pendTo = pendMid = pendWorst = -1;
        pendBrilliant = false;
        boardView.setHint(-1, -1);
    }

    /** Puts the box and arrow of the prepared hint on the board. */
    private void showHint() {
        if (hintMove < 0 || pendFrom < 0) return;
        boardView.setHint(pendFrom, pendTo);
        boardView.setBrilliant(pendBrilliant);
        boardView.setExtras(pendMid, pendWorst);
        setStatus(hintStatus);
    }

    private void done() {
        if (hintMove < 0) {
            setStatus("No move is shown yet. Wait for your turn.");
            return;
        }
        playMove(hintMove);                                         // puts the piece there, then waits for the opponent
    }

    // ================================================================== game
    /** Is this a 32-bit phone (or a 64-bit phone running 32-bit Android)? */
    private static boolean is32Bit() {
        try {
            return Build.SUPPORTED_64_BIT_ABIS == null || Build.SUPPORTED_64_BIT_ABIS.length == 0;
        } catch (Throwable t) {
            return false;
        }
    }

    /**
     * Starts the Stockfish program that was built into the app (fast dot-product version when the phone has it,
     * otherwise the plain one) and, when this build has one, a second engine for the Engine Agent.
     * If anything is wrong the built-in engine is used.
     */
    private void startStockfish() {
        try {
            java.io.File dir = new java.io.File(getApplicationInfo().nativeLibraryDir);
            java.io.File plain = new java.io.File(dir, "libstockfish.so");
            java.io.File fast = new java.io.File(dir, "libstockfish_dp.so");     // for phones with the dot-product instructions
            boolean small = is32Bit();                                           // 32-bit phones: less memory, fewer threads
            int cores = Runtime.getRuntime().availableProcessors();
            int threads = Math.max(1, Math.min(small ? 2 : 4, cores / 2));
            int hash = small ? 48 : 128;
            if (!plain.exists() && !fast.exists()) {
                engineName = "built-in engine (no Stockfish in this build)";
            } else {
                Uci u = null;
                if (fast.exists() && hasDotProduct()) u = Uci.start(fast.getAbsolutePath(), threads, hash);
                if (u == null && plain.exists()) u = Uci.start(plain.getAbsolutePath(), threads, hash);
                if (u == null) {
                    engineName = "built-in engine (Stockfish could not start on this phone)";
                } else {
                    stockfish = u;
                    Engine.uci = u;
                    engineName = u.name;
                }
            }
            // Engine Agent: second engines shipped as libeng_<name>.so (any phone) or libengdp_<name>.so (dot-product phones)
            java.io.File[] files = dir.listFiles();
            if (files != null && Engine.uci != null) {
                List<java.io.File> found = new ArrayList<>();
                for (java.io.File f : files) {
                    String n = f.getName();
                    boolean any = n.startsWith("libeng_") && n.endsWith(".so");
                    boolean dp = n.startsWith("libengdp_") && n.endsWith(".so") && hasDotProduct();
                    if (any || dp) found.add(f);
                }
                java.util.Collections.sort(found, (x, y) -> {
                    int c = agentRank(x.getName()) - agentRank(y.getName());
                    return c != 0 ? c : x.getName().compareTo(y.getName());
                });
                int limit = agentLimitForPhone(cores, small);
                Engine.agentLimit = limit;
                int each = limit > 2 ? 1 : Math.max(1, Math.min(2, cores / 4));
                StringBuilder names = new StringBuilder();
                for (java.io.File f : found) {
                    if (agentList.size() >= limit) break;                        // the phone's memory sets the limit
                    Uci a = Uci.start(f.getAbsolutePath(), each, small ? 32 : 64);
                    if (a == null) continue;                                     // did not start: go on without it
                    a.weight = agentWeight(f.getName());
                    agentList.add(a);
                    Engine.agents.add(a);
                    names.append(names.length() == 0 ? "" : " + ").append(a.name.split(" ")[0]);
                }
                agentName = names.toString();
            }
            ui.post(this::refreshButtons);
        } catch (Throwable t) {
            if (Engine.uci == null) engineName = "built-in engine (Stockfish error)";
        }
    }

    /** Order of the second engines: comparison engines first (Reckless, Triumviratus), then the analysis ones. */
    private static int agentRank(String file) {
        String n = file.toLowerCase(java.util.Locale.ROOT);
        if (n.contains("reckless")) return 0;
        if (n.contains("triumviratus")) return 1;
        if (n.contains("plenty")) return 2;
        if (n.contains("shash")) return 3;
        return 4;
    }

    /** How much a second engine's opinion counts: 2 = comparison engine, 1 = extra analysis. */
    private static int agentWeight(String file) {
        String n = file.toLowerCase(java.util.Locale.ROOT);
        return n.contains("plenty") || n.contains("shash") ? 1 : 2;
    }

    /** How many second engines this phone can run at once (each one holds a network in memory and uses processor time). */
    private int agentLimitForPhone(int cores, boolean small) {
        if (small) return 1;
        long mb = 0;
        try {
            android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
            android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
            am.getMemoryInfo(mi);
            mb = mi.totalMem / (1024 * 1024);
        } catch (Throwable ignored) {
        }
        if (mb >= 7000 && cores >= 8) return 4;
        if (mb >= 5500) return 3;
        if (mb >= 3500) return 2;
        return 1;
    }

    /** Does this phone's processor have the ARM dot-product instructions (makes the Stockfish network faster)? */
    private static boolean hasDotProduct() {
        try (java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader("/proc/cpuinfo"))) {
            String line;
            while ((line = r.readLine()) != null) {
                if (line.startsWith("Features") && line.contains("asimddp")) return true;
            }
        } catch (Exception ignored) {
        }
        return false;
    }

    private String engineLine(Brain.Decision dec) {
        boolean sf = Engine.uci != null;
        String depth = dec.result != null && dec.result.depth > 0 ? ", depth " + dec.result.depth : "";
        String second = sf && Engine.agentsOn && !Engine.agents.isEmpty() ? " + " + agentName : "";
        return "Engine: " + (sf ? engineName : engineName.startsWith("built-in") ? engineName : "built-in engine") + second + depth;
    }

    private void stopPonder(boolean clearCache) {
        ponderCancel.set(true);
        if (clearCache) ponderCache.clear();
    }

    private void cancelAll() {
        job++;
        cancelFlag.set(true);
        cancelFlag = new AtomicBoolean(false);
    }

    private void optionsChanged() {
        stopPonder(true);
        saveConfig();
        refreshButtons();
        advance();                                      // new settings: work out the hint again
    }

    private void newGame() {
        cancelAll();
        tracker.myWhite = myWhite;
        tracker.reset();
        stopPonder(true);
        final Uci sfNow = stockfish;
        if (sfNow != null) engineExec.execute(sfNow::newGame);       // a clean start for Stockfish's memory
        for (final Uci agNow : new ArrayList<>(agentList)) engineExec.execute(agNow::newGame);
        history.clear();
        moveInts.clear();
        clearSaved();
        failedGambits.clear();
        boardView.clearSelection();
        clearHint();
        advance();
    }

    private void undo() {
        if (history.isEmpty() || tracker.keys.size() < 2) return;
        cancelAll();
        stopPonder(true);
        tracker.pos = history.remove(history.size() - 1);
        if (!moveInts.isEmpty()) moveInts.remove(moveInts.size() - 1);
        tracker.keys.remove(tracker.keys.size() - 1);
        failedGambits.clear();
        boardView.clearSelection();
        clearHint();
        saveGame();
        advance();
    }

    private void toggleSide() {
        myWhite = !myWhite;
        saveConfig();
        refreshButtons();
        newGame();
    }

    /** A move tapped on the board: if it is a promotion, ask which piece. */
    private void play(int from, int to) {
        List<Integer> options = new ArrayList<>();
        for (int m : Rules.legalMoves(tracker.pos)) {
            if (Move.from(m) == from && Move.to(m) == to) options.add(m);
        }
        if (options.isEmpty()) return;
        if (options.size() == 1) {
            playMove(options.get(0));
            return;
        }
        askPromotion(options);
    }

    private void playMove(int chosen) {
        Position pos = tracker.pos;
        cancelAll();
        history.add(pos);
        moveInts.add(chosen);
        tracker.pos = Rules.apply(pos, chosen);
        tracker.keys.add(tracker.pos.key());
        clearHint();
        saveGame();
        advance();
    }

    private void askPromotion(List<Integer> options) {
        if (promoDialog != null) return;
        final boolean enemy = tracker.pos.white != myWhite;               // the pawn of the other side reached the last row
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(rounded(0xFF2A3042, dp(18)));
        card.setPadding(dp(14), dp(16), dp(14), dp(12));
        TextView q = smallText(Color.WHITE, 16, true);
        q.setText(enemy ? "The enemy pawn reached your side.\nWhat did it become?" : "Promote your pawn to:");
        q.setGravity(Gravity.CENTER);
        card.addView(q);
        TextView hint = smallText(0xFFAAB0C0, 12, false);
        hint.setText(enemy ? "Pick the piece the real game shows (a king is not allowed in chess)." : "A king is not allowed in chess.");
        hint.setGravity(Gravity.CENTER);
        hint.setPadding(0, dp(4), 0, dp(10));
        card.addView(hint);
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER);
        for (int m : options) {
            final int move = m;
            char pr = Move.promo(m) == 0 ? 'Q' : Move.promo(m);
            LinearLayout cell = new LinearLayout(this);
            cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER_HORIZONTAL);
            cell.setPadding(dp(4), 0, dp(4), 0);
            TextView circle = new TextView(this);
            circle.setText(Texts.glyph(pr));
            circle.setTextSize(30);
            circle.setGravity(Gravity.CENTER);
            circle.setTextColor(Color.WHITE);
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            g.setColor(0xFF1BB51B);
            g.setStroke(dp(3), 0xFF000000);
            circle.setBackground(g);
            circle.setOnClickListener(v -> {
                dismissPromo();
                playMove(move);
            });
            cell.addView(circle, new LinearLayout.LayoutParams(dp(58), dp(58)));
            TextView name = smallText(Color.WHITE, 12, false);
            name.setText(Texts.pieceName(pr));
            name.setGravity(Gravity.CENTER);
            cell.addView(name);
            r.addView(cell);
        }
        card.addView(r);
        TextView cancel = makeButton("Cancel", v -> dismissPromo());
        cancel.setTextColor(0xFFAAB0C0);
        LinearLayout cr = row();
        addWeighted(cr, cancel);
        ((LinearLayout.LayoutParams) cr.getLayoutParams()).topMargin = dp(10);
        card.addView(cr);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(Math.min(dp(340), screenW - dp(24)),
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_DIM_BEHIND,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.CENTER;
        lp.dimAmount = 0.5f;
        try {
            wm.addView(card, lp);
            promoDialog = card;
        } catch (Exception e) {
            playMove(options.get(0));
        }
    }

    private void dismissPromo() {
        if (promoDialog == null) return;
        try {
            wm.removeViewImmediate(promoDialog);
        } catch (Exception ignored) {
        }
        promoDialog = null;
    }

    // ---- Auto Save: the moves of the game are kept until New game
    private static String uci(int m) {
        char pr = Move.promo(m);
        return Rules.sqName(Move.from(m)) + Rules.sqName(Move.to(m)) + (pr == 0 ? "" : String.valueOf(Character.toLowerCase(pr)));
    }

    private void saveGame() {
        if (!autoSave) return;
        try {
            StringBuilder sb = new StringBuilder();
            for (int m : moveInts) sb.append(uci(m)).append(' ');
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("saved_moves", sb.toString().trim())
                    .putBoolean("saved_white", myWhite).apply();
        } catch (Exception ignored) {
        }
    }

    private void clearSaved() {
        try {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().remove("saved_moves").apply();
        } catch (Exception ignored) {
        }
    }

    /** Replays the saved game. @return true when a game was restored */
    private boolean restoreGame() {
        if (!autoSave) return false;
        try {
            SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
            String saved = sp.getString("saved_moves", "");
            if (saved.isEmpty()) return false;
            myWhite = sp.getBoolean("saved_white", myWhite);
            tracker.myWhite = myWhite;
            tracker.reset();
            history.clear();
            moveInts.clear();
            for (String t : saved.split(" ")) {
                int m = Gambits.parse(tracker.pos, t);
                if (m < 0) break;                                   // damaged save: keep what is valid
                history.add(tracker.pos);
                moveInts.add(m);
                tracker.pos = Rules.apply(tracker.pos, m);
                tracker.keys.add(tracker.pos.key());
            }
            return !moveInts.isEmpty();
        } catch (Exception e) {
            return false;
        }
    }

    /** After any change: game over? opponent's turn? or think about my move. */
    private void advance() {
        boardView.invalidate();
        Position pos = tracker.pos;
        String end = Rules.outcome(pos, tracker.keys, null);
        if (end != null) {
            setStatus(end);
            return;
        }
        if (pos.white != myWhite) {
            setStatus("Opponent's turn. Tap the piece they moved, then its new square.");
            return;
        }
        setStatus("Your turn - thinking…");
        think();
    }

    /** Predicts the opponent's most likely replies to the shown move and prepares our answers in the background. */
    private void startPonder(final Position pos, final int move, final boolean mine, final Brain.Options base,
                             final Set<String> failedNow) {
        stopPonder(true);
        final AtomicBoolean flag = new AtomicBoolean(false);
        ponderCancel = flag;
        final int shown = move;
        final int jobNow = job;
        final Set<String> failed = new HashSet<>(failedNow);
        final Random rng = new Random();
        engineExec.execute(() -> {
            try {
                Position p1 = Rules.apply(pos, shown);
                if (Rules.legalMoves(p1).length == 0 || flag.get()) return;
                Engine e = new Engine(flag);
                Engine.Result r = e.search(p1, 40, base.instant ? 0.25 : Math.max(0.4, Math.min(2.0, base.thinkSeconds / 2)), 40, 1, rng);
                if (r == null || flag.get()) return;
                final String likely = Texts.describe(p1, r.bestMove).text;
                ui.post(() -> {
                    if (jobNow == job && hintMove == shown && !flag.get()) setStatus(hintStatus + "\nLikely reply: " + likely);
                });
                int count = Math.min(2, r.candidates.length);
                for (int i = 0; i < count && !flag.get(); i++) {
                    int reply = r.candidates[i];
                    Position p2 = Rules.apply(p1, reply);
                    if (Rules.outcome(p2, null, null) != null) continue;
                    Brain.Options o2 = base.copy();
                    int n = base.history == null ? 0 : base.history.length;
                    int[] h2 = new int[n + 2];
                    if (n > 0) System.arraycopy(base.history, 0, h2, 0, n);
                    h2[n] = shown;
                    h2[n + 1] = reply;
                    o2.history = h2;
                    Brain.Decision d2 = new Brain().decide(p2, mine, o2, new HashSet<>(failed), rng, flag);
                    if (d2 != null && !flag.get()) ponderCache.put(p2.key(), d2);
                }
            } catch (Throwable ignored) {
            }
        });
    }

    private void think() {
        cancelAll();
        final int myJob = job;
        final AtomicBoolean cancel = cancelFlag;
        final Position pos = tracker.pos;
        final boolean mine = myWhite;
        final Brain.Options o = new Brain.Options();
        o.unpredictable = unpredictable;
        o.withBrilliant = onlyBrilliant;
        o.counter = counter;
        int[] hist = new int[moveInts.size()];
        for (int i = 0; i < hist.length; i++) hist[i] = moveInts.get(i);
        o.history = hist;
        o.bestGambit = bestGambit;
        o.fastMate = fastMate;
        o.instant = thinkIdx == 0;
        o.thinkSeconds = THINK_SECONDS[thinkIdx];                 // no cap: think as long as you choose
        o.margin = MODE_MARGIN[modeIdx];
        o.noBlunder = noBlunder;
        o.safeMode = safeMode;
        o.maxStrength = maxStrength;
        if (maxStrength) {                                        // the real best move: a real think time, no varied picks
            o.instant = false;
            o.thinkSeconds = Math.max(Brain.MAX_STRENGTH_SECONDS, o.thinkSeconds);
        }
        Engine.agentsOn = agentOn && !agentName.isEmpty() && !maxStrength;   // Max strength: Stockfish gets the whole phone
        Engine.agentTolerance = (safeMode || noBlunder) ? 12 : 20;
        final Set<String> failed = new HashSet<>(failedGambits);
        final Random rng = new Random();
        final Brain.Decision cached = ponderCache.remove(pos.key());       // already worked out while you waited?
        if (cached == null) stopPonder(false);
        final double extraSecs = thinkIdx == 0 ? 0.25 : 0.6;
        engineExec.execute(() -> {
            Brain.Decision d = null;
            String problem = null;
            try {
                d = cached != null ? cached : new Brain().decide(pos, mine, o, failed, rng, cancel);
            } catch (Throwable t) {
                problem = String.valueOf(t);
            }
            final Brain.Decision dec = d;
            final String err = problem;
            int[] mw = null;                                  // the middle and the worst move, when asked for
            if (dec != null && (showMid || showWorst)) {
                try {
                    mw = new Engine(cancel).midAndWorst(pos, dec.move, extraSecs);
                } catch (Throwable ignored) {
                }
            }
            final int midMove = mw != null && showMid ? mw[0] : -1;
            final int worstMove = mw != null && showWorst ? mw[1] : -1;
            ui.post(() -> {
                if (myJob != job) return;                     // the position changed meanwhile
                failedGambits.addAll(failed);
                if (dec == null) {
                    setStatus(err != null ? "Could not think: " + err : "No move available.");
                    return;
                }
                hintMove = dec.move;
                pendFrom = dec.from;
                pendTo = dec.to;
                pendBrilliant = "brilliant".equals(dec.kind);
                pendMid = midMove;
                pendWorst = worstMove;
                String piece = Texts.pieceName(Character.toUpperCase(pos.b[dec.from]));
                String more = "";
                if (midMove >= 0) more += "  Yellow = mid move.";
                if (worstMove >= 0) more += "  Red = worst move.";
                Texts.Described ds = Texts.describe(pos, dec.move);
                String tags = ds.tags.isEmpty() ? "" : " (" + join(ds.tags) + ")";
                hintStatus = (dec.kind.equals("brilliant") ? "!! " : "") + "Move the " + piece + " as shown by the blue arrow.\n"
                        + ds.text + tags + "\n" + (cached != null ? "(ready in advance) " : "") + dec.note + "\n"
                        + evalText(dec.score, mine) + more + "\n" + engineLine(dec);
                showHint();
                startPonder(pos, dec.move, mine, o, failed);
                if (autoDoneIdx > 0) {                           // Automatic Done: place the move after N seconds
                    final int shown = hintMove;
                    ui.postDelayed(() -> {
                        if (myJob == job && hintMove == shown && shown >= 0) playMove(shown);
                    }, 1000L * autoDoneIdx);
                }
            });
        });
    }

    // ================================================================== the board
    private final class BoardView extends View {
        private final Paint p = new Paint(), t = new Paint();
        private final Path head = new Path();
        private int sel = -1;
        private int[] targets = new int[0];
        int hintFrom = -1, hintTo = -1;
        boolean brilliant;

        BoardView(Context c) {
            super(c);
            p.setAntiAlias(true);
            t.setAntiAlias(true);
            t.setTextAlign(Paint.Align.CENTER);
        }

        void clearSelection() {
            sel = -1;
            targets = new int[0];
            invalidate();
        }

        int midFrom = -1, midTo = -1, worstFrom = -1, worstTo = -1;

        void setHint(int from, int to) {
            hintFrom = from;
            hintTo = to;
            if (from < 0) {
                setExtras(-1, -1);
                brilliant = false;
            }
            invalidate();
        }

        void setBrilliant(boolean b) {
            brilliant = b;
            invalidate();
        }

        void setExtras(int mid, int worst) {
            midFrom = mid >= 0 ? Move.from(mid) : -1;
            midTo = mid >= 0 ? Move.to(mid) : -1;
            worstFrom = worst >= 0 ? Move.from(worst) : -1;
            worstTo = worst >= 0 ? Move.to(worst) : -1;
            invalidate();
        }

        private int squareAt(int r, int c) {
            return BoardGeometry.imgIndex(r * 8 + c, !myWhite);
        }

        private float cx(int sq, float cell) {
            int i = BoardGeometry.imgIndex(sq, !myWhite);          // the mapping is its own inverse
            return (i % 8) * cell + cell / 2f;
        }

        private float cy(int sq, float cell) {
            int i = BoardGeometry.imgIndex(sq, !myWhite);
            return (i / 8) * cell + cell / 2f;
        }

        @Override
        protected void onDraw(Canvas cv) {
            float cell = getWidth() / 8f;
            Position pos = tracker.pos;
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
                    int sq = squareAt(r, c);
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(((r + c) & 1) == 0 ? 0xFFEEEED2 : 0xFF769656);
                    cv.drawRect(c * cell, r * cell, (c + 1) * cell, (r + 1) * cell, p);
                    if (sq == sel) {
                        p.setColor(0xAAFFD400);
                        cv.drawRect(c * cell, r * cell, (c + 1) * cell, (r + 1) * cell, p);
                    }
                    char ch = pos.b[sq];
                    if (ch != '.') {
                        String g = Texts.glyph(Character.toUpperCase(ch));
                        t.setTextSize(cell * 0.82f);
                        float x = c * cell + cell / 2f, y = r * cell + cell * 0.76f;
                        boolean white = Rules.isWhite(ch);
                        t.setStyle(Paint.Style.STROKE);
                        t.setStrokeWidth(cell * 0.06f);
                        t.setColor(white ? 0xFF222222 : 0xFFFFFFFF);
                        cv.drawText(g, x, y, t);
                        t.setStyle(Paint.Style.FILL);
                        t.setColor(white ? 0xFFFFFFFF : 0xFF111111);
                        cv.drawText(g, x, y, t);
                    }
                    for (int tg : targets) {
                        if (tg == sq) {
                            p.setColor(0xCC00E000);
                            cv.drawCircle(c * cell + cell / 2f, r * cell + cell / 2f, cell * 0.17f, p);
                        }
                    }
                }
            }
            t.setStyle(Paint.Style.FILL);
            t.setTextSize(cell * 0.24f);
            t.setColor(0xFF33442A);
            for (int i = 0; i < 8; i++) {                                // a-h / 1-8 labels
                String file = String.valueOf((char) ('a' + (myWhite ? i : 7 - i)));
                String rank = String.valueOf(myWhite ? 8 - i : i + 1);
                cv.drawText(file, i * cell + cell * 0.82f, 8 * cell - cell * 0.06f, t);
                cv.drawText(rank, cell * 0.14f, i * cell + cell * 0.27f, t);
            }
            if (worstFrom >= 0) drawMove(cv, cell, worstFrom, worstTo, RED_FILL, RED, RED_ARROW);
            if (midFrom >= 0) drawMove(cv, cell, midFrom, midTo, YELLOW_FILL, YELLOW, YELLOW_ARROW);
            if (hintFrom >= 0 && hintTo >= 0) drawMove(cv, cell, hintFrom, hintTo, 0x552F8BFF, BLUE, 0xEE2F8BFF);
            if (brilliant && hintTo >= 0) {                              // the "!!" badge, like Chess.com's brilliant icon
                float bx = cx(hintTo, cell) + cell * 0.30f, by = cy(hintTo, cell) - cell * 0.30f;
                p.setStyle(Paint.Style.FILL);
                p.setColor(0xFF1BACA6);
                cv.drawCircle(bx, by, cell * 0.27f, p);
                t.setStyle(Paint.Style.FILL);
                t.setColor(Color.WHITE);
                t.setTextSize(cell * 0.34f);
                cv.drawText("!!", bx, by + cell * 0.12f, t);
            }
        }

        /** BLUE box on the piece and on the target square, and a BLUE arrow between them. */
        private void drawMove(Canvas cv, float cell, int from, int to, int fill, int line, int arrow) {
            float fx = cx(from, cell), fy = cy(from, cell);
            float tx = cx(to, cell), ty = cy(to, cell);
            float h = cell / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(fill);
            cv.drawRect(fx - h, fy - h, fx + h, fy + h, p);
            cv.drawRect(tx - h, ty - h, tx + h, ty + h, p);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(line);
            p.setStrokeWidth(cell * 0.07f);
            cv.drawRect(fx - h + cell * 0.04f, fy - h + cell * 0.04f, fx + h - cell * 0.04f, fy + h - cell * 0.04f, p);
            p.setStrokeWidth(cell * 0.13f);
            cv.drawRect(tx - h + cell * 0.07f, ty - h + cell * 0.07f, tx + h - cell * 0.07f, ty + h - cell * 0.07f, p);

            float dx = tx - fx, dy = ty - fy;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len < 1f) return;
            float ux = dx / len, uy = dy / len;
            float headLen = cell * 0.42f, headW = cell * 0.30f;
            float sx = fx + ux * cell * 0.30f, sy = fy + uy * cell * 0.30f;     // start just outside the piece
            float bx = tx - ux * (cell * 0.28f + headLen), by = ty - uy * (cell * 0.28f + headLen);
            float ex = tx - ux * cell * 0.28f, ey = ty - uy * cell * 0.28f;
            p.setColor(arrow);
            p.setStrokeWidth(cell * 0.16f);
            p.setStrokeCap(Paint.Cap.ROUND);
            cv.drawLine(sx, sy, bx, by, p);
            p.setStyle(Paint.Style.FILL);
            head.reset();
            head.moveTo(ex, ey);
            head.lineTo(bx - uy * headW, by + ux * headW);
            head.lineTo(bx + uy * headW, by - ux * headW);
            head.close();
            cv.drawPath(head, p);
            p.setStrokeCap(Paint.Cap.BUTT);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            float cell = getWidth() / 8f;
            int c = (int) (e.getX() / cell), r = (int) (e.getY() / cell);
            if (c < 0 || c > 7 || r < 0 || r > 7) return true;
            int sq = squareAt(r, c);
            Position pos = tracker.pos;
            for (int tg : targets) {
                if (tg == sq && sel >= 0) {
                    int from = sel;
                    clearSelection();
                    play(from, sq);
                    return true;
                }
            }
            char ch = pos.b[sq];
            if (ch != '.' && Rules.isWhite(ch) == pos.white) {
                sel = sq;
                List<Integer> list = new ArrayList<>();
                for (int m : Rules.legalMoves(pos)) {
                    if (Move.from(m) == sq && !list.contains(Move.to(m))) list.add(Move.to(m));
                }
                targets = new int[list.size()];
                for (int i = 0; i < targets.length; i++) targets[i] = list.get(i);
            } else {
                sel = -1;
                targets = new int[0];
            }
            invalidate();
            return true;
        }
    }

    // ================================================================== settings
    private void saveConfig() {
        try {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean("white", myWhite)
                    .putBoolean("t_unpred", unpredictable)
                    .putBoolean("t_brill", onlyBrilliant)
                    .putBoolean("t_gambit", bestGambit)
                    .putBoolean("t_mate", fastMate)
                    .putBoolean("t_worst", showWorst)
                    .putBoolean("t_mid", showMid)
                    .putBoolean("t_counter", counter)
                    .putBoolean("t_autosave", autoSave)
                    .putInt("autodone", autoDoneIdx)
                    .putInt("think5", thinkIdx)
                    .putInt("mode4", modeIdx)
                    .putInt("size4", sizeIdx)
                    .putBoolean("collapsed", featuresCollapsed)
                    .putString("shown6", shownString())
                    .putBoolean("t_max", maxStrength)
                    .putBoolean("t_safe", safeMode)
                    .putBoolean("t_noblunder", noBlunder)
                    .putBoolean("t_agent", agentOn)
                    .apply();
        } catch (Exception ignored) {
        }
    }

    /** Evaluation line from White's point of view (score is in centipawns from the mover's view). */
    private static String evalText(int score, boolean moverIsWhite) {
        if (score >= Engine.MATE - 200) return "Eval: forced mate for you";
        if (score <= -Engine.MATE + 200) return "Eval: you are getting mated";
        int w = moverIsWhite ? score : -score;
        String side = Math.abs(w) < 25 ? "equal" : (w > 0 ? "White better" : "Black better");
        return String.format(java.util.Locale.US, "Eval: %+.1f (%s)", w / 100.0, side);
    }

    private static String join(List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < l.size(); i++) {
            if (i > 0) sb.append(", ");
            sb.append(l.get(i));
        }
        return sb.toString();
    }

    private String shownString() {
        StringBuilder sb = new StringBuilder();
        for (boolean b : featureShown) sb.append(b ? '1' : '0');
        return sb.toString();
    }

    private void loadConfig() {
        java.util.Arrays.fill(featureShown, true);
        try {
            SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            myWhite = p.getBoolean("white", true);
            unpredictable = p.getBoolean("t_unpred", true);
            onlyBrilliant = p.getBoolean("t_brill", false);
            bestGambit = p.getBoolean("t_gambit", false);
            fastMate = p.getBoolean("t_mate", false);
            showWorst = p.getBoolean("t_worst", false);
            showMid = p.getBoolean("t_mid", false);
            counter = p.getBoolean("t_counter", false);
            autoSave = p.getBoolean("t_autosave", true);
            autoDoneIdx = Math.max(0, Math.min(AUTO_DONE_NAMES.length - 1, p.getInt("autodone", 0)));
            thinkIdx = Math.max(0, Math.min(THINK_SECONDS.length - 1, p.getInt("think5", 0)));
            modeIdx = Math.max(0, Math.min(MODE_LABELS.length - 1, p.getInt("mode4", 7)));
            featuresCollapsed = p.getBoolean("collapsed", false);
            String shown = p.getString("shown6", "");
            maxStrength = p.getBoolean("t_max", true);
            safeMode = p.getBoolean("t_safe", false);
            noBlunder = p.getBoolean("t_noblunder", true);
            agentOn = p.getBoolean("t_agent", true);
            for (int i = 0; i < FEATURE_KEYS.length; i++) featureShown[i] = i >= shown.length() || shown.charAt(i) != '0';
            sizeIdx = Math.max(0, Math.min(BOARD_DP.length - 1, p.getInt("size4", 0)));      // new setting name: everybody starts small
        } catch (Exception ignored) {
        }
    }
}
