# Chess Helper (Android)

A floating chess board. You tap the moves (yours and the opponent's) on it, and on your turn it shows the best
move on its own board with a BLUE box on the piece, a BLUE box on the target square and an ARROW.
It reads nothing from the screen (no screen capture). It has no internet permission, no accounts and no keys.

Window controls: Done (plays the shown move for you), Undo move, New game, Choose your mode (Bullet / Blitz
(Lightning) / Rapid / Daily), Think (Instant by default, 1-30 s, no cap), Automatic Done (Off, 1-5 s), Auto Save (the game
survives closing), Safe Mode (low risk: risky features off, No blunder on), No blunder (Risk) (every shown move is checked
against the best move), Unpredictable (the best move, but not always the same one: only practically equal moves, re-checked),
With Brilliant (!!) (a real piece sacrifice that Stockfish's top-10 list rates within 0.3 pawn of the best move; rare), Use best
Gambit/Trap (~420 book lines incl. 38 extra traps/gambits/tricks, move-checked), Counter Gambit/Trap (recognises a gambit/trap from the
opponent's moves), Fast Checkmate 100% (complete mate search; shown mates are always real; deep quiet mates can be
missed within the time limit), Engine Agent (a second engine gives a second opinion), Worst move (red box + arrow), Mid move (yellow box + arrow), My pieces, Board size.
The gear in the title bar hides/shows all feature buttons (long-press: choose which); the X asks "Are you sure to close?".

Pondering: while you wait, the engine predicts the opponent's likely replies (shown as "Likely reply") and prepares its
answers, so the next hint can be instant.

Engine: the real Stockfish 19 (built from the official source in the GitHub workflow, shipped as libstockfish.so,
run through UCI). Fallback when it cannot start: a built-in Java engine, iterative deepening with transposition table, null-move and late-move reductions, killer/history ordering,
repetition awareness and an evaluation with pawn structure, king shelter, mobility and endgame mop-up.

Engine Agent: second UCI engines run next to Stockfish (the main engine): Reckless and Triumviratus compare, PlentyChess and
ShashChess add analysis (the `allengines` APK has all four; the standard APK has Reckless). How many run at once depends on the phone's memory.
Max strength (on by default) shows only the engine's real best move and thinks at least 3 seconds; turn it off to use Unpredictable, Safe Mode, Brilliant, Gambit/Trap and Engine Agent. New game and My pieces ask before they clear the game.
The agents take a faster forced mate when one finds it and break near-ties; none overrules a clearly better move. The workflow builds Reckless for it (64-bit phones with the
dot-product instructions only; if that build fails the APK is simply made without it). To add your own engine: put an
Android build of it (a UCI program built for Android, not a .so library) in `engines/arm64/` or `engines/arm32/` in the
repository; the workflow packs it as `libeng_<name>.so` and the app uses it as the second engine. Programs that were
not built for Android will not start, and the app then goes on without them.

Two APKs, because 64-bit and 32-bit phones need different native engines: `ChessHelper-arm64.apk` (almost every phone since
2017, choose this if unsure) and `ChessHelper-arm32.apk` (older/low-end phones or 32-bit Android). The start screen says which
one is installed.

Build: upload the zip to a GitHub repo; the Actions workflow builds both APKs and publishes them under Releases.
Use for practice and games against the computer; most chess sites forbid engine help in games against people.

PC version (Windows): the `desktop/` folder holds the same helper as a normal window (Java Swing, the same engine core). The
workflow builds Stockfish for Windows, bundles a Java runtime and publishes `ChessHelper-Windows-portable.zip` (unzip, run
ChessHelper.exe) and, when it can be built, `ChessHelper-Setup.exe`. To add another engine on PC, drop its .exe into the
`engines` folder next to the program, named `agent_<name>.exe`. There is no iPhone/iPad version: iOS does not allow a floating
helper window or running an engine program like this.
