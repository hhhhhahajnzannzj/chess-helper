package com.chesshelper.overlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.content.SharedPreferences;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Start screen: allow "Display over other apps", then start the floating "Chess Helper" board.
 * Optional Gemini key for the "Use AI" switch. No screen capture.
 */
public class MainActivity extends Activity {
    private static final int REQ_NOTIF = 43;

    private TextView stepOverlay, info;
    private EditText keyField;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = dp(20);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF1F2430);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, dp(40), pad, pad);
        sv.addView(col);

        col.addView(text("♞  Chess Helper", 26, 0xFF00E000, true));
        col.addView(text("A floating chess board. You tap the moves on it, and it shows the best move with an "
                + "ARROW and a BLUE box.", 15, 0xFFE8E8E8, false), lp(dp(10)));

        stepOverlay = button("", v -> askOverlayPermission());
        col.addView(stepOverlay, lp(dp(22)));

        TextView start = button("▶  Start Chess Helper", v -> startHelper());
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF1B8A1B);
        g.setCornerRadius(dp(10));
        start.setBackground(g);
        col.addView(start, lp(dp(12)));

        col.addView(button("■  Stop", v -> {
            stopService(new Intent(MainActivity.this, OverlayService.class));
            refresh();
        }), lp(dp(12)));

        keyField = new EditText(this);
        keyField.setHint("Enter API key Gemini (or leave blank)");
        keyField.setHintTextColor(0xFF7F8799);
        keyField.setTextColor(Color.WHITE);
        keyField.setTextSize(14);
        keyField.setSingleLine(true);
        keyField.setPadding(dp(12), dp(12), dp(12), dp(12));
        GradientDrawable kg = new GradientDrawable();
        kg.setColor(0xFF2A3042);
        kg.setCornerRadius(dp(10));
        keyField.setBackground(kg);
        try {
            keyField.setText(getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE)
                    .getString(OverlayService.PREF_KEY, ""));
        } catch (Exception ignored) {
        }
        col.addView(keyField, lp(dp(22)));
        col.addView(button("Save Key", v -> saveKey()), lp(dp(8)));

        info = text("", 14, 0xFFC8CDD8, false);
        col.addView(info, lp(dp(16)));

        col.addView(text("How to use\n"
                + "1. Allow “Display over other apps”, then tap Start.\n"
                + "2. Open your chess game. The Chess Helper board floats on top; drag it by its title bar, "
                + "the dash shrinks it, “Board size” changes its size.\n"
                + "3. Check “My pieces” (White or Black) and tap every move on the helper board: first the piece, "
                + "then the square it goes to. Do it for your moves AND the opponent's.\n"
                + "4. On your turn the helper thinks and shows the move on its board: a BLUE box on the piece, a BLUE "
                + "box on the target square and an ARROW between them. Make that move in your game.\n\n"
                + "Switches\n"
                + "• Unpredictable: picks among very strong moves so you are hard to read (OFF = always the best).\n"
                + "• Only Brilliant: shows a move only when it is a real brilliant: a genuine piece sacrifice that is "
                + "still a sacrifice three moves later and that a deep search confirms is as good as the best move "
                + "(or forces mate). If there is none it says so and shows the best move.\n"
                + "• Use best Gambit/Trap: plays gambits and traps from a built-in book (about 380 lines). If one "
                + "is refuted, or the opponent leaves the book, it tries another that fits, otherwise it plays the "
                + "100% accurate move.\n"
                + "• Fast Checkmate 100%: a special mate finder (about 0.1 s) shows the fastest forced mate whenever there is one.\n"
                + "• Use AI: Gemini chooses among moves the engine approves (needs internet; your key first, then "
                + "the built-in keys, switching by itself when one is limited).\n"
                + "• Humanize: plays like a person: natural, slightly varied (never a blunder), and the move "
                + "appears after a short, changing pause. It makes play look more natural, but it cannot "
                + "guarantee anything: sites can still tell, so use it for bot and practice games.\n"
                + "• Choose your mode: Bullet, Blitz (Lightning), Rapid or Daily. Faster mode = faster thinking, "
                + "kept balanced.\n"
                + "• Think: Auto (follows the mode), Instant, or 1 to 8 seconds.\n\n"
                + "Done button: when a move is shown, tap Done and the helper plays it on its board for you, then "
                + "waits for the opponent's move.\n"
                + "Setting button (or the ⚙ in the title bar): show or hide any feature, or Show all / Hide all. ✕ asks “Are you sure to close?”.\n\n"
                + "It starts from the normal starting position, so turn it on at the beginning of the game. "
                + "Use it for practice and games against the computer; most chess sites forbid engine help in "
                + "games against people.\n\n"
                + "Xiaomi / MIUI / HyperOS: if the window does not appear or disappears, open Settings > Apps > "
                + "Chess Helper > Other permissions and allow “Display pop-up windows while running in the "
                + "background”; set Battery saver to “No restrictions” and turn Autostart on.",
                13, 0xFFAAB0C0, false), lp(dp(10)));
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        boolean ok = Settings.canDrawOverlays(this);
        stepOverlay.setText(ok ? "✔  Permission “Display over other apps” is ON"
                : "1.  Allow “Display over other apps”  (tap here)");
        stepOverlay.setTextColor(ok ? 0xFF00E000 : 0xFFFFFFFF);
        info.setText(OverlayService.running ? "The Chess Helper board is running. Switch to your chess game."
                : "Not running.");
    }

    private void saveKey() {
        String k = keyField.getText() == null ? "" : keyField.getText().toString().trim();
        try {
            getSharedPreferences(OverlayService.PREFS, MODE_PRIVATE).edit().putString(OverlayService.PREF_KEY, k).apply();
            info.setText(k.isEmpty() ? "Key cleared. The built-in keys will be used."
                    : "Key saved. It is used first; the built-in keys are the backup.");
        } catch (Exception e) {
            info.setText("Could not save the key.");
        }
    }

    private void askOverlayPermission() {
        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
    }

    private void startHelper() {
        if (!Settings.canDrawOverlays(this)) {
            info.setText("First allow “Display over other apps” (the button above).");
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        if (OverlayService.running) {
            info.setText("Already running. Switch to your chess game.");
            return;
        }
        startForegroundService(new Intent(this, OverlayService.class));
        info.setText("Chess Helper started. Now open your chess game.");
        moveTaskToBack(true);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_NOTIF) startHelper();      // continue even if denied: the window still works
    }

    // ---- small view helpers ----
    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams lp(int topMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = topMargin;
        return p;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private TextView button(String s, View.OnClickListener l) {
        TextView t = text(s, 16, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(16), dp(12), dp(16));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF323A4D);
        g.setCornerRadius(dp(10));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }
}
