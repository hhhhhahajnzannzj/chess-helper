# Chess Helper (Android)

A floating chess board. You tap the moves (yours and the opponent's) on it, and on your turn it shows the best
move on its own board with a BLUE box on the piece, a BLUE box on the target square and an ARROW.
It reads nothing from the screen (no screen capture). Internet is used only by the optional "Use AI" switch.

Window controls: Done (plays the shown move for you), Undo move, New game, Choose your mode (Bullet / Blitz
(Lightning) / Rapid / Daily), Think (Auto, Instant, 1-8 s), Unpredictable, Only Brilliant (strict: real, deeply verified piece sacrifice), Use best Gambit/Trap
(~380 book lines from Wikipedia's lists; falls back to another gambit, then 100% accurate play), Fast Checkmate 100% (dedicated mate finder, ~0.1 s),
Humanize (natural, varied, never a blunder, with a short changing pause), Use AI (Gemini picks among engine-approved moves), My pieces, Board size. The gear in the title bar shows/hides any
of these; the X asks "Are you sure to close?".

Start screen: "Enter API key Gemini (or leave blank)" + Save Key. Your key is tried first, then the built-in keys in
`core/DefaultKeys.java`; when one is rate-limited the next one is used. NOTE: keys committed to a public repo can be
read by anyone and may be revoked by Google - keep the repo private or replace the keys.

Build: upload the zip to a GitHub repo; the Actions workflow builds `ChessHelper.apk` and publishes it under Releases.
Use for practice and games against the computer; most chess sites forbid engine help in games against people.
