import SwiftUI

struct ContentView: View {
    @StateObject private var game = GameModel()
    @State private var confirmNew = false
    @State private var pendingSide: Bool? = nil
    @StateObject private var pip = PiPController()

    private func pushToFloatingBoard() {
        Task { @MainActor in
            pip.update(game.pipSnapshot())
        }
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 12) {
                Text("Chess Helper")
                    .font(.title2.bold())
                    .foregroundColor(.green)
                Text(game.status)
                    .font(.headline)
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: .infinity)
                if !game.detail.isEmpty {
                    Text(game.detail)
                        .font(.subheadline)
                        .foregroundColor(.secondary)
                }
                BoardView(game: game)
                    .padding(.horizontal, 4)

                Button(action: { game.done() }) {
                    Text("Done ✔  (place the move)")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 12)
                }
                .buttonStyle(.borderedProminent)
                .tint(.green)
                .disabled(game.hint == nil)

                HStack(spacing: 12) {
                    Button(action: { game.undo() }) {
                        Text("Undo move").frame(maxWidth: .infinity).padding(.vertical, 8)
                    }
                    .buttonStyle(.bordered)
                    Button(action: { confirmNew = true }) {
                        Text("New game").frame(maxWidth: .infinity).padding(.vertical, 8)
                    }
                    .buttonStyle(.bordered)
                }

                HStack(spacing: 12) {
                    PiPPreview(controller: pip)
                        .frame(width: 96, height: 112)
                        .cornerRadius(8)
                    VStack(alignment: .leading, spacing: 6) {
                        Button(action: { pip.toggle() }) {
                            Text(pip.isActive ? "Close floating board" : "Floating board (PiP)")
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 8)
                        }
                        .buttonStyle(.bordered)
                        .disabled(!pip.isAvailable)
                        Text(pip.message.isEmpty
                             ? "A small window with the board and the blue move that stays on top of other apps. It shows only; tap the moves here."
                             : pip.message)
                            .font(.footnote)
                            .foregroundColor(.secondary)
                    }
                }
                .padding(10)
                .background(Color.gray.opacity(0.15))
                .cornerRadius(10)

                VStack(spacing: 8) {
                    HStack {
                        Text("Think time")
                        Spacer()
                        Picker("Think time", selection: Binding(
                            get: { game.thinkIdx },
                            set: { game.setThink($0) }
                        )) {
                            ForEach(0..<thinkNames.count, id: \.self) { i in
                                Text(thinkNames[i]).tag(i)
                            }
                        }
                        .pickerStyle(.menu)
                    }
                    HStack {
                        Text("My pieces")
                        Spacer()
                        Picker("My pieces", selection: Binding(
                            get: { game.myWhite },
                            set: { pendingSide = $0 }
                        )) {
                            Text("White").tag(true)
                            Text("Black").tag(false)
                        }
                        .pickerStyle(.segmented)
                        .frame(maxWidth: 200)
                    }
                }
                .padding(10)
                .background(Color.gray.opacity(0.15))
                .cornerRadius(10)

                Text("Tap every move on this board: the opponent's and yours. On your turn the best move is shown with blue boxes and a blue arrow. Practice and bot games only: using an engine against people is cheating.")
                    .font(.footnote)
                    .foregroundColor(.secondary)
                    .multilineTextAlignment(.center)
            }
            .padding(12)
        }
        .task { await game.startEngine() }
        .onAppear {
            pip.prepare()
            pushToFloatingBoard()
        }
        .onReceive(game.objectWillChange) { _ in
            pushToFloatingBoard()
        }
        .alert("Are you sure to start a new game?", isPresented: $confirmNew) {
            Button("Yes", role: .destructive) { game.resetGame() }
            Button("No", role: .cancel) {}
        }
        .alert("Change your side? This starts a new game.", isPresented: Binding(
            get: { pendingSide != nil },
            set: { if !$0 { pendingSide = nil } }
        )) {
            Button("Yes", role: .destructive) {
                if let side = pendingSide { game.setSide(white: side) }
                pendingSide = nil
            }
            Button("No", role: .cancel) { pendingSide = nil }
        }
        .confirmationDialog(game.promotionTitle, isPresented: $game.askPromotion, titleVisibility: .visible) {
            Button("Queen") { game.choosePromotion("q") }
            Button("Rook") { game.choosePromotion("r") }
            Button("Bishop") { game.choosePromotion("b") }
            Button("Knight") { game.choosePromotion("n") }
        }
    }
}
