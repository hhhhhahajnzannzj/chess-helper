import AVFoundation
import AVKit
import CoreMedia
import CoreVideo
import SwiftUI
import UIKit

/// Everything the floating (Picture in Picture) board needs to draw one picture.
struct PiPSnapshot {
    var board: [Character]
    var myWhite: Bool
    var hintFrom: Int?
    var hintTo: Int?
    var caption: String
}

private let pipGlyphs: [Character: String] = [
    "k": "\u{265A}\u{FE0E}", "q": "\u{265B}\u{FE0E}", "r": "\u{265C}\u{FE0E}",
    "b": "\u{265D}\u{FE0E}", "n": "\u{265E}\u{FE0E}", "p": "\u{265F}\u{FE0E}"
]

/// A small view that holds the layer the pictures are shown on (it also shows a preview inside the app).
final class PiPLayerView: UIView {
    private let content: CALayer

    init(content: CALayer) {
        self.content = content
        super.init(frame: .zero)
        backgroundColor = .black
        layer.addSublayer(content)
    }

    required init?(coder: NSCoder) {
        fatalError("not used")
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        content.frame = bounds
    }
}

struct PiPPreview: UIViewRepresentable {
    let controller: PiPController

    func makeUIView(context: Context) -> PiPLayerView {
        return PiPLayerView(content: controller.displayLayer)
    }

    func updateUIView(_ uiView: PiPLayerView, context: Context) {}
}

/// Shows the board and the suggested move in a small floating Picture in Picture window that stays on top of other apps.
/// iOS only lets apps float a video window, so the board is drawn as pictures and fed to the system as video frames.
/// The window cannot take touches: tap the moves in the app, then look at the window while you play.
/// Everything here runs on the main thread.
final class PiPController: NSObject, ObservableObject, AVPictureInPictureControllerDelegate, AVPictureInPictureSampleBufferPlaybackDelegate {
    let displayLayer = AVSampleBufferDisplayLayer()

    @Published private(set) var isActive = false
    @Published private(set) var isAvailable = AVPictureInPictureController.isPictureInPictureSupported()
    @Published private(set) var message = ""

    private var pip: AVPictureInPictureController?
    private var timebase: CMTimebase?
    private var lastBuffer: CVPixelBuffer?
    private var lastSnapshot: PiPSnapshot?
    private var timer: Timer?
    private var prepared = false
    private let width = 360
    private let height = 420

    // MARK: setup

    func prepare() {
        if prepared { return }
        prepared = true
        guard AVPictureInPictureController.isPictureInPictureSupported() else {
            message = "Picture in Picture is not supported on this device."
            return
        }
        let session = AVAudioSession.sharedInstance()
        do {
            // No sound is played. Mixing keeps the sounds of the chess app you are playing in.
            try session.setCategory(.playback, mode: .moviePlayback, options: [.mixWithOthers])
            try session.setActive(true)
        } catch {
            message = "Audio setup failed: " + error.localizedDescription
        }
        displayLayer.videoGravity = .resizeAspect
        var tb: CMTimebase?
        CMTimebaseCreateWithSourceClock(allocator: kCFAllocatorDefault, sourceClock: CMClockGetHostTimeClock(), timebaseOut: &tb)
        if let base = tb {
            CMTimebaseSetTime(base, time: CMTime.zero)
            CMTimebaseSetRate(base, rate: 1.0)
            displayLayer.controlTimebase = base
            timebase = base
        }
        let source = AVPictureInPictureController.ContentSource(sampleBufferDisplayLayer: displayLayer, playbackDelegate: self)
        let controller = AVPictureInPictureController(contentSource: source)
        controller.delegate = self
        controller.canStartPictureInPictureAutomaticallyFromInline = true     // starts by itself when you leave the app
        pip = controller
        startTimer()
        if let snap = lastSnapshot { update(snap) }
    }

    /// The button: opens the floating board, or closes it when it is open.
    func toggle() {
        prepare()
        guard let controller = pip else { return }
        if controller.isPictureInPictureActive {
            controller.stopPictureInPicture()
            return
        }
        if lastBuffer == nil, let snap = lastSnapshot { update(snap) }
        if controller.isPictureInPicturePossible {
            message = ""
            controller.startPictureInPicture()
        } else {
            message = "Not ready yet. Check that Picture in Picture is on in Settings > General > Picture in Picture, then try again."
        }
    }

    // MARK: pictures

    func update(_ snapshot: PiPSnapshot) {
        lastSnapshot = snapshot
        guard prepared, let buffer = render(snapshot) else { return }
        lastBuffer = buffer
        enqueue(buffer)
    }

    private func startTimer() {
        timer?.invalidate()
        // The same picture is sent again twice a second so the system keeps treating the window as live.
        let t = Timer(timeInterval: 0.5, repeats: true) { [weak self] _ in
            self?.tick()
        }
        RunLoop.main.add(t, forMode: .common)
        timer = t
    }

    private func tick() {
        if let buffer = lastBuffer { enqueue(buffer) }
    }

    private func enqueue(_ buffer: CVPixelBuffer) {
        var format: CMVideoFormatDescription?
        let made = CMVideoFormatDescriptionCreateForImageBuffer(allocator: kCFAllocatorDefault, imageBuffer: buffer, formatDescriptionOut: &format)
        guard made == noErr, let description = format else { return }
        var now = CMClockGetTime(CMClockGetHostTimeClock())
        if let base = timebase { now = CMTimebaseGetTime(base) }
        var timing = CMSampleTimingInfo(duration: CMTime.invalid, presentationTimeStamp: now, decodeTimeStamp: CMTime.invalid)
        var sample: CMSampleBuffer?
        let created = CMSampleBufferCreateReadyWithImageBuffer(allocator: kCFAllocatorDefault, imageBuffer: buffer,
                                                               formatDescription: description, sampleTiming: &timing,
                                                               sampleBufferOut: &sample)
        guard created == noErr, let sampleBuffer = sample else { return }
        if let attachments = CMSampleBufferGetSampleAttachmentsArray(sampleBuffer, createIfNecessary: true), CFArrayGetCount(attachments) > 0 {
            let dict = unsafeBitCast(CFArrayGetValueAtIndex(attachments, 0), to: CFMutableDictionary.self)
            CFDictionarySetValue(dict,
                                 Unmanaged.passUnretained(kCMSampleAttachmentKey_DisplayImmediately).toOpaque(),
                                 Unmanaged.passUnretained(kCFBooleanTrue).toOpaque())
        }
        if displayLayer.status == .failed { displayLayer.flush() }
        displayLayer.enqueue(sampleBuffer)
    }

    private func render(_ s: PiPSnapshot) -> CVPixelBuffer? {
        var created: CVPixelBuffer?
        let attributes: [String: Any] = [
            kCVPixelBufferCGImageCompatibilityKey as String: true,
            kCVPixelBufferCGBitmapContextCompatibilityKey as String: true,
            kCVPixelBufferIOSurfacePropertiesKey as String: [String: Any]()
        ]
        let status = CVPixelBufferCreate(kCFAllocatorDefault, width, height, kCVPixelFormatType_32BGRA, attributes as CFDictionary, &created)
        guard status == kCVReturnSuccess, let buffer = created else { return nil }
        CVPixelBufferLockBaseAddress(buffer, [])
        defer { CVPixelBufferUnlockBaseAddress(buffer, []) }
        guard let base = CVPixelBufferGetBaseAddress(buffer) else { return nil }
        let space = CGColorSpaceCreateDeviceRGB()
        let info = CGImageAlphaInfo.premultipliedFirst.rawValue | CGBitmapInfo.byteOrder32Little.rawValue
        guard let ctx = CGContext(data: base, width: width, height: height, bitsPerComponent: 8,
                                  bytesPerRow: CVPixelBufferGetBytesPerRow(buffer), space: space, bitmapInfo: info) else { return nil }
        ctx.translateBy(x: 0, y: CGFloat(height))      // so the drawing below can use "top left is 0,0"
        ctx.scaleBy(x: 1, y: -1)
        UIGraphicsPushContext(ctx)
        draw(s, in: ctx)
        UIGraphicsPopContext()
        return buffer
    }

    private func draw(_ s: PiPSnapshot, in ctx: CGContext) {
        let side = CGFloat(width)
        let cell = side / 8
        let light = UIColor(red: 0.93, green: 0.93, blue: 0.82, alpha: 1)
        let dark = UIColor(red: 0.46, green: 0.59, blue: 0.34, alpha: 1)
        let blue = UIColor(red: 0.18, green: 0.55, blue: 1.0, alpha: 1)

        UIColor(red: 0.08, green: 0.08, blue: 0.08, alpha: 1).setFill()
        ctx.fill(CGRect(x: 0, y: 0, width: CGFloat(width), height: CGFloat(height)))

        for row in 0..<8 {
            for col in 0..<8 {
                let isDark = (row + col) % 2 == 1
                (isDark ? dark : light).setFill()
                ctx.fill(CGRect(x: CGFloat(col) * cell, y: CGFloat(row) * cell, width: cell, height: cell))
            }
        }

        let font = UIFont.systemFont(ofSize: cell * 0.82)
        for row in 0..<8 {
            for col in 0..<8 {
                let sq = s.myWhite ? (7 - row) * 8 + col : row * 8 + (7 - col)
                if sq < 0 || sq >= s.board.count { continue }
                let piece = s.board[sq]
                if piece == "." { continue }
                let lower = piece.lowercased()
                guard let key = lower.first, let glyph = pipGlyphs[key] else { continue }
                let white = piece.isUppercase
                let attributes: [NSAttributedString.Key: Any] = [
                    .font: font,
                    .foregroundColor: white ? UIColor.white : UIColor.black,
                    .strokeColor: white ? UIColor.black : UIColor.white,
                    .strokeWidth: -2.5
                ]
                let text = NSAttributedString(string: glyph, attributes: attributes)
                let size = text.size()
                text.draw(at: CGPoint(x: CGFloat(col) * cell + (cell - size.width) / 2,
                                      y: CGFloat(row) * cell + (cell - size.height) / 2))
            }
        }

        if let from = s.hintFrom, let to = s.hintTo {
            let a = centre(of: from, cell: cell, white: s.myWhite)
            let b = centre(of: to, cell: cell, white: s.myWhite)
            ctx.setStrokeColor(blue.cgColor)
            ctx.setLineWidth(5)
            ctx.stroke(CGRect(x: a.x - cell / 2 + 3, y: a.y - cell / 2 + 3, width: cell - 6, height: cell - 6))
            ctx.stroke(CGRect(x: b.x - cell / 2 + 3, y: b.y - cell / 2 + 3, width: cell - 6, height: cell - 6))
            ctx.setFillColor(blue.withAlphaComponent(0.9).cgColor)
            addArrow(to: ctx, from: a, to: b, cell: cell)
            ctx.fillPath()
        }

        let style = NSMutableParagraphStyle()
        style.alignment = .center
        let captionAttributes: [NSAttributedString.Key: Any] = [
            .font: UIFont.boldSystemFont(ofSize: 28),
            .foregroundColor: UIColor.white,
            .paragraphStyle: style
        ]
        let rect = CGRect(x: 8, y: side + 14, width: CGFloat(width) - 16, height: CGFloat(height) - side - 20)
        (s.caption as NSString).draw(in: rect, withAttributes: captionAttributes)
    }

    private func centre(of sq: Int, cell: CGFloat, white: Bool) -> CGPoint {
        let file = sq % 8
        let rank = sq / 8
        let col = white ? file : 7 - file
        let row = white ? 7 - rank : rank
        return CGPoint(x: (CGFloat(col) + 0.5) * cell, y: (CGFloat(row) + 0.5) * cell)
    }

    /// The same arrow as the one on the app's board.
    private func addArrow(to ctx: CGContext, from: CGPoint, to: CGPoint, cell: CGFloat) {
        let dx: CGFloat = to.x - from.x
        let dy: CGFloat = to.y - from.y
        let length: CGFloat = max(1, (dx * dx + dy * dy).squareRoot())
        let ux: CGFloat = dx / length
        let uy: CGFloat = dy / length
        let nx: CGFloat = -uy
        let ny: CGFloat = ux
        let shaft: CGFloat = cell * 0.09
        let headLength: CGFloat = cell * 0.38
        let headHalf: CGFloat = cell * 0.24
        let start = CGPoint(x: from.x + ux * cell * 0.3, y: from.y + uy * cell * 0.3)
        let tip = CGPoint(x: to.x - ux * cell * 0.12, y: to.y - uy * cell * 0.12)
        let baseX: CGFloat = tip.x - ux * headLength
        let baseY: CGFloat = tip.y - uy * headLength
        ctx.beginPath()
        ctx.move(to: CGPoint(x: start.x + nx * shaft, y: start.y + ny * shaft))
        ctx.addLine(to: CGPoint(x: baseX + nx * shaft, y: baseY + ny * shaft))
        ctx.addLine(to: CGPoint(x: baseX + nx * headHalf, y: baseY + ny * headHalf))
        ctx.addLine(to: tip)
        ctx.addLine(to: CGPoint(x: baseX - nx * headHalf, y: baseY - ny * headHalf))
        ctx.addLine(to: CGPoint(x: baseX - nx * shaft, y: baseY - ny * shaft))
        ctx.addLine(to: CGPoint(x: start.x - nx * shaft, y: start.y - ny * shaft))
        ctx.closePath()
    }

    // MARK: AVPictureInPictureControllerDelegate

    func pictureInPictureControllerDidStartPictureInPicture(_ pictureInPictureController: AVPictureInPictureController) {
        isActive = true
        message = ""
    }

    func pictureInPictureControllerDidStopPictureInPicture(_ pictureInPictureController: AVPictureInPictureController) {
        isActive = false
    }

    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController,
                                    failedToStartPictureInPictureWithError error: Error) {
        isActive = false
        message = "The floating board could not start: " + error.localizedDescription
    }

    // MARK: AVPictureInPictureSampleBufferPlaybackDelegate (the board is always "playing")

    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController, setPlaying playing: Bool) {}

    func pictureInPictureControllerTimeRangeForPlayback(_ pictureInPictureController: AVPictureInPictureController) -> CMTimeRange {
        return CMTimeRange(start: CMTime.zero, duration: CMTime.positiveInfinity)
    }

    func pictureInPictureControllerIsPlaybackPaused(_ pictureInPictureController: AVPictureInPictureController) -> Bool {
        return false
    }

    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController,
                                    didTransitionToRenderSize newRenderSize: CMVideoDimensions) {}

    func pictureInPictureController(_ pictureInPictureController: AVPictureInPictureController,
                                    skipByInterval skipInterval: CMTime,
                                    completion completionHandler: @escaping () -> Void) {
        completionHandler()
    }
}
