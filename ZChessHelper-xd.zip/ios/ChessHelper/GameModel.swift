import Foundation
import SwiftUI

let thinkNames = ["Instant", "1 s", "2 s", "3 s", "5 s", "8 s", "15 s", "30 s"]
let thinkMillis = [150, 1000, 2000, 3000, 5000, 8000, 15000, 30000]

@MainActor
final class GameModel: ObservableObject {
    @Published var position = Position.start()
    @Published var selected: Int? = nil
    @Published var hint: Move? = nil
    @Published var status = "Starting the engine…"
    @Published var detail = ""
    @Published var myWhite = true
    @Published var thinkIdx = 3
    @Published var askPromotion = false
    @Published var promotionTitle = "Promote to"
    @Published var gameOver = false

    private var history: [Position] = []
    private var keys: [String] = [Position.start().key]
    private var pendingPromotion: [Move] = []
    private let engine = StockfishService()
    private var job = 0
    private var thinkTask: Task<Void, Never>? = nil
    private var engineReady = false
    private let defaults = UserDefaults.standard

    init() {
        if defaults.object(forKey: "think") != nil {
            thinkIdx = max(0, min(thinkNames.count - 1, defaults.integer(forKey: "think")))
        }
        if defaults.object(forKey: "white") != nil {
            myWhite = defaults.bool(forKey: "white")
        }
    }

    // MARK: engine

    func startEngine() async {
        let ok = await engine.start()
        engineReady = ok
        if ok {
            afterMove()
        } else {
            status = "The engine could not start on this device."
        }
    }

    // MARK: floating board (Picture in Picture)

    /// What the floating board shows: the position, the blue move and one short line of text.
    func pipSnapshot() -> PiPSnapshot {
        var caption = "Chess Helper"
        if let m = hint {
            caption = Chess.pieceName(position.b[m.from]) + " " + Chess.name(m.from) + " to " + Chess.name(m.to)
            if let promo = m.promo { caption += " = " + Chess.pieceName(promo) }
        } else if gameOver {
            caption = status
        } else if position.whiteToMove != myWhite {
            caption = "Opponent's turn"
        } else if engineReady {
            caption = "Thinking…"
        }
        return PiPSnapshot(board: position.b, myWhite: myWhite, hintFrom: hint?.from, hintTo: hint?.to, caption: caption)
    }

    // MARK: settings

    func setThink(_ index: Int) {
        thinkIdx = index
        defaults.set(index, forKey: "think")
        rethink()
    }

    func setSide(white: Bool) {
        myWhite = white
        defaults.set(white, forKey: "white")
        resetGame()
    }

    private func rethink() {
        if !gameOver && engineReady && position.whiteToMove == myWhite { think() }
    }

    // MARK: tapping

    var legal: [Move] { position.legalMoves() }

    var targets: [Int] {
        guard let from = selected else { return [] }
        return legal.filter { $0.from == from }.map { $0.to }
    }

    func tap(_ sq: Int) {
        if gameOver { return }
        if let from = selected {
            let options = legal.filter { $0.from == from && $0.to == sq }
            if !options.isEmpty {
                selected = nil
                if options.count == 1 {
                    play(options[0])
                } else {
                    pendingPromotion = options
                    let enemy = position.whiteToMove != myWhite
                    promotionTitle = enemy ? "The enemy pawn reached your side. What did it become?" : "Promote your pawn to:"
                    askPromotion = true
                }
                return
            }
            selected = nil
        }
        let p = position.b[sq]
        if p != "." && p.isUppercase == position.whiteToMove { selected = sq }
    }

    func choosePromotion(_ piece: Character) {
        if let m = pendingPromotion.first(where: { $0.promo == piece }) { play(m) }
        pendingPromotion = []
    }

    // MARK: moves

    private func play(_ m: Move) {
        history.append(position)
        position = position.applying(m)
        keys.append(position.key)
        hint = nil
        detail = ""
        afterMove()
    }

    func done() {
        guard let m = hint else { return }
        play(m)
    }

    func undo() {
        guard let previous = history.popLast() else { return }
        keys.removeLast()
        position = previous
        selected = nil
        hint = nil
        detail = ""
        cancelThinking()
        afterMove()
    }

    func resetGame() {
        cancelThinking()
        history = []
        position = Position.start()
        keys = [position.key]
        selected = nil
        hint = nil
        detail = ""
        gameOver = false
        Task { await engine.newGame() }
        afterMove()
    }

    private func afterMove() {
        selected = nil
        if let end = position.outcome(keys: keys) {
            gameOver = true
            status = end
            return
        }
        gameOver = false
        if position.whiteToMove != myWhite {
            status = "Opponent's turn. Tap the piece they moved, then its new square."
            return
        }
        if engineReady { think() } else { status = "Starting the engine…" }
    }

    // MARK: thinking

    private func cancelThinking() {
        job += 1
        thinkTask?.cancel()
        Task { await engine.stopSearch() }
    }

    private func think() {
        job += 1
        let myJob = job
        let pos = position
        let ms = thinkMillis[thinkIdx]
        status = "Your turn - thinking…"
        hint = nil
        thinkTask?.cancel()
        thinkTask = Task {
            let lines = await engine.search(fen: pos.fen, movetimeMs: ms, multipv: 1)
            if Task.isCancelled || myJob != self.job { return }
            guard let best = lines.first, let move = pos.move(fromUCI: best.move) else {
                self.status = "The engine gave no move. Try Undo or New game."
                return
            }
            self.show(move: move, line: best, in: pos)
        }
    }

    private func show(move: Move, line: EngineLine, in pos: Position) {
        hint = move
        let piece = Chess.pieceName(pos.b[move.from])
        var text = "Move the " + piece + " from " + Chess.name(move.from) + " to " + Chess.name(move.to) + " (blue arrow)."
        if let promo = move.promo { text += " Promote to " + Chess.pieceName(promo) + "." }
        status = text
        detail = evalText(line.score) + "  (depth " + String(line.depth) + ")"
    }

    private func evalText(_ score: Int) -> String {
        if score >= 29000 { return "Forced mate for you in " + String(30000 - score) }
        if score <= -29000 { return "You are getting mated in " + String(score + 30000) }
        let white = myWhite ? score : -score
        let value = Double(white) / 100.0
        let sign = value >= 0 ? "+" : ""
        return "Evaluation " + sign + String(format: "%.2f", value) + " (for White)"
    }
}
