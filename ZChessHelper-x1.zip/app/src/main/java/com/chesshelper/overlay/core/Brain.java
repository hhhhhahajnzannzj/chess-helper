package com.chesshelper.overlay.core;

import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/** Chooses the move to show, according to the switches. */
public final class Brain {
    public static final class Options {
        public boolean unpredictable = true;
        public boolean withBrilliant;       // "With Brilliant": play a real brilliant (!!) move whenever there is one
        public boolean counter;             // "Counter Gambit/Trap": spot the opponent's gambit or trap and answer it
        public int[] history;               // the moves played so far in this game (needed by "counter")
        public boolean bestGambit;          // "Use best Gambit/Trap"
        public boolean fastMate;            // "Fast Checkmate 100%"
        public boolean instant;             // "Instant" thinking
        public double thinkSeconds = 2;
        public int margin = 45;             // the most (centipawns) a varied move may be worse than the best
        public boolean noBlunder;           // "No blunder (Risk)": every pick is checked against the best move
        public boolean safeMode;            // "Safe Mode": low risk, the risky features are switched off

        public Options copy() {
            Options c = new Options();
            c.unpredictable = unpredictable;
            c.withBrilliant = withBrilliant;
            c.counter = counter;
            c.history = history;
            c.bestGambit = bestGambit;
            c.fastMate = fastMate;
            c.instant = instant;
            c.thinkSeconds = thinkSeconds;
            c.margin = margin;
            c.noBlunder = noBlunder;
            c.safeMode = safeMode;
            return c;
        }

        /** What really runs: Safe Mode turns the risky features off and No blunder on. */
        public Options effective() {
            if (!safeMode) return this;
            Options e = copy();
            e.unpredictable = false;
            e.withBrilliant = false;
            e.bestGambit = false;
            e.noBlunder = true;
            return e;
        }
    }

    public static final class Decision {
        public int move;
        public int from, to;
        public int score;               // centipawns, mover's view
        public String kind;             // "best", "varied", "brilliant", "gambit", "accurate", "mate", "counter", "safe"
        public String note;             // one line for the person
        public Engine.Result result;
    }

    private static final int MAX_BOOK_TRIES = 12;

    private final Gambits.Line[] book;

    public Brain() {
        this(Gambits.BOOK);
    }

    public Brain(Gambits.Line[] book) {
        this.book = book;
    }

    /**
     * How far from the best move (centipawns) Unpredictable may stray. The idea is "the best move, but not always
     * the same one": only moves the engine rates practically equal are allowed, and the more there is to lose
     * (winning or losing position) the less it strays.
     */
    static int tolerance(int best, int fullMove, boolean instant, boolean noBlunder, int modeMargin) {
        int a = Math.abs(best);
        int t;
        if (a >= 600) t = 6;                    // clearly winning or losing: just the best move
        else if (best >= 250) t = 12;           // better: keep it
        else if (best <= -250) t = 8;           // worse: be exact
        else if (fullMove <= 10) t = 28;        // opening: many moves are equal
        else t = 18;
        t = Math.min(t, Math.max(0, modeMargin));
        if (instant) t = Math.min(t, 10);
        if (noBlunder) t = Math.min(t, 12);
        return t;
    }

    /** Picks among the near-best candidates: the best one most of the time, a close second now and then. */
    static int pickVaried(int[] cand, int[] scores, int tol, Random rng) {
        if (cand.length < 2 || tol <= 0) return 0;
        int best = scores[0];
        if (best >= Engine.MATE - 200 || best <= -Engine.MATE + 200) return 0;
        double[] w = new double[cand.length];
        double total = 0;
        double scale = tol / 2.5 + 1;
        for (int i = 0; i < cand.length; i++) {
            if (scores[i] < best - tol) {
                w[i] = 0;
                continue;
            }
            w[i] = Math.exp(-(best - scores[i]) / scale);
            total += w[i];
        }
        double x = rng.nextDouble() * total;
        for (int i = 0; i < cand.length; i++) {
            x -= w[i];
            if (w[i] > 0 && x <= 0) return i;
        }
        return 0;
    }

    /**
     * @param failed keys of gambits/traps that already failed in this game; this method adds to it
     * @return null when there is no legal move
     */
    public Decision decide(Position pos, boolean myWhite, Options opt, Set<String> failed, Random rng,
                           AtomicBoolean cancel) {
        final Options o = opt.effective();
        final boolean safe = opt.safeMode;
        final String tag = safe ? "Safe Mode: " : "";
        Engine eng = new Engine(cancel);
        if (o.instant) eng.setTableBits(16);
        double secs = o.instant ? 0.15 : Math.max(0.3, o.thinkSeconds);  // Instant: a sixth of a second (pondering often makes it zero)
        int depth = o.instant ? 8 : 40;                                   // the clock decides how deep it gets
        setHistory(eng, pos, o);
        boolean accurateOnly = !o.unpredictable;
        boolean varied = !accurateOnly;

        // ---- 1. Fast Checkmate 100%: a complete mate solver; a forced mate always wins over everything else
        if (o.fastMate) {
            int[] fm = eng.findMate(pos, o.instant ? 3 : 4, 6, o.instant ? 0.35 : 1.2, varied ? rng : null);
            if (fm != null) {
                return make(pos, fm[0], Engine.MATE - (2 * fm[1] - 1), "mate", "Fast checkmate: forced mate in "
                        + fm[1] + (fm[1] == 1 ? " move!" : " moves!"), null);
            }
        }

        // ---- 2. Counter Gambit/Trap: recognise what the opponent is doing, then play the 100% accurate answer
        String counterNote = null;
        if (o.counter && o.history != null) {
            Gambits.Detected det = Gambits.detectOpponent(o.history, myWhite, book);
            if (det != null) {
                counterNote = "Counter: the opponent's moves match " + det.names + (det.trap ? " (a possible trap)" : " (a possible gambit)")
                        + ". Playing the 100% accurate answer";
                accurateOnly = true;
                varied = false;
                secs = Math.max(secs, o.instant ? 0.3 : 1.0);
                depth = Math.max(depth, 6);
            }
        }

        // ---- normal search. The search lists the candidates; the choice among them is made below.
        int searchMargin = varied ? Math.max(o.margin, 30) : (o.noBlunder ? 80 : 0);
        Engine.Result r = eng.search(pos, depth, secs, searchMargin, 1, rng);
        if (r == null) return null;
        final double verifySecs = o.instant ? 0.12 : Math.min(1.5, Math.max(0.3, secs * 0.4));
        final int vdepth = Math.max(4, r.depth);                         // used by the built-in engine; Stockfish goes by time

        // ---- 3. gambit / trap book
        String bookNote = null;
        if (o.bestGambit && counterNote == null) {
            List<Gambits.Pick> picks = Gambits.matches(pos, myWhite, failed, book);
            if (varied) Collections.shuffle(picks, rng);
            int tries = 0;
            double check = Math.min(1.5, Math.max(0.25, secs));
            int allowed = o.noBlunder ? 70 : 200;                        // how much worse than the best a gambit may be rated
            int floor = o.noBlunder ? -80 : -250;
            for (Gambits.Pick pk : picks) {
                if (tries++ >= MAX_BOOK_TRIES) break;
                int s = pk.move == r.bestMove ? r.bestScore : eng.scoreMove(pos, pk.move, Math.max(4, r.depth), check);
                boolean sound = s != Integer.MIN_VALUE && s >= r.bestScore - allowed && s >= floor;
                if (sound) {
                    return make(pos, pk.move, s, "gambit",
                            pk.line.name + (pk.line.isTrap() ? " (trap, book move)" : " (gambit, book move)"), r);
                }
                if (failed != null) failed.add(pk.line.key());          // refuted: try the next one
                bookNote = pk.line.name + " failed";
            }
            if (bookNote != null) bookNote += "; playing the 100% accurate move";
            else bookNote = "No gambit or trap fits here; playing the 100% accurate move";
            if (varied) {                                                // be fully accurate, no varied pick
                varied = false;
                accurateOnly = true;
            }
        }

        // ---- 4. With Brilliant
        if (o.withBrilliant) {
            double bt = o.instant ? 0.35 : Math.min(6.0, Math.max(1.5, secs * 2));
            int b = eng.findBrilliant(pos, r, rng, varied, bt, o.noBlunder ? 15 : 30);
            if (b >= 0) {
                int s = b == r.bestMove ? r.bestScore : eng.scoreMove(pos, b, Math.max(4, r.depth), 0.5);
                if (s == Integer.MIN_VALUE) s = r.bestScore;
                Decision d = make(pos, b, s, "brilliant", (counterNote == null ? "" : counterNote + ". ")
                        + "Brilliant move (!!): a real piece sacrifice, checked deeply", r);
                return o.noBlunder ? guard(eng, pos, d, r, 30, vdepth, verifySecs) : d;
            }
            bookNote = (bookNote == null ? "" : bookNote + ". ") + "No real brilliant move here";
        }

        // ---- 5. the choice itself: the best move; Unpredictable may take a practically equal one
        int move = r.bestMove;
        int score = r.bestScore;
        String kind = "best";
        String note = "The best move";
        boolean mate = r.bestScore >= Engine.MATE - 200;
        if (r.avoidedRepeat) {
            move = r.move;
            score = r.score;
            note = "Repetition avoided: you are better, so it plays on for the win";
        } else if (mate) {
            kind = "mate";
            note = "Forced mate!";
        } else {
            if (o.noBlunder) {                                         // a quick second look at the best move itself
                Engine.Result fixed = recheckBest(eng, pos, r, vdepth, verifySecs);
                if (fixed != null) {
                    move = fixed.bestMove;
                    score = fixed.bestScore;
                    r = fixed;
                    note = "No blunder: the first choice looked risky, so a safer move was taken";
                }
            }
            if (varied && r.candidates != null && r.candidates.length > 1 && move == r.candidates[0]) {
                int tol = tolerance(r.candidateScores[0], pos.full, o.instant, o.noBlunder, o.margin);
                int ci = pickVaried(r.candidates, r.candidateScores, tol, rng);
                if (ci != 0) {
                    int pick = r.candidates[ci];
                    // the pick must still look as good as the best move in a second, fair comparison
                    boolean ok = true;
                    if (!o.instant || o.noBlunder) {
                        int sp = eng.scoreMove(pos, pick, vdepth, verifySecs);
                        int sb = eng.scoreMove(pos, r.candidates[0], vdepth, verifySecs);
                        ok = sp != Integer.MIN_VALUE && sb != Integer.MIN_VALUE && sp >= sb - tol;
                        if (ok) score = sp;
                    } else {
                        score = r.candidateScores[ci];
                    }
                    if (ok) {
                        move = pick;
                        kind = "varied";
                        note = "A different move, but practically as good as the best (within " + tol + " cp)";
                    }
                }
                if (kind.equals("best")) note = "The best move";
            }
        }
        if (safe) {
            kind = kind.equals("best") ? "safe" : kind;
            note = tag + note;
        }
        Decision d = make(pos, move, score, kind, note, r);
        if (counterNote != null) {
            d.kind = "counter";
            bookNote = bookNote == null ? counterNote : counterNote + ". " + bookNote;
        }
        if (bookNote != null) {
            d.note = bookNote + (bookNote.endsWith(".") ? "" : ".") + (d.note.equals("The best move") ? "" : " " + d.note);
            if (bookNote.contains("100% accurate") && !d.kind.equals("counter")) d.kind = "accurate";
        }
        return d;
    }

    /**
     * No blunder: the chosen special move (gambit, brilliant, ...) must be rated about as well as the engine's
     * best move in a fair comparison, otherwise the best move is shown instead.
     */
    private Decision guard(Engine eng, Position pos, Decision d, Engine.Result r, int allowed, int depth,
                           double secs) {
        if (d.move == r.bestMove || d.kind.equals("mate")) return d;
        int s = eng.scoreMove(pos, d.move, depth, secs);
        int sb = eng.scoreMove(pos, r.bestMove, depth, secs);
        boolean ok = s != Integer.MIN_VALUE && sb != Integer.MIN_VALUE && (s >= Engine.MATE - 200 || s >= sb - allowed);
        if (ok) return d;
        Decision safe = make(pos, r.bestMove, r.bestScore, "accurate",
                "No blunder: the special move did not hold up, so here is the best move", r);
        return safe;
    }

    /**
     * Looks at the best move once more (a fresh, focused search of only that move). If it now drops a lot, the
     * runner-up is checked the same way and used when it is clearly better.
     *
     * @return a result whose bestMove/bestScore are the safer move, or null when the best move stands
     */
    private Engine.Result recheckBest(Engine eng, Position pos, Engine.Result r, int depth, double secs) {
        if (r.candidates == null || r.candidates.length < 2) return null;
        int s1 = eng.scoreMove(pos, r.bestMove, depth, secs);
        if (s1 == Integer.MIN_VALUE || s1 >= r.bestScore - 120) return null;
        int alt = r.candidates[1];
        int s2 = eng.scoreMove(pos, alt, depth, secs);
        if (s2 == Integer.MIN_VALUE || s2 <= s1 + 30) return null;
        Engine.Result n = new Engine.Result();
        n.move = alt;
        n.bestMove = alt;
        n.score = s2;
        n.bestScore = s2;
        n.depth = r.depth;
        n.alternatives = new int[]{r.bestMove};
        n.candidates = new int[]{alt};
        n.candidateScores = new int[]{s2};
        return n;
    }

    /** Lets the engine know the positions already played, so it avoids (or takes) repetitions. */
    private static void setHistory(Engine eng, Position pos, Options o) {
        if (o.history == null || o.history.length == 0) return;
        try {
            Position p = Position.fromFen(Rules.START_FEN);
            long[] hs = new long[o.history.length];
            for (int i = 0; i < o.history.length; i++) {
                hs[i] = Engine.hash(p);
                p = Rules.apply(p, o.history[i]);
            }
            if (Engine.hash(p) == Engine.hash(pos)) eng.setGameHistory(hs);     // only when it is really this game
        } catch (RuntimeException ignored) {
        }
    }

    private static Decision make(Position pos, int move, int score, String kind, String note, Engine.Result r) {
        Decision d = new Decision();
        d.move = move;
        d.from = Move.from(move);
        d.to = Move.to(move);
        d.score = score;
        d.kind = kind;
        d.note = note;
        d.result = r;
        return d;
    }
}
