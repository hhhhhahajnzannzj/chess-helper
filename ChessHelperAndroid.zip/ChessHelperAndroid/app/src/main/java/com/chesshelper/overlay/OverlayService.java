package com.chesshelper.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chesshelper.overlay.core.BoardReader;
import com.chesshelper.overlay.core.Engine;
import com.chesshelper.overlay.core.GameTracker;
import com.chesshelper.overlay.core.Position;
import com.chesshelper.overlay.core.Rules;
import com.chesshelper.overlay.core.Texts;

import java.nio.ByteBuffer;
import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The floating "Chess Helper" window.
 *
 * - reads the board from the screen (MediaProjection screenshots),
 * - works out the best move,
 * - draws a YELLOW box on the piece to pick up and a GREEN box on the square to put it on.
 */
public class OverlayService extends Service {
    public static final String EXTRA_CODE = "code";
    public static final String EXTRA_DATA = "data";
    public static final String ACTION_STOP = "com.chesshelper.overlay.STOP";
    private static final String CHANNEL_ID = "chess_helper";
    private static final int NOTIF_ID = 7;
    public static volatile boolean running;

    // The box colours must equal BoardReader.OV_GREEN / OV_YELLOW (they are erased when reading).
    private static final int GREEN = Color.rgb(0, 224, 0);
    private static final int YELLOW = Color.rgb(255, 212, 0);
    private static final int BG = 0xFF1F2430, BAR = 0xFF11151C, FG = 0xFFE8E8E8, BTN = 0xFF323A4D;

    private static final String[] LEVEL_NAMES = {"Predictable", "Balanced", "Wild"};
    private static final int[] LEVEL_MARGIN = {1, 45, 90};
    private static final int[] LEVEL_TEMP = {1, 22, 45};
    private static final int[] THINK_SECONDS = {1, 2, 3, 5, 8};

    private WindowManager wm;
    private Handler ui;
    private ExecutorService readExec, engineExec;
    private HandlerThread frameThread;

    // screen capture
    private MediaProjection projection;
    private ImageReader imageReader;
    private VirtualDisplay virtualDisplay;
    private int screenW, screenH;
    private final Object frameLock = new Object();
    private Image heldImage;

    // views
    private LinearLayout panel, bodyView;
    private WindowManager.LayoutParams panelParams;
    private TextView statusView, targetView, detailsView, btnSide, btnAuto, btnLevel, btnThink;
    private FrameBox greenBox, yellowBox;
    private SelectView selectView;
    private int overlayDx, overlayDy;          // correction between requested and real window position
    private boolean offsetChecked;

    // game state (touched on the UI thread only, except `reader`)
    private final BoardReader reader = new BoardReader();
    private final GameTracker tracker = new GameTracker(true);
    private int[] region;                      // board rectangle on screen: left, top, w, h
    private boolean myWhite = true, auto;
    private int levelIdx = 1, thinkIdx = 2;
    private char[] lastRead, handled;
    private int stable, unclear;
    private String shownKey;
    private boolean readBusy;
    private int searchId;
    private AtomicBoolean cancelFlag;

    private static final class Frame {
        final int[] px;
        final int w, h;

        Frame(int[] px, int w, int h) {
            this.px = px;
            this.w = w;
            this.h = h;
        }
    }

    // ================================================================== lifecycle
    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        ui = new Handler(Looper.getMainLooper());
        readExec = Executors.newSingleThreadExecutor();
        engineExec = Executors.newSingleThreadExecutor();
        frameThread = new HandlerThread("chess-frames");
        frameThread.start();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @SuppressWarnings("deprecation")
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running || intent == null) return START_NOT_STICKY;
        try {
            createChannel();
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 29) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
            } else {
                startForeground(NOTIF_ID, n);
            }
            int code = intent.getIntExtra(EXTRA_CODE, 0);
            Intent data = intent.getParcelableExtra(EXTRA_DATA);
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            projection = mpm.getMediaProjection(code, data);
            projection.registerCallback(new MediaProjection.Callback() {
                @Override
                public void onStop() {
                    ui.post(new Runnable() {
                        @Override
                        public void run() {
                            stopSelf();
                        }
                    });
                }
            }, ui);
            setupCapture();
            buildUi();
            loadConfig();
            running = true;
        } catch (Exception e) {
            Toast.makeText(this, "Chess Helper could not start: " + e.getMessage(), Toast.LENGTH_LONG).show();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        auto = false;
        ui.removeCallbacksAndMessages(null);
        cancelSearch();
        try {
            hideBoxes();
            if (selectView != null) removeQuietly(selectView);
            if (panel != null) removeQuietly(panel);
        } catch (Exception ignored) {
        }
        synchronized (frameLock) {
            if (heldImage != null) heldImage.close();
            heldImage = null;
        }
        if (virtualDisplay != null) virtualDisplay.release();
        if (imageReader != null) imageReader.close();
        if (projection != null) projection.stop();
        readExec.shutdownNow();
        engineExec.shutdownNow();
        frameThread.quitSafely();
        super.onDestroy();
    }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Chess Helper",
                NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification.Action action = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", pi).build();
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Chess Helper is running")
                .setContentText("Open your chess app. Tap Stop to close the helper.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .addAction(action)
                .setOngoing(true)
                .build();
    }

    // ================================================================== screen capture
    @SuppressWarnings("deprecation")
    private void setupCapture() {
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getRealMetrics(dm);
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        imageReader = ImageReader.newInstance(screenW, screenH, PixelFormat.RGBA_8888, 3);
        imageReader.setOnImageAvailableListener(new ImageReader.OnImageAvailableListener() {
            @Override
            public void onImageAvailable(ImageReader r) {
                Image img = null;
                try {
                    img = r.acquireLatestImage();
                } catch (Exception ignored) {
                }
                if (img == null) return;
                synchronized (frameLock) {
                    if (heldImage != null) heldImage.close();
                    heldImage = img;               // keep only the newest frame
                }
            }
        }, new Handler(frameThread.getLooper()));
        virtualDisplay = projection.createVirtualDisplay("ChessHelper", screenW, screenH, dm.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, imageReader.getSurface(), null, null);
    }

    /** Copies a rectangle of the newest screen frame into ARGB pixels (null if there is no frame yet). */
    private Frame grabRegion(int l, int t, int w, int h) {
        synchronized (frameLock) {
            if (heldImage == null) return null;
            Image.Plane plane = heldImage.getPlanes()[0];
            ByteBuffer buf = plane.getBuffer();
            int rowStride = plane.getRowStride(), pixStride = plane.getPixelStride();
            int iw = heldImage.getWidth(), ih = heldImage.getHeight();
            l = Math.max(0, l);
            t = Math.max(0, t);
            w = Math.min(w, iw - l);
            h = Math.min(h, ih - t);
            if (w <= 0 || h <= 0) return null;
            int[] out = new int[w * h];
            for (int y = 0; y < h; y++) {
                int base = (t + y) * rowStride + l * pixStride;
                for (int x = 0; x < w; x++) {
                    int i = base + x * pixStride;
                    int r = buf.get(i) & 0xFF, g = buf.get(i + 1) & 0xFF, b = buf.get(i + 2) & 0xFF;
                    out[y * w + x] = 0xFF000000 | (r << 16) | (g << 8) | b;
                }
            }
            return new Frame(out, w, h);
        }
    }

    // ================================================================== UI building
    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private TextView makeButton(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(FG);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(10), dp(6), dp(10));
        t.setBackground(rounded(BTN, dp(8)));
        t.setClickable(true);
        t.setOnClickListener(l);
        return t;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(4);
        r.setLayoutParams(lp);
        return r;
    }

    private void addWeighted(LinearLayout row, View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(2);
        lp.rightMargin = dp(2);
        row.addView(v, lp);
    }

    private void buildUi() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(rounded(BG, dp(14)));

        // ---- title bar (drag handle) ----
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable barBg = rounded(BAR, dp(14));
        bar.setBackground(barBg);
        TextView title = new TextView(this);
        title.setText("♞  Chess Helper");
        title.setTextColor(GREEN);
        title.setTextSize(15);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        title.setPadding(dp(12), dp(8), dp(8), dp(8));
        bar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView collapse = new TextView(this);
        collapse.setText("–");
        collapse.setTextColor(0xFFAAB0C0);
        collapse.setTextSize(20);
        collapse.setPadding(dp(14), dp(4), dp(14), dp(4));
        collapse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bodyView.setVisibility(bodyView.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
            }
        });
        bar.addView(collapse);
        TextView close = new TextView(this);
        close.setText("✕");
        close.setTextColor(0xFFAAB0C0);
        close.setTextSize(18);
        close.setPadding(dp(14), dp(4), dp(14), dp(4));
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopSelf();
            }
        });
        bar.addView(close);
        bar.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = panelParams.x;
                        sy = panelParams.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelParams.x = sx + (int) (e.getRawX() - tx);
                        panelParams.y = sy + (int) (e.getRawY() - ty);
                        wm.updateViewLayout(panel, panelParams);
                        return true;
                    default:
                        return false;
                }
            }
        });
        panel.addView(bar);

        // ---- body ----
        bodyView = new LinearLayout(this);
        bodyView.setOrientation(LinearLayout.VERTICAL);
        bodyView.setPadding(dp(10), dp(6), dp(10), dp(10));
        panel.addView(bodyView);

        statusView = new TextView(this);
        statusView.setTextColor(FG);
        statusView.setTextSize(13);
        statusView.setTypeface(null, android.graphics.Typeface.BOLD);
        statusView.setText("Step 1: open a game with the START position, then tap ① Select board.");
        bodyView.addView(statusView);

        LinearLayout r1 = row();
        addWeighted(r1, makeButton("① Select board", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                selectBoard();
            }
        }));
        addWeighted(r1, makeButton("② Calibrate", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calibrate();
            }
        }));
        bodyView.addView(r1);

        LinearLayout r2 = row();
        TextView lbl = new TextView(this);
        lbl.setText("My pieces:");
        lbl.setTextColor(FG);
        lbl.setTextSize(13);
        r2.addView(lbl);
        btnSide = makeButton("White", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleSide();
            }
        });
        addWeighted(r2, btnSide);
        btnAuto = makeButton("Auto: OFF", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toggleAuto();
            }
        });
        addWeighted(r2, btnAuto);
        bodyView.addView(r2);

        LinearLayout r3 = row();
        btnLevel = makeButton("", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                levelIdx = (levelIdx + 1) % LEVEL_NAMES.length;
                refreshButtons();
                saveConfig();
            }
        });
        btnThink = makeButton("", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                thinkIdx = (thinkIdx + 1) % THINK_SECONDS.length;
                refreshButtons();
                saveConfig();
            }
        });
        addWeighted(r3, btnLevel);
        addWeighted(r3, btnThink);
        bodyView.addView(r3);

        targetView = new TextView(this);
        targetView.setText("The GREEN box will show\nwhere to place the piece");
        targetView.setTextColor(0xFFC9FFC9);
        targetView.setTextSize(16);
        targetView.setTypeface(null, android.graphics.Typeface.BOLD);
        targetView.setGravity(Gravity.CENTER);
        targetView.setPadding(dp(8), dp(12), dp(8), dp(12));
        GradientDrawable tbg = rounded(0xFF0B3D0B, dp(10));
        tbg.setStroke(dp(2), GREEN);
        targetView.setBackground(tbg);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        tlp.topMargin = dp(8);
        bodyView.addView(targetView, tlp);

        detailsView = new TextView(this);
        detailsView.setTextColor(0xFFC8CDD8);
        detailsView.setTextSize(11);
        bodyView.addView(detailsView);

        LinearLayout r4 = row();
        addWeighted(r4, makeButton("Suggest now", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                suggestNow();
            }
        }));
        addWeighted(r4, makeButton("Hide boxes", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideBoxes();
            }
        }));
        addWeighted(r4, makeButton("New game", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                newGame();
            }
        }));
        bodyView.addView(r4);

        refreshButtons();
        greenBox = new FrameBox(GREEN);
        yellowBox = new FrameBox(YELLOW);

        panelParams = new WindowManager.LayoutParams(dp(270), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = dp(10);
        panelParams.y = (int) (screenH * 0.55f);
        wm.addView(panel, panelParams);
    }

    private void refreshButtons() {
        btnSide.setText(myWhite ? "White" : "Black");
        btnAuto.setText(auto ? "Auto: ON" : "Auto: OFF");
        btnAuto.setTextColor(auto ? GREEN : FG);
        btnLevel.setText("Surprise: " + LEVEL_NAMES[levelIdx]);
        btnThink.setText("Think: " + THINK_SECONDS[thinkIdx] + "s");
    }

    private void setStatus(String s) {
        statusView.setText(s);
    }

    private void removeQuietly(View v) {
        try {
            wm.removeViewImmediate(v);
        } catch (Exception ignored) {
        }
    }

    // ================================================================== overlay boxes
    /** A hollow coloured rectangle drawn with four thin windows, so the square stays tappable. */
    private final class FrameBox {
        private final View[] views = new View[4];
        private final WindowManager.LayoutParams[] lps = new WindowManager.LayoutParams[4];
        private final boolean[] attached = new boolean[4];
        private int[] last;                                  // x, y, w, h, thickness of the last show()

        FrameBox(int color) {
            for (int i = 0; i < 4; i++) {
                views[i] = new View(OverlayService.this);
                views[i].setBackgroundColor(color);
                WindowManager.LayoutParams lp = new WindowManager.LayoutParams(10, 10,
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                        PixelFormat.OPAQUE);
                lp.gravity = Gravity.TOP | Gravity.START;
                if (Build.VERSION.SDK_INT >= 28) {
                    lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                }
                lps[i] = lp;
            }
        }

        void reshow() {
            if (last != null && attached[0]) show(last[0], last[1], last[2], last[3], last[4]);
        }

        void show(final int x, final int y, final int w, final int h, final int t) {
            last = new int[]{x, y, w, h, t};
            final int[][] g = {{x, y, w, t}, {x, y + h - t, w, t}, {x, y, t, h}, {x + w - t, y, t, h}};
            for (int i = 0; i < 4; i++) {
                lps[i].x = g[i][0] + overlayDx;
                lps[i].y = g[i][1] + overlayDy;
                lps[i].width = g[i][2];
                lps[i].height = g[i][3];
                try {
                    if (!attached[i]) {
                        wm.addView(views[i], lps[i]);
                        attached[i] = true;
                    } else {
                        wm.updateViewLayout(views[i], lps[i]);
                    }
                } catch (Exception ignored) {
                }
            }
            if (!offsetChecked) {
                // Some phones place overlay windows below the status bar / cutout. Measure where the
                // first edge really landed once, remember the difference, and redraw there.
                offsetChecked = true;
                final View first = views[0];
                first.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (!attached[0]) return;
                        int[] loc = new int[2];
                        first.getLocationOnScreen(loc);
                        int fixX = (g[0][0] + overlayDx) - loc[0];
                        int fixY = (g[0][1] + overlayDy) - loc[1];
                        if (fixX != 0 || fixY != 0) {
                            overlayDx += fixX;
                            overlayDy += fixY;
                            greenBox.reshow();
                            yellowBox.reshow();
                        }
                    }
                }, 150);
            }
        }

        void hide() {
            for (int i = 0; i < 4; i++) {
                if (attached[i]) {
                    removeQuietly(views[i]);
                    attached[i] = false;
                }
            }
        }
    }

    private void hideBoxes() {
        if (greenBox != null) greenBox.hide();
        if (yellowBox != null) yellowBox.hide();
    }

    // ================================================================== step 1: select the board
    /** Full-screen translucent layer: drag a rectangle around the board. */
    private final class SelectView extends View {
        private final Paint fill = new Paint(), line = new Paint(), text = new Paint();
        private float x0, y0, x1, y1;
        private float rawX0, rawY0;
        private boolean dragging;

        SelectView(Context c) {
            super(c);
            fill.setColor(0x2200E000);
            line.setColor(GREEN);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(dp(3));
            text.setColor(GREEN);
            text.setTextSize(dp(16));
            text.setFakeBoldText(true);
        }

        @Override
        protected void onDraw(Canvas c) {
            c.drawColor(0x77000000);
            c.drawText("Drag a rectangle around the 64 squares", dp(16), dp(90), text);
            c.drawText("(just tap to cancel)", dp(16), dp(115), text);
            if (dragging) {
                c.drawRect(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1), Math.max(y0, y1), fill);
                c.drawRect(Math.min(x0, x1), Math.min(y0, y1), Math.max(x0, x1), Math.max(y0, y1), line);
            }
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    x0 = x1 = e.getX();
                    y0 = y1 = e.getY();
                    rawX0 = e.getRawX();
                    rawY0 = e.getRawY();
                    dragging = true;
                    invalidate();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    x1 = e.getX();
                    y1 = e.getY();
                    invalidate();
                    return true;
                case MotionEvent.ACTION_UP:
                    dragging = false;
                    int l = (int) Math.min(rawX0, e.getRawX()), r = (int) Math.max(rawX0, e.getRawX());
                    int t = (int) Math.min(rawY0, e.getRawY()), b = (int) Math.max(rawY0, e.getRawY());
                    finishSelection(l, t, r - l, b - t);
                    return true;
                default:
                    return true;
            }
        }
    }

    private void selectBoard() {
        if (selectView != null) return;
        hideBoxes();
        auto = false;
        refreshButtons();
        ui.removeCallbacks(tick);
        panel.setVisibility(View.GONE);
        selectView = new SelectView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                        | WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        wm.addView(selectView, lp);
    }

    private void finishSelection(int l, int t, int w, int h) {
        removeQuietly(selectView);
        selectView = null;
        panel.setVisibility(View.VISIBLE);
        if (w < dp(120) || h < dp(120)) {
            setStatus("Selection cancelled (too small). Tap ① to try again.");
            return;
        }
        region = new int[]{l, t, w, h};
        reader.setReady(false);
        handled = null;
        shownKey = null;
        saveConfig();
        setStatus("Board selected ✔\nNow show the START position and tap ② Calibrate.");
    }

    // ================================================================== step 2: calibrate
    private boolean panelOverlapsBoard() {
        if (region == null || panel.getVisibility() != View.VISIBLE) return false;
        int[] loc = new int[2];
        panel.getLocationOnScreen(loc);
        int pl = loc[0], pt = loc[1], pr = pl + panel.getWidth(), pb = pt + panel.getHeight();
        return pl < region[0] + region[2] && pr > region[0] && pt < region[1] + region[3] && pb > region[1];
    }

    private void calibrate() {
        if (region == null) {
            setStatus("Tap ① Select board first.");
            return;
        }
        if (panelOverlapsBoard()) {
            setStatus("I'm covering the board! Drag me (by the title) off the board, then tap ② again.");
            return;
        }
        final int[] reg = region.clone();
        final boolean flipped = !myWhite;
        setStatus("Calibrating…");
        readExec.execute(new Runnable() {
            @Override
            public void run() {
                String msg;
                int[] newRegion = null;
                try {
                    int mx = reg[2] / 16, my = reg[3] / 16;           // margin around the rough selection
                    int L = Math.max(0, reg[0] - mx), T = Math.max(0, reg[1] - my);
                    Frame big = grabRegion(L, T, (reg[0] - L) + reg[2] + mx, (reg[1] - T) + reg[3] + my);
                    if (big == null) {
                        msg = "No screen picture yet. Move something on the screen, then tap ② again.";
                    } else {
                        int[] r = BoardReader.refineBoard(big.px, big.w, big.h, reg[0] - L, reg[1] - T, reg[2], reg[3]);
                        int[] sub = new int[r[2] * r[3]];
                        if (r[0] < 0 || r[1] < 0 || r[0] + r[2] > big.w || r[1] + r[3] > big.h)
                            throw new IllegalArgumentException("The selection is too close to the screen edge.");
                        for (int y = 0; y < r[3]; y++)
                            System.arraycopy(big.px, (r[1] + y) * big.w + r[0], sub, y * r[2], r[2]);
                        reader.calibrate(sub, r[2], r[3], flipped);
                        newRegion = new int[]{L + r[0], T + r[1], r[2], r[3]};
                        msg = "Calibrated ✔  Tap Auto. When it is your turn the GREEN box appears.";
                    }
                } catch (IllegalArgumentException e) {
                    msg = "Calibration failed: " + e.getMessage();
                } catch (Exception e) {
                    msg = "Calibration problem: " + e;
                }
                final String m = msg;
                final int[] nr = newRegion;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (nr != null) {
                            region = nr;
                            tracker.myWhite = myWhite;
                            tracker.reset();
                            handled = null;
                            lastRead = null;
                            shownKey = null;
                            saveConfig();
                        }
                        setStatus(m);
                    }
                });
            }
        });
    }

    // ================================================================== reading the game
    private void toggleSide() {
        myWhite = !myWhite;
        reader.setReady(false);
        tracker.myWhite = myWhite;
        tracker.reset();
        handled = null;
        shownKey = null;
        hideBoxes();
        refreshButtons();
        setStatus("Side changed. Show the START position (your pieces at the bottom) and tap ② Calibrate.");
        saveConfig();
    }

    private void toggleAuto() {
        ui.removeCallbacks(tick);
        if (!auto) {
            if (region == null || !reader.isReady()) {
                setStatus("First do ① Select board and ② Calibrate.");
                return;
            }
            auto = true;
            setStatus("Auto is ON. Waiting for your turn…");
            ui.post(tick);
        } else {
            auto = false;
        }
        refreshButtons();
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!auto) return;
            if (!readBusy && region != null && reader.isReady()) {
                readBusy = true;
                final int[] reg = region.clone();
                readExec.execute(new Runnable() {
                    @Override
                    public void run() {
                        char[] board = null;
                        try {
                            Frame f = grabRegion(reg[0], reg[1], reg[2], reg[3]);
                            if (f != null && f.w == reg[2] && f.h == reg[3]) board = reader.read(f.px, f.w, f.h);
                        } catch (Exception ignored) {
                        }
                        final char[] b = board;
                        ui.post(new Runnable() {
                            @Override
                            public void run() {
                                readBusy = false;
                                handleBoard(b, false);
                            }
                        });
                    }
                });
            }
            ui.postDelayed(this, 700);
        }
    };

    private void handleBoard(char[] board, boolean force) {
        if (board == null) {
            unclear++;
            if (unclear >= 3) {
                setStatus(panelOverlapsBoard() ? "I'm covering the board. Drag me off it."
                        : "Can't read the board clearly (piece being dragged? board covered or moved?)");
            }
            return;
        }
        unclear = 0;
        if (lastRead != null && java.util.Arrays.equals(board, lastRead)) stable++;
        else {
            lastRead = board;
            stable = 1;
        }
        if (!force && (stable < 2 || (handled != null && java.util.Arrays.equals(board, handled)))) return;
        handled = board;
        String result = tracker.update(board);
        if (result.equals("invalid")) {
            setStatus("That doesn't look like a legal chess position.");
            return;
        }
        if (result.equals("same") && !force && tracker.pos.key().equals(shownKey)) return;
        onPosition();
    }

    private void onPosition() {
        cancelSearch();
        hideBoxes();
        targetView.setText("The GREEN box will show\nwhere to place the piece");
        detailsView.setText("");
        Position pos = tracker.pos;
        shownKey = pos.key();
        String end = Rules.outcome(pos, tracker.keys, null);
        if (end != null) {
            setStatus(end);
            return;
        }
        String note = tracker.synced ? "" : "\n(joined mid-game: castling rights guessed)";
        if (pos.white == myWhite) {
            setStatus("Your turn - thinking…" + note);
            requestSuggestion();
        } else {
            setStatus("Opponent's turn…" + note);
        }
    }

    private void suggestNow() {
        if (region == null || !reader.isReady()) {
            setStatus("First do ① Select board and ② Calibrate.");
            return;
        }
        final int[] reg = region.clone();
        readExec.execute(new Runnable() {
            @Override
            public void run() {
                char[] board = null;
                try {
                    Frame f = grabRegion(reg[0], reg[1], reg[2], reg[3]);
                    if (f != null && f.w == reg[2] && f.h == reg[3]) board = reader.read(f.px, f.w, f.h);
                } catch (Exception ignored) {
                }
                final char[] b = board;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (b == null) {
                            setStatus("Can't read the board right now.");
                            return;
                        }
                        lastRead = b;
                        handled = b;
                        String res = tracker.update(b);
                        if (res.equals("invalid")) {
                            setStatus("That doesn't look like a legal chess position.");
                            return;
                        }
                        if (tracker.pos.white != myWhite) tracker.forceMyTurn();   // treat as my turn
                        onPosition();
                    }
                });
            }
        });
    }

    private void newGame() {
        cancelSearch();
        tracker.myWhite = myWhite;
        tracker.reset();
        handled = null;
        lastRead = null;
        shownKey = null;
        hideBoxes();
        targetView.setText("The GREEN box will show\nwhere to place the piece");
        detailsView.setText("");
        setStatus("Tracking reset. Play from the start position, or tap Auto.");
    }

    // ================================================================== the Helper
    private void cancelSearch() {
        if (cancelFlag != null) cancelFlag.set(true);
        searchId++;
    }

    private void requestSuggestion() {
        cancelSearch();
        final int sid = searchId;
        final AtomicBoolean cancel = new AtomicBoolean(false);
        cancelFlag = cancel;
        final Position pos = tracker.pos;
        final String key = pos.key();
        final int margin = LEVEL_MARGIN[levelIdx], temp = LEVEL_TEMP[levelIdx], secs = THINK_SECONDS[thinkIdx];
        engineExec.execute(new Runnable() {
            @Override
            public void run() {
                Engine.Result r = null;
                try {
                    r = new Engine(cancel).search(pos, 6, secs, margin, temp, new Random());
                } catch (Throwable ignored) {
                }
                final Engine.Result res = r;
                ui.post(new Runnable() {
                    @Override
                    public void run() {
                        if (sid != searchId || res == null) return;
                        if (!tracker.pos.key().equals(key)) return;
                        showSuggestion(res);
                    }
                });
            }
        });
    }

    /** Screen rectangle {x, y, w, h} of a square (0 = a8 ... 63 = h1). */
    private int[] squareRect(int sq) {
        int r = sq / 8, c = sq % 8;
        if (reader.isFlipped()) {
            r = 7 - r;
            c = 7 - c;
        }
        float cw = region[2] / 8f, ch = region[3] / 8f;
        int x0 = region[0] + Math.round(c * cw), y0 = region[1] + Math.round(r * ch);
        int x1 = region[0] + Math.round((c + 1) * cw), y1 = region[1] + Math.round((r + 1) * ch);
        return new int[]{x0, y0, x1 - x0, y1 - y0};
    }

    private void showSuggestion(Engine.Result res) {
        Position pos = tracker.pos;
        int m = res.move;
        int from = com.chesshelper.overlay.core.Move.from(m), to = com.chesshelper.overlay.core.Move.to(m);
        Texts.Described d = Texts.describe(pos, m);
        char piece = Character.toUpperCase(pos.b[from]);
        targetView.setText(Texts.glyph(piece) + " " + Texts.pieceName(piece) + "\n"
                + Rules.sqName(from) + "  →  " + Rules.sqName(to));
        StringBuilder sb = new StringBuilder();
        sb.append("Pick up the piece in the YELLOW box and put it in the GREEN box (")
                .append(Rules.sqName(to)).append(").");
        if (!d.tags.isEmpty()) sb.append("\nThis move ").append(android.text.TextUtils.join(", ", d.tags)).append(".");
        sb.append("\n").append(Texts.evalText(res.score)).append("  |  winning chance ")
                .append(Math.round(Texts.winChance(res.score) * 100)).append("%");
        detailsView.setText(sb.toString());
        setStatus("Your turn: move the " + Texts.pieceName(piece));
        int[] f = squareRect(from), t = squareRect(to);
        int th = Math.max(dp(3), (int) (Math.min(t[2], t[3]) * 0.06f));
        yellowBox.show(f[0] + 2, f[1] + 2, f[2] - 4, f[3] - 4, Math.max(2, th - 1));
        greenBox.show(t[0] + 2, t[1] + 2, t[2] - 4, t[3] - 4, th);
    }

    // ================================================================== settings
    private void saveConfig() {
        try {
            SharedPreferences.Editor e = getSharedPreferences("chess_helper", MODE_PRIVATE).edit();
            if (region != null) e.putString("region", region[0] + "," + region[1] + "," + region[2] + "," + region[3]);
            e.putString("screen", screenW + "x" + screenH);
            e.putBoolean("white", myWhite);
            e.putInt("level", levelIdx);
            e.putInt("think", thinkIdx);
            if (reader.isReady()) e.putString("reader", reader.serialize());
            else e.remove("reader");
            e.apply();
        } catch (Exception ignored) {
        }
    }

    private void loadConfig() {
        try {
            SharedPreferences p = getSharedPreferences("chess_helper", MODE_PRIVATE);
            myWhite = p.getBoolean("white", true);
            levelIdx = Math.max(0, Math.min(LEVEL_NAMES.length - 1, p.getInt("level", 1)));
            thinkIdx = Math.max(0, Math.min(THINK_SECONDS.length - 1, p.getInt("think", 2)));
            tracker.myWhite = myWhite;
            String reg = p.getString("region", null);
            String blob = p.getString("reader", null);
            if (reg != null && (screenW + "x" + screenH).equals(p.getString("screen", ""))) {
                String[] s = reg.split(",");
                region = new int[]{Integer.parseInt(s[0]), Integer.parseInt(s[1]),
                        Integer.parseInt(s[2]), Integer.parseInt(s[3])};
                if (blob != null && reader.deserialize(blob))
                    setStatus("Loaded your saved board ✔  Tap Auto to start.\n(Board moved? Redo ① and ②.)");
            }
            refreshButtons();
        } catch (Exception ignored) {
        }
    }
}
