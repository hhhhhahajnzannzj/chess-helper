package com.chesshelper.overlay.core;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Base64;

/**
 * Reads a chess position from a screenshot of the board.
 *
 * Calibration: you show the START position once; the reader learns the silhouette of every
 * piece type. Reading: each square is compared with those silhouettes (background colour
 * independent), brightness tells White from Black.
 *
 * Pure Java (works on int[] ARGB pixels) so it can be tested without Android.
 */
public final class BoardReader {
    public static final int GRID = 48;               // every square is shrunk to GRID x GRID
    private static final double INSET = 0.07;        // ignore the outer 7% of a square
    private static final double BG_TOL = 32.0;       // colour distance from background = "piece"
    private static final String PIECES = "PNBRQKpnbrqk";

    // Colours of our own hint boxes (the screenshot contains them, so they are erased).
    public static final int[] OV_GREEN = {0, 224, 0};
    public static final int[] OV_YELLOW = {255, 212, 0};

    private float[][] templates = new float[12][GRID * GRID];
    private float lumSplit = 128f;
    private float emptyFrac = 0.08f;
    private float minPieceFrac = 0.15f;
    private boolean flipped;
    private volatile boolean ready;

    public boolean isReady() {
        return ready;
    }

    public void setReady(boolean r) {
        ready = r;
    }

    public boolean isFlipped() {
        return flipped;
    }

    // ------------------------------------------------------------------ pixels -> features
    private static final class Cell {
        float frac;          // share of the square covered by a piece
        boolean[] sil;       // centred solid silhouette (GRID x GRID)
        float lum;           // brightness of the piece
    }

    /** Most common colour (the background) of n interleaved RGB pixels; skip[i] excludes pixels. */
    private static float[] modeColor(float[] a, int n, boolean[] skip) {
        int[] counts = new int[4096];
        int[] keys = new int[n];
        for (int i = 0; i < n; i++) {
            if (skip != null && skip[i]) {
                keys[i] = -1;
                continue;
            }
            int k = ((int) (a[3 * i] / 16)) * 256 + ((int) (a[3 * i + 1] / 16)) * 16 + (int) (a[3 * i + 2] / 16);
            keys[i] = k;
            counts[k]++;
        }
        int best = 0;
        for (int k = 1; k < 4096; k++) if (counts[k] > counts[best]) best = k;
        double sr = 0, sg = 0, sb = 0;
        int cnt = 0;
        for (int i = 0; i < n; i++) {
            if (keys[i] == best) {
                sr += a[3 * i];
                sg += a[3 * i + 1];
                sb += a[3 * i + 2];
                cnt++;
            }
        }
        if (cnt == 0) return new float[]{0, 0, 0};
        return new float[]{(float) (sr / cnt), (float) (sg / cnt), (float) (sb / cnt)};
    }

    /** Paint our own green/yellow hint boxes over with the background colour. */
    private static void eraseOverlay(float[] a, int w, int h) {
        boolean[] ov = new boolean[w * h];
        boolean any = false;
        for (int i = 0; i < w * h; i++) {
            float r = a[3 * i], g = a[3 * i + 1], b = a[3 * i + 2];
            if (Math.abs(r - OV_GREEN[0]) + Math.abs(g - OV_GREEN[1]) + Math.abs(b - OV_GREEN[2]) < 60
                    || Math.abs(r - OV_YELLOW[0]) + Math.abs(g - OV_YELLOW[1]) + Math.abs(b - OV_YELLOW[2]) < 60) {
                ov[i] = true;
                any = true;
            }
        }
        if (!any) return;
        for (int it = 0; it < 2; it++) {                    // grow by 2 px to remove blended edges
            boolean[] g2 = ov.clone();
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    if (!ov[y * w + x]) continue;
                    if (y > 0) g2[(y - 1) * w + x] = true;
                    if (y < h - 1) g2[(y + 1) * w + x] = true;
                    if (x > 0) g2[y * w + x - 1] = true;
                    if (x < w - 1) g2[y * w + x + 1] = true;
                }
            }
            ov = g2;
        }
        int keep = 0;
        for (boolean v : ov) if (!v) keep++;
        if (keep == 0) return;
        float[] mc = modeColor(a, w * h, ov);
        for (int i = 0; i < w * h; i++) {
            if (ov[i]) {
                a[3 * i] = mc[0];
                a[3 * i + 1] = mc[1];
                a[3 * i + 2] = mc[2];
            }
        }
    }

    /** Area-average the rectangle [x0,x1) x [y0,y1) of a (width w) down to GRID x GRID. */
    private static float[] boxResize(float[] a, int w, int x0, int y0, int x1, int y1) {
        int sw = x1 - x0, sh = y1 - y0;
        float[] out = new float[GRID * GRID * 3];
        for (int ty = 0; ty < GRID; ty++) {
            int ya = y0 + (int) Math.floor(ty * (double) sh / GRID);
            int yb = y0 + (int) Math.ceil((ty + 1) * (double) sh / GRID);
            if (yb > y1) yb = y1;
            if (yb <= ya) yb = ya + 1;
            for (int tx = 0; tx < GRID; tx++) {
                int xa = x0 + (int) Math.floor(tx * (double) sw / GRID);
                int xb = x0 + (int) Math.ceil((tx + 1) * (double) sw / GRID);
                if (xb > x1) xb = x1;
                if (xb <= xa) xb = xa + 1;
                double r = 0, g = 0, b = 0;
                int n = 0;
                for (int y = ya; y < yb; y++) {
                    for (int x = xa; x < xb; x++) {
                        int i = y * w + x;
                        r += a[3 * i];
                        g += a[3 * i + 1];
                        b += a[3 * i + 2];
                        n++;
                    }
                }
                int o = 3 * (ty * GRID + tx);
                out[o] = (float) (r / n);
                out[o + 1] = (float) (g / n);
                out[o + 2] = (float) (b / n);
            }
        }
        return out;
    }

    /** Make the piece a solid silhouette (white pieces have hollow bodies). */
    private static boolean[] fillHoles(boolean[] mask) {
        int G = GRID;
        boolean[] ext = new boolean[G * G];
        for (int i = 0; i < G; i++) {
            int[] edge = {i, (G - 1) * G + i, i * G, i * G + G - 1};
            for (int e : edge) if (!mask[e]) ext[e] = true;
        }
        boolean changed = true;
        while (changed) {
            changed = false;
            for (int y = 0; y < G; y++) {
                for (int x = 0; x < G; x++) {
                    int i = y * G + x;
                    if (ext[i] || mask[i]) continue;
                    if ((y > 0 && ext[i - G]) || (y < G - 1 && ext[i + G]) || (x > 0 && ext[i - 1])
                            || (x < G - 1 && ext[i + 1])) {
                        ext[i] = true;
                        changed = true;
                    }
                }
            }
        }
        boolean[] sil = new boolean[G * G];
        for (int i = 0; i < G * G; i++) sil[i] = !ext[i];
        return sil;
    }

    /** Slide the shape to the middle of the grid (the selection may be a few pixels off). */
    private static boolean[] center(boolean[] sil) {
        int G = GRID;
        int ymin = G, ymax = -1, xmin = G, xmax = -1;
        for (int y = 0; y < G; y++) {
            for (int x = 0; x < G; x++) {
                if (sil[y * G + x]) {
                    if (y < ymin) ymin = y;
                    if (y > ymax) ymax = y;
                    if (x < xmin) xmin = x;
                    if (x > xmax) xmax = x;
                }
            }
        }
        if (ymax < 0) return sil;
        int dy = G / 2 - (ymin + ymax) / 2;
        int dx = G / 2 - (xmin + xmax) / 2;
        boolean[] out = new boolean[G * G];
        for (int y = 0; y < G; y++) {
            for (int x = 0; x < G; x++) {
                if (!sil[y * G + x]) continue;
                int ny = y + dy, nx = x + dx;
                if (ny >= 0 && ny < G && nx >= 0 && nx < G) out[ny * G + nx] = true;
            }
        }
        return out;
    }

    private static Cell analyse(int[] px, int imgW, int x0, int y0, int x1, int y1) {
        int w = x1 - x0, h = y1 - y0;
        float[] a = new float[w * h * 3];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int c = px[(y0 + y) * imgW + x0 + x];
                int o = 3 * (y * w + x);
                a[o] = (c >> 16) & 255;
                a[o + 1] = (c >> 8) & 255;
                a[o + 2] = c & 255;
            }
        }
        eraseOverlay(a, w, h);
        int m = (int) (Math.min(w, h) * INSET);
        float[] small = boxResize(a, w, m, m, w - m, h - m);
        float[] bg = modeColor(small, GRID * GRID, null);
        boolean[] mask = new boolean[GRID * GRID];
        int covered = 0;
        for (int i = 0; i < GRID * GRID; i++) {
            double dr = small[3 * i] - bg[0], dg = small[3 * i + 1] - bg[1], db = small[3 * i + 2] - bg[2];
            if (Math.sqrt(dr * dr + dg * dg + db * db) > BG_TOL) {
                mask[i] = true;
                covered++;
            }
        }
        Cell c = new Cell();
        c.frac = covered / (float) (GRID * GRID);
        boolean[] sil = covered > 0 ? fillHoles(mask) : mask;
        double lum = 0;
        int n = 0;
        for (int i = 0; i < GRID * GRID; i++) {
            if (sil[i]) {
                lum += 0.299 * small[3 * i] + 0.587 * small[3 * i + 1] + 0.114 * small[3 * i + 2];
                n++;
            }
        }
        c.lum = n > 0 ? (float) (lum / n) : 0f;
        c.sil = center(sil);
        return c;
    }

    private static Cell[] analyseBoard(int[] px, int w, int h) {
        Cell[] cells = new Cell[64];
        for (int r = 0; r < 8; r++) {
            for (int c = 0; c < 8; c++) {
                int x0 = Math.round(c * w / 8f), y0 = Math.round(r * h / 8f);
                int x1 = Math.round((c + 1) * w / 8f), y1 = Math.round((r + 1) * h / 8f);
                cells[r * 8 + c] = analyse(px, w, x0, y0, x1, y1);
            }
        }
        return cells;
    }

    /** A plain round blob = the little "you can move here" dot. */
    private static boolean isDisc(boolean[] sil) {
        int n = 0;
        double sx = 0, sy = 0;
        for (int i = 0; i < sil.length; i++) {
            if (sil[i]) {
                n++;
                sx += i % GRID;
                sy += i / GRID;
            }
        }
        if (n < 8) return true;
        double mx = sx / n, my = sy / n, rEq = Math.sqrt(n / Math.PI);
        int inside = 0;
        for (int i = 0; i < sil.length; i++) {
            if (!sil[i]) continue;
            double dx = i % GRID - mx, dy = i / GRID - my;
            if (Math.sqrt(dx * dx + dy * dy) <= 1.15 * rEq) inside++;
        }
        return inside / (double) n > 0.97;
    }

    /** Square number (0 = a8 ... 63 = h1) of the i-th cell of the image. */
    public static int imgIndex(int i, boolean flipped) {
        int r = i / 8, c = i % 8;
        return flipped ? (7 - r) * 8 + (7 - c) : i;
    }

    // ------------------------------------------------------------------ calibrate / read
    /**
     * Learn the piece look from an image of the START position (the board only).
     *
     * @throws IllegalArgumentException with a message for the user when it doesn't work
     */
    public void calibrate(int[] px, int w, int h, boolean flipped) {
        ready = false;
        Cell[] cells = analyseBoard(px, w, h);
        char[] start = Position.fromFen(Rules.START_FEN).b;
        float[][] sum = new float[12][GRID * GRID];
        int[] cnt = new int[12];
        double lumW = 0, lumB = 0;
        int nW = 0, nB = 0;
        float minPiece = 1f, maxEmpty = 0f;
        for (int i = 0; i < 64; i++) {
            Cell c = cells[i];
            char p = start[imgIndex(i, flipped)];
            if (p == '.') {
                maxEmpty = Math.max(maxEmpty, c.frac);
                continue;
            }
            int pi = PIECES.indexOf(p);
            cnt[pi]++;
            for (int k = 0; k < GRID * GRID; k++) if (c.sil[k]) sum[pi][k] += 1f;
            if (Rules.isWhite(p)) {
                lumW += c.lum;
                nW++;
            } else {
                lumB += c.lum;
                nB++;
            }
            minPiece = Math.min(minPiece, c.frac);
        }
        if (minPiece < 2.5f * maxEmpty + 0.03f)
            throw new IllegalArgumentException("I can't tell pieces from empty squares. Is the START "
                    + "position visible, with nothing covering the board?");
        double wl = lumW / nW, bl = lumB / nB;
        if (wl < bl + 20)
            throw new IllegalArgumentException("White and Black pieces look too similar. Check "
                    + "'My pieces' (which colour is at the bottom).");
        float[][] t = new float[12][GRID * GRID];
        for (int p = 0; p < 12; p++) for (int k = 0; k < GRID * GRID; k++) t[p][k] = sum[p][k] / cnt[p];
        templates = t;
        lumSplit = (float) ((wl + bl) / 2);
        emptyFrac = Math.max(0.55f * minPiece, 2f * maxEmpty + 0.02f);
        minPieceFrac = minPiece;
        this.flipped = flipped;
        ready = true;
        char[] got = read(px, w, h);
        if (got == null || !Arrays.equals(got, start)) {
            ready = false;
            throw new IllegalArgumentException("Calibration check failed (read the start position wrongly). "
                    + "Try a plainer board theme / re-select the board.");
        }
    }

    /** @return 64 chars in board order (0 = a8), or null if some square is unclear */
    public char[] read(int[] px, int w, int h) {
        if (!ready) return null;
        float[][] tpl = templates;
        char[] board = new char[64];
        Arrays.fill(board, '.');
        Cell[] cells = analyseBoard(px, w, h);
        for (int i = 0; i < 64; i++) {
            Cell c = cells[i];
            if (c.frac < emptyFrac) continue;
            if (c.frac < 0.9f * minPieceFrac && isDisc(c.sil)) continue;   // move-hint dot
            boolean white = c.lum > lumSplit;
            double best = 0;
            int bestP = -1;
            for (int p = 0; p < 12; p++) {
                if (Rules.isWhite(PIECES.charAt(p)) != white) continue;
                double mn = 0, mx = 0;
                for (int k = 0; k < GRID * GRID; k++) {
                    float t = tpl[p][k], s = c.sil[k] ? 1f : 0f;
                    mn += Math.min(t, s);
                    mx += Math.max(t, s);
                }
                double score = mn / Math.max(mx, 1e-6);
                if (score > best) {
                    best = score;
                    bestP = p;
                }
            }
            if (best < 0.45 || bestP < 0) return null;
            board[imgIndex(i, flipped)] = PIECES.charAt(bestP);
        }
        return board;
    }

    // ------------------------------------------------------------------ save / load
    public String serialize() {
        ByteBuffer bb = ByteBuffer.allocate(13 + 12 * GRID * GRID);
        bb.putFloat(lumSplit).putFloat(emptyFrac).putFloat(minPieceFrac).put((byte) (flipped ? 1 : 0));
        for (float[] t : templates) for (float v : t) bb.put((byte) Math.round(v * 255f));
        return Base64.getEncoder().encodeToString(bb.array());
    }

    public boolean deserialize(String s) {
        try {
            ByteBuffer bb = ByteBuffer.wrap(Base64.getDecoder().decode(s));
            float ls = bb.getFloat(), ef = bb.getFloat(), mp = bb.getFloat();
            boolean fl = bb.get() == 1;
            float[][] t = new float[12][GRID * GRID];
            for (int p = 0; p < 12; p++) for (int k = 0; k < GRID * GRID; k++) t[p][k] = (bb.get() & 0xff) / 255f;
            templates = t;
            lumSplit = ls;
            emptyFrac = ef;
            minPieceFrac = mp;
            flipped = fl;
            ready = true;
            return true;
        } catch (Exception e) {
            ready = false;
            return false;
        }
    }

    // ------------------------------------------------------------------ snap selection to the grid
    private static int[] peaks(double[] profile, double icpt, double slope, int[] ks, double frac) {
        int[] pos = new int[ks.length];
        for (int i = 0; i < ks.length; i++) {
            double c = icpt + ks[i] * slope;
            int lo = Math.max((int) (c - frac * slope), 0);
            int hi = Math.min((int) (c + frac * slope), profile.length - 1);
            if (hi <= lo) return null;
            int arg = lo;
            for (int j = lo + 1; j < hi; j++) if (profile[j] > profile[arg]) arg = j;
            pos[i] = arg + 1;
        }
        return pos;
    }

    /** least-squares line through (ks, pos) -> {intercept, slope} */
    private static double[] polyfit(int[] ks, int[] pos) {
        double mk = 0, mp = 0;
        for (int i = 0; i < ks.length; i++) {
            mk += ks[i];
            mp += pos[i];
        }
        mk /= ks.length;
        mp /= ks.length;
        double num = 0, den = 0;
        for (int i = 0; i < ks.length; i++) {
            num += (ks[i] - mk) * (pos[i] - mp);
            den += (ks[i] - mk) * (ks[i] - mk);
        }
        double slope = num / den;
        return new double[]{mp - slope * mk, slope};
    }

    private static double[] fit(double[] profile, double origin, double step, int[] core, int[] all) {
        int[] pos = peaks(profile, origin, step, core, 0.25);          // rough fit from clean lines
        if (pos == null) return null;
        double[] f = polyfit(core, pos);
        if (Math.abs(f[1] - step) > 0.2 * step || Math.abs(f[0] - origin) > 0.8 * step) return null;
        pos = peaks(profile, f[0], f[1], all, 0.1);                    // then use every line
        if (pos == null) return null;
        return polyfit(all, pos);
    }

    private static int clamp(int v, int lo, int hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /**
     * Snap a rough board selection to the real square grid. px = screenshot (width W, height H)
     * with some margin around the board; (ax, ay, aw, ah) = rough selection inside it.
     * Needs the START position (ranks 3-6 are empty).
     *
     * @return {x, y, w, h}; the input rectangle if it can't tell
     */
    public static int[] refineBoard(int[] px, int W, int H, int ax, int ay, int aw, int ah) {
        int[] approx = {ax, ay, aw, ah};
        double cw = aw / 8.0, chh = ah / 8.0;
        int ya = clamp((int) (ay + 2.15 * chh), 0, H), yb = clamp((int) (ay + 5.85 * chh), 0, H);
        if (W < 3 || H < 3 || yb <= ya) return approx;
        double[] xprof = new double[W - 1];
        for (int y = ya; y < yb; y++) {
            for (int x = 0; x < W - 1; x++) {
                int c0 = px[y * W + x], c1 = px[y * W + x + 1];
                xprof[x] += Math.abs(((c1 >> 16) & 255) - ((c0 >> 16) & 255))
                        + Math.abs(((c1 >> 8) & 255) - ((c0 >> 8) & 255))
                        + Math.abs((c1 & 255) - (c0 & 255));
            }
        }
        int xa = clamp((int) (ax + 0.15 * cw), 0, W), xb = clamp((int) (ax + aw - 0.15 * cw), 0, W);
        if (xb <= xa) return approx;
        double[] yprof = new double[H - 1];
        double[] tmp = new double[xb - xa];
        for (int y = 0; y < H - 1; y++) {                    // median ignores piece edges
            for (int x = xa; x < xb; x++) {
                int c0 = px[y * W + x], c1 = px[(y + 1) * W + x];
                tmp[x - xa] = Math.abs(((c1 >> 16) & 255) - ((c0 >> 16) & 255))
                        + Math.abs(((c1 >> 8) & 255) - ((c0 >> 8) & 255))
                        + Math.abs((c1 & 255) - (c0 & 255));
            }
            Arrays.sort(tmp);
            int n = tmp.length;
            yprof[y] = n % 2 == 1 ? tmp[n / 2] : (tmp[n / 2 - 1] + tmp[n / 2]) / 2;
        }
        int[] seven = {1, 2, 3, 4, 5, 6, 7};
        double[] fx = fit(xprof, ax, cw, seven, seven);
        double[] fy = fit(yprof, ay, chh, new int[]{3, 4, 5}, seven);   // rows 3-5: empty squares both sides
        if (fx == null || fy == null) return approx;
        return new int[]{(int) Math.round(fx[0]), (int) Math.round(fy[0]),
                (int) Math.round(8 * fx[1]), (int) Math.round(8 * fy[1])};
    }
}
