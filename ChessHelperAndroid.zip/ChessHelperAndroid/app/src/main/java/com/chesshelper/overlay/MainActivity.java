package com.chesshelper.overlay;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

/**
 * Start screen. Walks you through the two permissions the floating window needs:
 *   1. "Display over other apps"  (to float above your chess game)
 *   2. screen capture             (to read the board)
 * then starts the floating "Chess Helper" window.
 */
public class MainActivity extends Activity {
    private static final int REQ_PROJECTION = 42;
    private static final int REQ_NOTIF = 43;

    private TextView stepOverlay, info;
    private TextView startButton;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = dp(20);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(0xFF1F2430);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(pad, dp(40), pad, pad);
        sv.addView(col);

        TextView title = text("♞  Chess Helper", 26, 0xFF00E000, true);
        col.addView(title);
        col.addView(text("A floating window that reads the chess game on your screen and shows a GREEN box "
                + "where to place your piece.", 15, 0xFFE8E8E8, false), lp(dp(10)));

        stepOverlay = button("", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askOverlayPermission();
            }
        });
        col.addView(stepOverlay, lp(dp(24)));

        startButton = button("▶  Start Chess Helper", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startHelper();
            }
        });
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF1B8A1B);
        g.setCornerRadius(dp(10));
        startButton.setBackground(g);
        col.addView(startButton, lp(dp(12)));

        TextView stop = button("■  Stop", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopService(new Intent(MainActivity.this, OverlayService.class));
                refresh();
            }
        });
        col.addView(stop, lp(dp(12)));

        info = text("", 14, 0xFFC8CDD8, false);
        col.addView(info, lp(dp(20)));

        col.addView(text("How to use\n"
                + "1. Tap Start, then “Start now” on the screen-capture question.\n"
                + "2. Open your chess app / website with a NEW game (start position).\n"
                + "3. In the floating window: tap ① Select board and drag around the 64 squares.\n"
                + "4. Tap ② Calibrate, then Auto.\n"
                + "5. On your turn a YELLOW box shows the piece to pick up and a GREEN box shows where to "
                + "put it. Drag the window by its title bar. Use – to shrink it.\n\n"
                + "Tips: pick a flat, plain board theme and turn off move-hint dots. Keep the window off the "
                + "board. Use it for practice and games against the computer; most chess sites forbid engine "
                + "help in rated games against people.", 13, 0xFFAAB0C0, false), lp(dp(10)));
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        boolean ok = Settings.canDrawOverlays(this);
        stepOverlay.setText(ok ? "✔  Permission “Display over other apps” is ON"
                : "①  Allow “Display over other apps”  (tap here)");
        stepOverlay.setTextColor(ok ? 0xFF00E000 : 0xFFFFFFFF);
        info.setText(OverlayService.running ? "The Chess Helper window is running. Switch to your chess game."
                : "Not running.");
    }

    private void askOverlayPermission() {
        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
        startActivity(i);
    }

    private void startHelper() {
        if (!Settings.canDrawOverlays(this)) {
            info.setText("First allow “Display over other apps” (the first button).");
            return;
        }
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIF);
            return;
        }
        if (OverlayService.running) {
            info.setText("Already running. Switch to your chess game.");
            return;
        }
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_PROJECTION);
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_NOTIF) startHelper();      // continue even if denied: the window still works
    }

    @Override
    protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req != REQ_PROJECTION) return;
        if (result != RESULT_OK || data == null) {
            info.setText("Screen capture was not allowed, so I can't read the board. Tap Start and choose “Start now”.");
            return;
        }
        Intent svc = new Intent(this, OverlayService.class);
        svc.putExtra(OverlayService.EXTRA_CODE, result);
        svc.putExtra(OverlayService.EXTRA_DATA, data);
        startForegroundService(svc);
        info.setText("Chess Helper started. Now open your chess game.");
        moveTaskToBack(true);                      // go back to whatever you were playing
    }

    // ---- small view helpers ----
    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private LinearLayout.LayoutParams lp(int topMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.topMargin = topMargin;
        return p;
    }

    private TextView text(String s, float sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    private TextView button(String s, View.OnClickListener l) {
        TextView t = text(s, 16, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(12), dp(16), dp(12), dp(16));
        GradientDrawable g = new GradientDrawable();
        g.setColor(0xFF323A4D);
        g.setCornerRadius(dp(10));
        t.setBackground(g);
        t.setOnClickListener(l);
        return t;
    }
}
