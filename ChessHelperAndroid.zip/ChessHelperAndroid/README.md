# Chess Helper for Android

A floating, draggable **"Chess Helper"** window. It reads the chess game on your screen and
draws a **green box** on the square where your piece should go (and a **yellow box** on the
piece to pick up). Moves come from a built-in engine that picks the best move but varies
randomly among near-best moves, so advice isn't predictable. Forced checkmates are always played.

Needs Android 8.0+ (API 26). No internet, no accounts, no third-party libraries.

## Build the APK with only a phone (free, GitHub builds it for you)

A zip cannot be turned into an app by a "zip to apk" converter: the code must be compiled and
signed. GitHub can do that for free:

1. In Chrome open github.com, create a free account, and turn on **Desktop site** (Chrome menu).
2. **New repository** -> name `chess-helper` -> Public -> tick *Add a README* -> Create.
3. **Add file > Upload files** -> pick the original `ChessHelperAndroid.zip` -> **Commit changes**.
4. **Add file > Create new file** -> in the name box type `.github/workflows/build.yml`
   -> paste the contents of `.github/workflows/build.yml` from this project -> **Commit changes**.
5. Open the **Actions** tab and wait ~5-10 minutes for a green check.
6. Back on the repository main page, open **Releases** (right side) -> latest -> download
   **ChessHelper.apk** -> install it (allow "install unknown apps" for your browser).

If the run shows a red X, open it and send a screenshot of the red error lines.

## Build the APK (Android Studio, ~5 minutes)

1. Install **Android Studio** (free): https://developer.android.com/studio
2. **File > Open** and choose this `ChessHelperAndroid` folder. Let Gradle sync finish
   (it downloads the Android SDK parts it needs; accept the licence prompts).
3. Plug in your phone (turn on *Developer options > USB debugging*) and press the green
   **Run** button. Or: **Build > Build Bundle(s) / APK(s) > Build APK(s)** and copy
   `app/build/outputs/apk/debug/app-debug.apk` to your phone and install it
   (allow "install unknown apps" when asked).

Command line alternative: `./gradlew assembleDebug`

## Use it

1. Open **Chess Helper**. Tap **(1) Allow "Display over other apps"**, switch it on, go back.
2. Tap **Start Chess Helper** -> allow notifications -> **Start now** on the screen-capture question.
3. The floating window appears. Open your chess app / website and start a **new game**
   (so the START position is visible).
4. In the floating window, set **My pieces** (the colour at the bottom of the board), tap
   **(1) Select board** and drag a rectangle around the 64 squares, then tap **(2) Calibrate**.
5. Tap **Auto: OFF** so it says **ON**. On your turn: YELLOW box = piece to pick up,
   GREEN box = where to put it. Drag the window by its title bar, tap the dash to shrink it.
6. **Surprise** (Predictable / Balanced / Wild) and **Think** (seconds) change how it chooses.
   **Suggest now** forces a suggestion; **New game** resets tracking.

Your selection and calibration are saved, so next time you can just tap Start and Auto
(if the board hasn't moved on screen).

## Tips and limits

* Works best with a flat, plain board theme. Turn off move-hint dots, coordinates drawn on
  the board, and fancy 3D/wood boards if reading fails.
* Keep the helper window off the board (drag it to the empty area under/above the board).
* Rotate the phone BEFORE selecting the board; if you rotate, select + calibrate again.
* Some banking-style or "secure" apps block screen capture; chess apps normally don't.
* Please use it for practice, analysis and games against the computer. Most chess sites
  ban engine help in rated games against real people.

## How it is built

`core/` is plain Java (no Android classes): `Rules` (move generation), `Engine` (alpha-beta
search + randomised choice), `BoardReader` (screenshot -> board, learns the pieces from the
start position), `GameTracker` (follows the game move by move, incl. castling / en passant).
`OverlayService` is the floating window + screen capture, `MainActivity` the permission screen.
