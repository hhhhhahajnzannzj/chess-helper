package com.chesshelper.overlay.core;

/** The "Choose elo" levels. Each range is played at its middle strength. 0 = off (full strength). */
public final class EloLevels {
    private EloLevels() {
    }

    public static final String[] NAMES = {"Off (full strength)", "100-500", "500-800", "800-1100", "1100-1400",
            "1400-1700", "1700-2000", "2000-2400", "2400-2800", "2800+ (maximum)"};
    /** The strength each level plays at (0 = off). */
    public static final int[] ELO = {0, 300, 650, 950, 1250, 1550, 1850, 2200, 2600, 3000};
    private static final double[] TEMP = {0, 450, 280, 170, 105, 65, 40, 22, 10, 3};          // centipawns: how far from the best a pick may stray
    private static final double[] BLUNDER = {0, 0.35, 0.20, 0.10, 0.04, 0, 0, 0, 0, 0};        // chance of a plain random pick among the best ten

    /** The level (index) of a strength value. */
    public static int indexOf(int elo) {
        for (int i = 0; i < ELO.length; i++) if (ELO[i] == elo) return i;
        return 0;
    }

    public static String nameOf(int elo) {
        return NAMES[indexOf(elo)];
    }

    /** How loose the choice is: low strength = large number. */
    public static double temperature(int elo) {
        return interpolate(TEMP, elo);
    }

    public static double blunderChance(int elo) {
        return interpolate(BLUNDER, elo);
    }

    private static double interpolate(double[] table, int elo) {
        if (elo <= ELO[1]) return table[1];
        for (int i = 2; i < ELO.length; i++) {
            if (elo <= ELO[i]) {
                double f = (elo - ELO[i - 1]) / (double) (ELO[i] - ELO[i - 1]);
                return table[i - 1] + (table[i] - table[i - 1]) * f;
            }
        }
        return table[ELO.length - 1];
    }
}
