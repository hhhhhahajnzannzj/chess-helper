package com.chesshelper.overlay;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.Icon;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.chesshelper.overlay.core.BoardGeometry;
import com.chesshelper.overlay.core.Brain;
import com.chesshelper.overlay.core.GameTracker;
import com.chesshelper.overlay.core.Move;
import com.chesshelper.overlay.core.Position;
import com.chesshelper.overlay.core.Rules;
import com.chesshelper.overlay.core.Texts;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * The floating "Chess Helper" window. It holds its own chess board: you tap every move (yours and the
 * opponent's) on it, and when it is your turn the best move is shown on that board with an ARROW and a
 * BLUE box. Nothing is read from the screen and nothing is sent anywhere.
 */
public class OverlayService extends Service {
    public static final String ACTION_STOP = "com.chesshelper.overlay.STOP";
    public static final String PREFS = "chess_helper";
    private static final String CHANNEL_ID = "chess_helper";
    private static final int NOTIF_ID = 7;
    public static volatile boolean running;

    private static final int GREEN = Color.rgb(0, 224, 0);
    private static final int BLUE = Color.rgb(47, 139, 255);
    private static final int BG = 0xFF1F2430, BAR = 0xFF11151C, FG = 0xFFE8E8E8, BTN = 0xFF323A4D;

    private static final int[] THINK_SECONDS = {1, 2, 3, 5, 8};
    private static final int[] BOARD_DP = {210, 260, 310};
    private static final String[] SIZE_NAMES = {"Small", "Medium", "Large"};

    private WindowManager wm;
    private Handler ui;
    private ExecutorService engineExec;
    private int screenW, screenH;

    // views
    private LinearLayout panel, bodyView;
    private WindowManager.LayoutParams panelParams;
    private TextView statusView, btnSide, btnThink, btnSize;
    private TextView btnUnpredictable, btnBrilliant, btnGambit, btnAlien;
    private BoardView boardView;

    // game state (UI thread only)
    private final GameTracker tracker = new GameTracker(true);
    private final List<Position> history = new ArrayList<>();
    private final Set<String> failedGambits = new HashSet<>();
    private boolean myWhite = true;
    private boolean unpredictable = true, onlyBrilliant, bestGambit, alienIq;
    private int thinkIdx = 1, sizeIdx = 1;
    private int job;                                   // bumps whenever work is cancelled / restarted
    private AtomicBoolean cancelFlag = new AtomicBoolean(false);

    // ================================================================== lifecycle
    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        ui = new Handler(Looper.getMainLooper());
        engineExec = Executors.newSingleThreadExecutor();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (running || intent == null) return START_NOT_STICKY;
        try {
            createChannel();
            Notification n = buildNotification();
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NOTIF_ID, n);
            }
            android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
            screenW = dm.widthPixels;
            screenH = dm.heightPixels;
            loadConfig();
            buildUi();
            running = true;
            newGame();
        } catch (Exception e) {
            Toast.makeText(this, "Chess Helper could not start: " + e.getMessage(), Toast.LENGTH_LONG).show();
            stopSelf();
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        running = false;
        cancelAll();
        ui.removeCallbacksAndMessages(null);
        try {
            if (panel != null) wm.removeViewImmediate(panel);
        } catch (Exception ignored) {
        }
        engineExec.shutdownNow();
        super.onDestroy();
    }

    private void createChannel() {
        NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Chess Helper",
                NotificationManager.IMPORTANCE_LOW);
        ((NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);
    }

    private Notification buildNotification() {
        Intent stop = new Intent(this, OverlayService.class).setAction(ACTION_STOP);
        PendingIntent pi = PendingIntent.getService(this, 0, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification.Action action = new Notification.Action.Builder(
                Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", pi).build();
        return new Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Chess Helper is running")
                .setContentText("Tap Stop to close the helper.")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .addAction(action)
                .setOngoing(true)
                .build();
    }

    // ================================================================== UI helpers
    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private TextView makeButton(String text, View.OnClickListener l) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(FG);
        t.setTextSize(13);
        t.setGravity(Gravity.CENTER);
        t.setPadding(dp(6), dp(10), dp(6), dp(10));
        t.setBackground(rounded(BTN, dp(8)));
        t.setClickable(true);
        t.setOnClickListener(l);
        return t;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(4);
        r.setLayoutParams(lp);
        return r;
    }

    private void addWeighted(LinearLayout row, View v) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        lp.leftMargin = dp(2);
        lp.rightMargin = dp(2);
        row.addView(v, lp);
    }

    private TextView smallText(int color, float sp, boolean bold) {
        TextView t = new TextView(this);
        t.setTextColor(color);
        t.setTextSize(sp);
        if (bold) t.setTypeface(null, android.graphics.Typeface.BOLD);
        return t;
    }

    private int boardPx() {
        int want = dp(BOARD_DP[sizeIdx]);
        return Math.min(want, screenW - dp(28));
    }

    private void buildUi() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setBackground(rounded(BG, dp(14)));

        // ---- title bar (drag handle) ----
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(rounded(BAR, dp(14)));
        TextView title = smallText(GREEN, 15, true);
        title.setText("♞  Chess Helper");
        title.setPadding(dp(12), dp(8), dp(8), dp(8));
        bar.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView collapse = smallText(0xFFAAB0C0, 20, false);
        collapse.setText("–");
        collapse.setPadding(dp(14), dp(4), dp(14), dp(4));
        collapse.setOnClickListener(v ->
                bodyView.setVisibility(bodyView.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE));
        bar.addView(collapse);
        TextView close = smallText(0xFFAAB0C0, 18, false);
        close.setText("✕");
        close.setPadding(dp(14), dp(4), dp(14), dp(4));
        close.setOnClickListener(v -> stopSelf());
        bar.addView(close);
        bar.setOnTouchListener(new View.OnTouchListener() {
            int sx, sy;
            float tx, ty;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = panelParams.x;
                        sy = panelParams.y;
                        tx = e.getRawX();
                        ty = e.getRawY();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelParams.x = sx + (int) (e.getRawX() - tx);
                        panelParams.y = sy + (int) (e.getRawY() - ty);
                        wm.updateViewLayout(panel, panelParams);
                        return true;
                    default:
                        return false;
                }
            }
        });
        panel.addView(bar);

        // ---- body ----
        bodyView = new LinearLayout(this);
        bodyView.setOrientation(LinearLayout.VERTICAL);
        bodyView.setPadding(dp(10), dp(6), dp(10), dp(10));
        panel.addView(bodyView);

        statusView = smallText(FG, 13, true);
        bodyView.addView(statusView);

        boardView = new BoardView(this);
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(boardPx(), boardPx());
        blp.topMargin = dp(6);
        blp.gravity = Gravity.CENTER_HORIZONTAL;
        bodyView.addView(boardView, blp);

        LinearLayout r1 = row();
        addWeighted(r1, makeButton("Undo move", v -> undo()));
        addWeighted(r1, makeButton("New game", v -> newGame()));
        bodyView.addView(r1);

        LinearLayout r2 = row();
        btnUnpredictable = makeButton("", v -> {
            unpredictable = !unpredictable;
            optionsChanged();
        });
        btnBrilliant = makeButton("", v -> {
            onlyBrilliant = !onlyBrilliant;
            optionsChanged();
        });
        addWeighted(r2, btnUnpredictable);
        addWeighted(r2, btnBrilliant);
        bodyView.addView(r2);

        LinearLayout r3 = row();
        btnGambit = makeButton("", v -> {
            bestGambit = !bestGambit;
            failedGambits.clear();
            optionsChanged();
        });
        btnAlien = makeButton("", v -> {
            alienIq = !alienIq;
            optionsChanged();
        });
        addWeighted(r3, btnGambit);
        addWeighted(r3, btnAlien);
        bodyView.addView(r3);

        LinearLayout r4 = row();
        btnSide = makeButton("", v -> toggleSide());
        btnThink = makeButton("", v -> {
            thinkIdx = (thinkIdx + 1) % THINK_SECONDS.length;
            optionsChanged();
        });
        addWeighted(r4, btnSide);
        addWeighted(r4, btnThink);
        bodyView.addView(r4);

        LinearLayout r5 = row();
        btnSize = makeButton("", v -> {
            sizeIdx = (sizeIdx + 1) % BOARD_DP.length;
            applySize();
            saveConfig();
            refreshButtons();
        });
        addWeighted(r5, btnSize);
        bodyView.addView(r5);

        refreshButtons();

        panelParams = new WindowManager.LayoutParams(panelWidth(), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelParams.gravity = Gravity.TOP | Gravity.START;
        panelParams.x = dp(8);
        panelParams.y = dp(48);
        wm.addView(panel, panelParams);
    }

    private int panelWidth() {
        return boardPx() + dp(20);
    }

    private void applySize() {
        LinearLayout.LayoutParams blp = (LinearLayout.LayoutParams) boardView.getLayoutParams();
        blp.width = boardPx();
        blp.height = boardPx();
        boardView.setLayoutParams(blp);
        panelParams.width = panelWidth();
        wm.updateViewLayout(panel, panelParams);
    }

    private void toggleButton(TextView b, String name, boolean on) {
        b.setText(name + ": " + (on ? "ON" : "OFF"));
        b.setTextColor(on ? GREEN : FG);
        b.setBackground(rounded(on ? 0xFF1B4A24 : BTN, dp(8)));
    }

    private void refreshButtons() {
        toggleButton(btnUnpredictable, "Unpredictable", unpredictable);
        toggleButton(btnBrilliant, "Only Brilliant", onlyBrilliant);
        toggleButton(btnGambit, "Use best Gambit", bestGambit);
        toggleButton(btnAlien, "Witten Alien IQ", alienIq);
        btnSide.setText("My pieces: " + (myWhite ? "White" : "Black"));
        btnThink.setText("Think: " + THINK_SECONDS[thinkIdx] + "s");
        btnSize.setText("Board size: " + SIZE_NAMES[sizeIdx]);
    }

    private void setStatus(String s) {
        statusView.setText(s);
    }

    // ================================================================== game
    private void cancelAll() {
        job++;
        cancelFlag.set(true);
        cancelFlag = new AtomicBoolean(false);
    }

    private void optionsChanged() {
        saveConfig();
        refreshButtons();
        advance();                                      // new settings: work out the hint again
    }

    private void newGame() {
        cancelAll();
        tracker.myWhite = myWhite;
        tracker.reset();
        history.clear();
        failedGambits.clear();
        boardView.clearSelection();
        boardView.setHint(-1, -1);
        advance();
    }

    private void undo() {
        if (history.isEmpty() || tracker.keys.size() < 2) return;
        cancelAll();
        tracker.pos = history.remove(history.size() - 1);
        tracker.keys.remove(tracker.keys.size() - 1);
        failedGambits.clear();
        boardView.clearSelection();
        boardView.setHint(-1, -1);
        advance();
    }

    private void toggleSide() {
        myWhite = !myWhite;
        saveConfig();
        refreshButtons();
        newGame();
    }

    private void play(int from, int to) {
        Position pos = tracker.pos;
        int chosen = -1;
        for (int m : Rules.legalMoves(pos)) {
            if (Move.from(m) == from && Move.to(m) == to && (Move.promo(m) == 0 || Move.promo(m) == 'Q')) chosen = m;
        }
        if (chosen < 0) return;
        cancelAll();
        history.add(pos);
        tracker.pos = Rules.apply(pos, chosen);
        tracker.keys.add(tracker.pos.key());
        boardView.setHint(-1, -1);
        advance();
    }

    /** After any change: game over? opponent's turn? or think about my move. */
    private void advance() {
        boardView.invalidate();
        Position pos = tracker.pos;
        String end = Rules.outcome(pos, tracker.keys, null);
        if (end != null) {
            setStatus(end);
            return;
        }
        if (pos.white != myWhite) {
            setStatus("Opponent's turn. Tap the piece they moved, then its new square.");
            return;
        }
        setStatus("Your turn - thinking…");
        think();
    }

    private void think() {
        cancelAll();
        final int myJob = job;
        final AtomicBoolean cancel = cancelFlag;
        final Position pos = tracker.pos;
        final boolean mine = myWhite;
        final Brain.Options o = new Brain.Options();
        o.unpredictable = unpredictable;
        o.onlyBrilliant = onlyBrilliant;
        o.bestGambit = bestGambit;
        o.alienIq = alienIq;
        o.thinkSeconds = THINK_SECONDS[thinkIdx];
        final Set<String> failed = new HashSet<>(failedGambits);
        engineExec.execute(() -> {
            Brain.Decision d = null;
            String problem = null;
            try {
                d = new Brain().decide(pos, mine, o, failed, new Random(), cancel);
            } catch (Throwable t) {
                problem = String.valueOf(t);
            }
            final Brain.Decision dec = d;
            final String err = problem;
            ui.post(() -> {
                if (myJob != job) return;                     // the position changed meanwhile
                failedGambits.addAll(failed);
                if (dec == null) {
                    setStatus(err != null ? "Could not think: " + err : "No move available.");
                    return;
                }
                boardView.setHint(dec.from, dec.to);
                String piece = Texts.pieceName(Character.toUpperCase(pos.b[dec.from]));
                setStatus("Move the " + piece + " as shown by the arrow.\n" + dec.note);
            });
        });
    }

    // ================================================================== the board
    private final class BoardView extends View {
        private final Paint p = new Paint(), t = new Paint();
        private final Path head = new Path();
        private int sel = -1;
        private int[] targets = new int[0];
        private int hintFrom = -1, hintTo = -1;

        BoardView(Context c) {
            super(c);
            p.setAntiAlias(true);
            t.setAntiAlias(true);
            t.setTextAlign(Paint.Align.CENTER);
        }

        void clearSelection() {
            sel = -1;
            targets = new int[0];
            invalidate();
        }

        void setHint(int from, int to) {
            hintFrom = from;
            hintTo = to;
            invalidate();
        }

        private int squareAt(int r, int c) {
            return BoardGeometry.imgIndex(r * 8 + c, !myWhite);
        }

        private float cx(int sq, float cell) {
            int i = BoardGeometry.imgIndex(sq, !myWhite);          // the mapping is its own inverse
            return (i % 8) * cell + cell / 2f;
        }

        private float cy(int sq, float cell) {
            int i = BoardGeometry.imgIndex(sq, !myWhite);
            return (i / 8) * cell + cell / 2f;
        }

        @Override
        protected void onDraw(Canvas cv) {
            float cell = getWidth() / 8f;
            Position pos = tracker.pos;
            for (int r = 0; r < 8; r++) {
                for (int c = 0; c < 8; c++) {
                    int sq = squareAt(r, c);
                    p.setStyle(Paint.Style.FILL);
                    p.setColor(((r + c) & 1) == 0 ? 0xFFEEEED2 : 0xFF769656);
                    cv.drawRect(c * cell, r * cell, (c + 1) * cell, (r + 1) * cell, p);
                    if (sq == sel) {
                        p.setColor(0xAAFFD400);
                        cv.drawRect(c * cell, r * cell, (c + 1) * cell, (r + 1) * cell, p);
                    }
                    char ch = pos.b[sq];
                    if (ch != '.') {
                        String g = Texts.glyph(Character.toUpperCase(ch));
                        t.setTextSize(cell * 0.82f);
                        float x = c * cell + cell / 2f, y = r * cell + cell * 0.76f;
                        boolean white = Rules.isWhite(ch);
                        t.setStyle(Paint.Style.STROKE);
                        t.setStrokeWidth(cell * 0.06f);
                        t.setColor(white ? 0xFF222222 : 0xFFFFFFFF);
                        cv.drawText(g, x, y, t);
                        t.setStyle(Paint.Style.FILL);
                        t.setColor(white ? 0xFFFFFFFF : 0xFF111111);
                        cv.drawText(g, x, y, t);
                    }
                    for (int tg : targets) {
                        if (tg == sq) {
                            p.setColor(0xCC00E000);
                            cv.drawCircle(c * cell + cell / 2f, r * cell + cell / 2f, cell * 0.17f, p);
                        }
                    }
                }
            }
            t.setStyle(Paint.Style.FILL);
            t.setTextSize(cell * 0.24f);
            t.setColor(0xFF33442A);
            for (int i = 0; i < 8; i++) {                                // a-h / 1-8 labels
                String file = String.valueOf((char) ('a' + (myWhite ? i : 7 - i)));
                String rank = String.valueOf(myWhite ? 8 - i : i + 1);
                cv.drawText(file, i * cell + cell * 0.82f, 8 * cell - cell * 0.06f, t);
                cv.drawText(rank, cell * 0.14f, i * cell + cell * 0.27f, t);
            }
            if (hintFrom >= 0 && hintTo >= 0) drawHint(cv, cell);
        }

        /** BLUE box on the piece and on the target square, and a BLUE arrow between them. */
        private void drawHint(Canvas cv, float cell) {
            float fx = cx(hintFrom, cell), fy = cy(hintFrom, cell);
            float tx = cx(hintTo, cell), ty = cy(hintTo, cell);
            float h = cell / 2f;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0x552F8BFF);
            cv.drawRect(fx - h, fy - h, fx + h, fy + h, p);
            cv.drawRect(tx - h, ty - h, tx + h, ty + h, p);
            p.setStyle(Paint.Style.STROKE);
            p.setColor(BLUE);
            p.setStrokeWidth(cell * 0.07f);
            cv.drawRect(fx - h + cell * 0.04f, fy - h + cell * 0.04f, fx + h - cell * 0.04f, fy + h - cell * 0.04f, p);
            p.setStrokeWidth(cell * 0.13f);
            cv.drawRect(tx - h + cell * 0.07f, ty - h + cell * 0.07f, tx + h - cell * 0.07f, ty + h - cell * 0.07f, p);

            float dx = tx - fx, dy = ty - fy;
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len < 1f) return;
            float ux = dx / len, uy = dy / len;
            float headLen = cell * 0.42f, headW = cell * 0.30f;
            float sx = fx + ux * cell * 0.30f, sy = fy + uy * cell * 0.30f;     // start just outside the piece
            float bx = tx - ux * (cell * 0.28f + headLen), by = ty - uy * (cell * 0.28f + headLen);
            float ex = tx - ux * cell * 0.28f, ey = ty - uy * cell * 0.28f;
            p.setColor(0xEE2F8BFF);
            p.setStrokeWidth(cell * 0.16f);
            p.setStrokeCap(Paint.Cap.ROUND);
            cv.drawLine(sx, sy, bx, by, p);
            p.setStyle(Paint.Style.FILL);
            head.reset();
            head.moveTo(ex, ey);
            head.lineTo(bx - uy * headW, by + ux * headW);
            head.lineTo(bx + uy * headW, by - ux * headW);
            head.close();
            cv.drawPath(head, p);
            p.setStrokeCap(Paint.Cap.BUTT);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            if (e.getAction() != MotionEvent.ACTION_UP) return true;
            float cell = getWidth() / 8f;
            int c = (int) (e.getX() / cell), r = (int) (e.getY() / cell);
            if (c < 0 || c > 7 || r < 0 || r > 7) return true;
            int sq = squareAt(r, c);
            Position pos = tracker.pos;
            for (int tg : targets) {
                if (tg == sq && sel >= 0) {
                    int from = sel;
                    clearSelection();
                    play(from, sq);
                    return true;
                }
            }
            char ch = pos.b[sq];
            if (ch != '.' && Rules.isWhite(ch) == pos.white) {
                sel = sq;
                List<Integer> list = new ArrayList<>();
                for (int m : Rules.legalMoves(pos)) {
                    if (Move.from(m) == sq && !list.contains(Move.to(m))) list.add(Move.to(m));
                }
                targets = new int[list.size()];
                for (int i = 0; i < targets.length; i++) targets[i] = list.get(i);
            } else {
                sel = -1;
                targets = new int[0];
            }
            invalidate();
            return true;
        }
    }

    // ================================================================== settings
    private void saveConfig() {
        try {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putBoolean("white", myWhite)
                    .putBoolean("t_unpred", unpredictable)
                    .putBoolean("t_brill", onlyBrilliant)
                    .putBoolean("t_gambit", bestGambit)
                    .putBoolean("t_alien", alienIq)
                    .putInt("think3", thinkIdx)
                    .putInt("size3", sizeIdx)
                    .apply();
        } catch (Exception ignored) {
        }
    }

    private void loadConfig() {
        try {
            SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
            myWhite = p.getBoolean("white", true);
            unpredictable = p.getBoolean("t_unpred", true);
            onlyBrilliant = p.getBoolean("t_brill", false);
            bestGambit = p.getBoolean("t_gambit", false);
            alienIq = p.getBoolean("t_alien", false);
            thinkIdx = Math.max(0, Math.min(THINK_SECONDS.length - 1, p.getInt("think3", 1)));
            sizeIdx = Math.max(0, Math.min(BOARD_DP.length - 1, p.getInt("size3", 1)));
        } catch (Exception ignored) {
        }
    }
}
