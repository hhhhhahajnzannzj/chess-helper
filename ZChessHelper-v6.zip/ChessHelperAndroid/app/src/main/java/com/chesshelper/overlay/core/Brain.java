package com.chesshelper.overlay.core;

import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/** Chooses the move to show, according to the toggles. */
public final class Brain {
    public static final class Options {
        public boolean unpredictable = true;
        public boolean onlyBrilliant;
        public boolean bestGambit;
        public boolean alienIq;
        public double thinkSeconds = 2;
    }

    public static final class Decision {
        public int move;
        public int from, to;
        public int score;               // centipawns, mover's view
        public String kind;             // "best", "random", "brilliant", "gambit", "accurate", "mate"
        public String note;             // one line for the person
        public Engine.Result result;
    }

    private final Gambits.Line[] book;

    public Brain() {
        this(Gambits.BOOK);
    }

    public Brain(Gambits.Line[] book) {
        this.book = book;
    }

    /**
     * @param failed names of gambits that already failed in this game; this method adds to it
     * @return null when there is no legal move
     */
    public Decision decide(Position pos, boolean myWhite, Options o, Set<String> failed, Random rng,
                           AtomicBoolean cancel) {
        Engine eng = new Engine(cancel);
        boolean accurateOnly = o.alienIq || !o.unpredictable;
        double secs = o.alienIq ? Math.max(o.thinkSeconds, 6) : o.thinkSeconds;
        int depth = o.alienIq ? 16 : 7;
        Engine.Result r = eng.search(pos, depth, secs, accurateOnly ? 0 : 45, accurateOnly ? 1 : 22, rng);
        if (r == null) return null;

        String gambitNote = null;
        if (o.bestGambit) {
            List<Gambits.Pick> picks = Gambits.matches(pos, myWhite, failed, book);
            for (Gambits.Pick pk : picks) {
                int s = pk.move == r.bestMove ? r.bestScore : eng.scoreMove(pos, pk.move, Math.max(4, r.depth), 1.5);
                boolean sound = s != Integer.MIN_VALUE && s >= r.bestScore - 200 && s >= -250;
                if (sound) {
                    return make(pos, pk.move, s, "gambit", pk.line.name + " (book move)", r);
                }
                if (failed != null) failed.add(pk.line.name);          // refuted: try the next gambit
                gambitNote = pk.line.name + " failed";
            }
            if (!picks.isEmpty()) {
                gambitNote += "; playing the 100% accurate move";
            } else {
                gambitNote = "No gambit fits this position; playing the 100% accurate move";
            }
            // gambit plan is over for this move: be fully accurate (no random choice)
            if (!accurateOnly) {
                Engine.Result acc = new Engine(cancel).search(pos, depth, secs, 0, 1, rng);
                if (acc != null) r = acc;
            }
        }

        if (o.onlyBrilliant) {
            int b = eng.findBrilliant(pos, r, rng, o.unpredictable && !o.alienIq, Math.max(1.0, secs));
            if (b >= 0) {
                int s = b == r.bestMove ? r.bestScore : eng.scoreMove(pos, b, Math.max(4, r.depth), 1.0);
                if (s == Integer.MIN_VALUE) s = r.bestScore;
                return make(pos, b, s, "brilliant", "Brilliant move (a real sacrifice that works)", r);
            }
            Decision d = plain(pos, r, o);
            d.note = "No brilliant move here. " + d.note;
            return withGambit(d, gambitNote);
        }
        return withGambit(plain(pos, r, o), gambitNote);
    }

    private static Decision withGambit(Decision d, String gambitNote) {
        if (gambitNote != null) {
            d.kind = "accurate";
            d.note = gambitNote + ".";
        }
        return d;
    }

    private static Decision plain(Position pos, Engine.Result r, Options o) {
        boolean mate = r.score >= Engine.MATE - 200;
        String kind = mate ? "mate" : (o.alienIq ? "accurate" : (o.unpredictable ? "random" : "best"));
        String note = mate ? "Forced mate!" : o.alienIq ? "Alien IQ: deepest search, 100% accurate"
                : o.unpredictable ? "A strong move, picked with some surprise" : "The best move";
        return make(pos, r.move, r.score, kind, note, r);
    }

    private static Decision make(Position pos, int move, int score, String kind, String note, Engine.Result r) {
        Decision d = new Decision();
        d.move = move;
        d.from = Move.from(move);
        d.to = Move.to(move);
        d.score = score;
        d.kind = kind;
        d.note = note;
        d.result = r;
        return d;
    }
}
