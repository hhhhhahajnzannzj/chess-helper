# Chess Helper (Android)

A floating chess board. You tap the moves (yours and the opponent's) on it, and on your turn it shows the best
move on its own board with a BLUE box and an ARROW. It reads nothing from the screen and sends nothing anywhere
(no internet permission, no screen capture, no API key).

Switches: Unpredictable, Only Brilliant, Use best Gambit (book + fallback to other gambits, then 100% accurate
play), Witten Alien IQ (strongest mode). Also: Undo move, New game, My pieces, Think time, Board size.

Build: upload the zip to a GitHub repo; the Actions workflow builds `ChessHelper.apk` and publishes it under Releases.
Use for practice and games against the computer; most chess sites forbid engine help in games against people.
